# Android project — Iran Stock Signal v1.1

Native Android WebView shell around the v1.1 Persian mobile UI.

## Build
Requires Android SDK 35 and Gradle/Android Gradle Plugin 8.7.3.

From this directory:

    gradle :app:assembleDebug

APK output:

    app/build/outputs/apk/debug/app-debug.apk

## Important
The bundled HTML is the current v1.1 UI. The Python/FastAPI backend from the original project remains separate and is not embedded in this APK. The UI must point to a running API service for live TSETMC analysis. The Android shell currently loads the UI from local assets.

## v19 additions
- Hot Money Score (0-100): combines real buyer power, abnormal volume, real-money flow strength, and multi-day persistence.
- Anomaly / Information-Risk Score (0-100): flags unusually synchronized volume, money flow, persistence and price behavior. This is a screening indicator only and does not prove insider trading or illegal activity.
