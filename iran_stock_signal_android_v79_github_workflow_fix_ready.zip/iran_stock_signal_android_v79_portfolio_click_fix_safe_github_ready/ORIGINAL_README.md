# Iran Stock Signal MVP 1.0

Analytical prototype for Iranian-market stock screening. It is **not a profit guarantee or financial advice**.

## Current capabilities
- Live TSETMC price history with schema validation.
- Termux-friendly `curl` fallback when Python HTTP is blocked.
- Real/client money-flow history when TSETMC exposes it.
- Technical features: MA20/MA50, RSI14, MACD, ATR14, volume ratio, support/resistance.
- 100-point signal engine with hard risk filters.
- Multi-symbol scanner.
- Conservative historical backtest with next-open entry, fees/slippage, stop/target handling and no look-ahead.
- Completed positions are recorded as one trade even when Target-1 is partial, preventing distorted metrics.

## API
- `/health`
- `/connection-check`
- `/signal/{symbol}`
- `/scan?symbols=فولاد,فملی,شپنا`
- `/backtest/{symbol}`

## Run
```bash
pip install -r requirements.txt
uvicorn app.api:app --reload
```

Production use must validate live data and market conditions. Signals are analytical outputs, not guaranteed outcomes.
