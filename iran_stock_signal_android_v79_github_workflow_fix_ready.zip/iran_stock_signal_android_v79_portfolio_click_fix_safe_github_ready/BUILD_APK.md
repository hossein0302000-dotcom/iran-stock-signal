# Build APK

Version: 1.14.0 (versionCode 65)

GitHub Actions: upload this repository and run the Android APK workflow.
