package com.iranstocks.signal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new MarketBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class MarketBridge {
        @JavascriptInterface public void analyze(final String symbol) {
            new Thread(() -> {
                String result;
                try { result = analyzeSymbol(symbol); }
                catch (Exception e) { result = errorJson(e.getMessage() == null ? "خطا در دریافت داده" : e.getMessage()); }
                final String js = "window.receiveAnalysis(" + JSONObject.quote(result) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            }).start();
        }
    }

    private String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "application/json,text/plain,*/*");
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close(); c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("TSETMC HTTP " + code);
        return b.toString();
    }

    private String analyzeSymbol(String symbol) throws Exception {
        String q = URLEncoder.encode(symbol.trim(), "UTF-8").replace("+", "%20");
        JSONObject search = new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentSearch/" + q));
        JSONArray arr = search.optJSONArray("instrument");
        if (arr == null) arr = search.optJSONArray("instruments");
        if (arr == null) arr = search.optJSONArray("data");
        if (arr == null) throw new Exception("نماد پیدا نشد");
        String insCode = null, title = symbol;
        for (int i=0;i<arr.length();i++) {
            JSONObject x = arr.optJSONObject(i); if (x == null) continue;
            String code = x.optString("insCode", "");
            if (code.length() > 0) { insCode = code; title = x.optString("lVal30", x.optString("lVal18AFC", symbol)); break; }
        }
        if (insCode == null) throw new Exception("نماد پیدا نشد");

        JSONObject histObj = new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/" + insCode + "/0"));
        JSONArray raw = histObj.optJSONArray("closingPriceDaily");
        if (raw == null || raw.length() < 60) throw new Exception("داده تاریخی کافی نیست");
        List<Row> rows = new ArrayList<>();
        for (int i=0;i<raw.length();i++) {
            JSONObject x=raw.optJSONObject(i); if(x==null) continue;
            double close=num(x,"pClosing","close","Close");
            double open=num(x,"priceFirst","pOpen","open","Open");
            double high=num(x,"priceMax","pHigh","high","High");
            double low=num(x,"priceMin","pLow","low","Low");
            double vol=num(x,"qTotTran5J","volume","Volume");
            if(close>0) rows.add(new Row(close,open,high,low,vol,x.optInt("dEven",0)));
        }
        Collections.sort(rows, Comparator.comparingInt(a -> a.date));
        if(rows.size()<60) throw new Exception("داده تاریخی کافی نیست");
        int n=rows.size()-1; Row cur=rows.get(n);
        double ma20=avgClose(rows,n,20), ma50=avgClose(rows,n,50), avgVol20=avgVol(rows,n,20);
        double rsi=rsi(rows,n,14); double prevRsi=rsi(rows,n-1,14);
        double macd=ema(rows,n,12)-ema(rows,n,26), prevMacd=ema(rows,n-1,12)-ema(rows,n-1,26);
        double resistance=highest(rows,n-1,20);
        int score=0; List<String> reasons=new ArrayList<>(); List<String> warnings=new ArrayList<>();
        if(cur.close>ma20){score+=5; reasons.add("قیمت بالای میانگین ۲۰ روزه");}
        if(cur.close>ma50){score+=5; reasons.add("قیمت بالای میانگین ۵۰ روزه");}
        if(ma20>ma50){score+=5; reasons.add("روند میان‌مدت صعودی است");}
        if(ma20>avgClose(rows,n-1,20)){score+=5; reasons.add("شیب میانگین ۲۰ روزه مثبت است");}
        if(rsi>=50 && rsi<=65){score+=6; reasons.add("RSI در محدوده مناسب است");} else if(rsi>65 && rsi<=70){score+=3; reasons.add("مومنتوم مثبت است");} else if(rsi>70){warnings.add("RSI بالاست؛ ورود می‌تواند پرریسک‌تر باشد");}
        if(macd>0){score+=5; reasons.add("MACD مثبت است");}
        if(macd>prevMacd){score+=4; reasons.add("مومنتوم MACD رو به بهبود است");}
        double vr=avgVol20>0?cur.vol/avgVol20:0;
        if(vr>=2){score+=15; reasons.add("حجم معاملات بیش از دو برابر میانگین است");}
        else if(vr>=1.5){score+=12; reasons.add("حجم معاملات قوی است");}
        else if(vr>=1.2){score+=8; reasons.add("حجم معاملات بالاتر از میانگین است");}
        else if(vr>=1.0){score+=4; reasons.add("حجم معاملات تأیید نسبی دارد");}
        if(cur.close>resistance && cur.vol>=avgVol20*1.2){score+=15; reasons.add("شکست مقاومت با تأیید حجم");}
        else if(cur.close>resistance){score+=8; warnings.add("شکست مقاومت هنوز تأیید حجمی کامل ندارد");}
        else warnings.add("هنوز شکست مقاومت ۲۰ روزه دیده نمی‌شود");
        score=Math.max(0,Math.min(100,score));
        String action=score>=80?"BUY":score>=70?"BUY":score>=55?"WATCH":"EXIT/NO_ENTRY";
        if(cur.close<ma50 && rsi<45){warnings.add("روند و مومنتوم ضعیف است"); if(score>69) action="WATCH";}
        double atr=atr(rows,n,14); double stop=Math.max(0,cur.close-1.5*atr); double risk=cur.close-stop; double t1=cur.close+1.5*risk; double t2=cur.close+2.5*risk;
        JSONObject out=new JSONObject(); out.put("ok",true); out.put("symbol",title); out.put("score",score); out.put("action",action); out.put("entry",cur.close); out.put("stop",stop); out.put("target1",t1); out.put("target2",t2); out.put("data_rows",rows.size()); out.put("source","TSETMC"); out.put("reasons",new JSONArray(reasons)); out.put("warnings",new JSONArray(warnings));
        return out.toString();
    }

    private double num(JSONObject x,String... keys){for(String k:keys) if(x.has(k)) return x.optDouble(k,0); return 0;}
    private double avgClose(List<Row> a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z+=a.get(i).close;return z/(end-s+1);}
    private double avgVol(List<Row> a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z+=a.get(i).vol;return z/(end-s+1);}
    private double highest(List<Row>a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z=Math.max(z,a.get(i).high);return z;}
    private double rsi(List<Row>a,int end,int len){if(end<len)return 50;double g=0,l=0;for(int i=end-len+1;i<=end;i++){double d=a.get(i).close-a.get(i-1).close;if(d>0)g+=d;else l-=d;}if(l==0)return 100;double rs=(g/len)/(l/len);return 100-(100/(1+rs));}
    private double ema(List<Row>a,int end,int len){int s=Math.max(0,end-len*3);double e=a.get(s).close;double k=2.0/(len+1);for(int i=s+1;i<=end;i++)e=a.get(i).close*k+e*(1-k);return e;}
    private double atr(List<Row>a,int end,int len){int s=Math.max(1,end-len+1);double z=0;for(int i=s;i<=end;i++){Row r=a.get(i),p=a.get(i-1);z+=Math.max(r.high-r.low,Math.max(Math.abs(r.high-p.close),Math.abs(r.low-p.close)));}return z/(end-s+1);}
    private String errorJson(String msg){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",msg);return o.toString();}catch(Exception e){return "{\"ok\":false,\"error\":\"خطا\"}";}}
    private static class Row{double close,open,high,low,vol;int date;Row(double c,double o,double h,double l,double v,int d){close=c;open=o;high=h;low=l;vol=v;date=d;}}

    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null)webView.destroy();super.onDestroy();}
}
