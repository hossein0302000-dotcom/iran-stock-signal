# V21 build

This build keeps the V20 features and hardens the Android build:
- versionCode 15 / versionName 1.5.1
- Java 17 compile/target compatibility is explicit
- long-term JSON array construction is explicit for Android compatibility
- GitHub Actions uses current setup action major versions
- Gradle build uses `--stacktrace` so a future failure exposes the actual compiler/resource error
