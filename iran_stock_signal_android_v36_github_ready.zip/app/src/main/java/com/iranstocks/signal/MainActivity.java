package com.iranstocks.signal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new MarketBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class MarketBridge {
        @JavascriptInterface public void analyze(final String symbol) {
            new Thread(() -> {
                String result;
                try { result = analyzeSymbol(symbol); }
                catch (Exception e) { result = errorJson(e.getMessage() == null ? "خطا در دریافت داده" : e.getMessage()); }
                final String js = "window.receiveAnalysis(" + JSONObject.quote(result) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            }).start();
        }

        @JavascriptInterface public void scanMarket() { scanMarket("short"); }

        @JavascriptInterface public void backtestMarket() {
            new Thread(() -> {
                String result;
                try { result = backtestMarketInternal(); }
                catch (Exception e) { result = errorJson(e.getMessage() == null ? "خطا در اعتبارسنجی" : e.getMessage()); }
                final String js = "window.receiveBacktest(" + JSONObject.quote(result) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            }).start();
        }

        @JavascriptInterface public void scanMarket(String mode) {
            final String scanMode = (mode == null || mode.trim().isEmpty()) ? "short" : mode;
            new Thread(() -> {
                String result;
                try { result = scanMarketInternal(scanMode); }
                catch (Exception e) { result = errorJson(e.getMessage() == null ? "خطا در اسکن بازار" : e.getMessage()); }
                final String js = "window.receiveScan(" + JSONObject.quote(result) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            }).start();
        }
    }

    private String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "application/json,text/plain,*/*");
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close(); c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("TSETMC HTTP " + code);
        return b.toString();
    }

    private String analyzeSymbol(String symbol) throws Exception {
        String q = URLEncoder.encode(symbol.trim(), "UTF-8").replace("+", "%20");
        JSONObject search = new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentSearch/" + q));
        JSONArray arr = search.optJSONArray("instrumentSearch");
        if (arr == null) arr = search.optJSONArray("instrument");
        if (arr == null) arr = search.optJSONArray("instruments");
        if (arr == null) arr = search.optJSONArray("data");
        if (arr == null) throw new Exception("نماد پیدا نشد");
        String insCode = null, title = symbol;
        for (int i=0;i<arr.length();i++) {
            JSONObject x = arr.optJSONObject(i); if (x == null) continue;
            String code = x.optString("insCode", "");
            if (code.length() > 0) { insCode = code; title = x.optString("lVal30", x.optString("lVal18AFC", symbol)); break; }
        }
        if (insCode == null) throw new Exception("نماد پیدا نشد");
        return analyzeInsCode(insCode, title, getMarketRegime());
    }

    private String analyzeInsCode(String insCode, String title, MarketRegime market) throws Exception {
        JSONObject histObj = new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/" + insCode + "/0"));
        JSONArray raw = histObj.optJSONArray("closingPriceDaily");
        if (raw == null || raw.length() < 60) throw new Exception("داده تاریخی کافی نیست");
        List<Row> rows = new ArrayList<>();
        for (int i=0;i<raw.length();i++) {
            JSONObject x=raw.optJSONObject(i); if(x==null) continue;
            double close=num(x,"pClosing","close","Close");
            double open=num(x,"priceFirst","pOpen","open","Open");
            double high=num(x,"priceMax","pHigh","high","High");
            double low=num(x,"priceMin","pLow","low","Low");
            double vol=num(x,"qTotTran5J","volume","Volume");
            if(close>0) rows.add(new Row(close,open,high,low,vol,x.optInt("dEven",0)));
        }
        Collections.sort(rows, Comparator.comparingInt(a -> a.date));
        if(rows.size()<60) throw new Exception("داده تاریخی کافی نیست");
        int n=rows.size()-1; Row cur=rows.get(n);

        // --- Trend: 20 points ---
        double ma20=avgClose(rows,n,20), ma50=avgClose(rows,n,50), avgVol20=avgVol(rows,n,20);
        double rsi=rsi(rows,n,14);
        double macd=ema(rows,n,12)-ema(rows,n,26), prevMacd=ema(rows,n-1,12)-ema(rows,n-1,26);
        double adx=adx(rows,n,14);
        double mfi=mfi(rows,n,14);
        double resistance=highest(rows,n-1,20);

        int score=0;
        List<String> reasons=new ArrayList<>();
        List<String> warnings=new ArrayList<>();

        if(cur.close>ma20){score+=5; reasons.add("قیمت بالای میانگین ۲۰ روزه");}
        if(cur.close>ma50){score+=5; reasons.add("قیمت بالای میانگین ۵۰ روزه");}
        if(ma20>ma50){score+=5; reasons.add("روند میان‌مدت صعودی است");}
        if(ma20>avgClose(rows,n-1,20)){score+=5; reasons.add("شیب میانگین ۲۰ روزه مثبت است");}

        // --- Momentum: 15 points ---
        if(rsi>=50 && rsi<=65){score+=5; reasons.add("RSI در محدوده مناسب است");}
        else if(rsi>65 && rsi<=70){score+=3; reasons.add("مومنتوم مثبت است");}
        else if(rsi>70){warnings.add("RSI بالاست؛ ورود می‌تواند پرریسک‌تر باشد");}
        else if(rsi<40){warnings.add("RSI ضعیف است");}
        if(macd>0){score+=3; reasons.add("MACD مثبت است");}
        if(macd>prevMacd){score+=2; reasons.add("مومنتوم MACD رو به بهبود است");}
        if(adx>=25){score+=5; reasons.add("ADX قدرت روند را تأیید می‌کند");}
        else if(adx>=20){score+=3; reasons.add("قدرت روند متوسط است");}
        else warnings.add("ADX پایین است؛ روند قدرت کافی ندارد");

        // --- Volume: 15 points (direction-aware) ---
        double vr=avgVol20>0?cur.vol/avgVol20:0;
        boolean positiveCandle=cur.close>=cur.open && cur.close>=rows.get(Math.max(0,n-1)).close;
        if(positiveCandle){
            if(vr>=2){score+=15; reasons.add("حجم بالا همراه حرکت مثبت قیمت است");}
            else if(vr>=1.5){score+=12; reasons.add("حجم معاملات قوی و هم‌جهت با قیمت است");}
            else if(vr>=1.2){score+=8; reasons.add("حجم معاملات بالاتر از میانگین است");}
            else if(vr>=1.0){score+=4; reasons.add("حجم معاملات تأیید نسبی دارد");}
            else warnings.add("حجم معاملات پایین‌تر از میانگین است");
        } else if(vr>=1.2){
            warnings.add("حجم بالا همراه فشار فروش است؛ حجم به‌تنهایی سیگنال خرید نیست");
        } else if(vr<1.0){
            warnings.add("حجم معاملات پایین‌تر از میانگین است");
        }

        // --- Breakout / structure: 15 points ---
        if(cur.close>resistance && cur.close>=cur.open && cur.vol>=avgVol20*1.2){score+=15; reasons.add("شکست مقاومت با تأیید قیمت و حجم");}
        else if(cur.close>resistance && cur.close>=cur.open){score+=8; warnings.add("شکست مقاومت هنوز تأیید حجمی کامل ندارد");}
        else warnings.add("هنوز شکست مقاومت ۲۰ روزه تأیید نشده است");

        // --- Smart liquidity: Hot Money 10 + Anomaly/Rent-risk 5 = 15 points ---
        ClientData ct = getLatestClientType(insCode, cur.date);
        double buyerPower=0, realMoneyFlow=0, hotMoneyScore=0, anomalyScore=0;
        if(ct != null) {
            double avgBuy = ct.buyIValue>0 && ct.buyICount>0 ? ct.buyIValue/ct.buyICount : 0;
            double avgSell = ct.sellIValue>0 && ct.sellICount>0 ? ct.sellIValue/ct.sellICount : 0;
            buyerPower = avgSell>0 ? avgBuy/avgSell : 0;
            realMoneyFlow = ct.buyIValue - ct.sellIValue;
            double flowRatio = (ct.buyIValue + ct.sellIValue)>0 ? realMoneyFlow/(ct.buyIValue + ct.sellIValue) : 0;
            double fiveDayFlow=0, fiveDayTurnover=0; int posFlowDays=0, activeDays=0;
            try {
                JSONObject co=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/"+insCode));
                JSONArray ca=co.optJSONArray("clientType");
                if(ca!=null){
                    for(int i=0;i<ca.length();i++){
                        JSONObject x=ca.optJSONObject(i); if(x==null) continue;
                        int d=x.optInt("recDate",0); if(d>cur.date) continue;
                        double bv=x.optDouble("buy_I_Value",0), sv=x.optDouble("sell_I_Value",0);
                        double f=bv-sv;
                        if(activeDays<5){ fiveDayFlow+=f; fiveDayTurnover+=(bv+sv); if(f>0)posFlowDays++; activeDays++; }
                    }
                }
            } catch(Exception ignored) {}
            double flowPct=Math.max(0,Math.min(100,flowRatio*500));
            double powerPts=buyerPower>=2?25:buyerPower>=1.5?20:buyerPower>=1.2?15:buyerPower>=1.0?9:buyerPower>=0.8?4:0;
            double volPts=vr>=3?25:vr>=2?20:vr>=1.5?15:vr>=1.2?9:0;
            double persistence=activeDays>0?(posFlowDays/(double)activeDays)*25:0;
            double flowStrength=fiveDayTurnover>0?Math.max(0,Math.min(25,(fiveDayFlow/fiveDayTurnover)*250)):0;
            hotMoneyScore=Math.round(Math.max(0,Math.min(100,powerPts+volPts+flowStrength+persistence)));
            if(buyerPower>0 && buyerPower<0.80) hotMoneyScore=Math.min(hotMoneyScore,35);
            if(realMoneyFlow<0) hotMoneyScore=Math.min(hotMoneyScore,45);
            if(hotMoneyScore>=80){score+=10; reasons.add("پول داغ و ورود نقدینگی قوی است");}
            else if(hotMoneyScore>=60){score+=8; reasons.add("ورود نقدینگی قابل توجه است");}
            else if(hotMoneyScore>=40){score+=5; reasons.add("نشانه‌هایی از ورود نقدینگی دیده می‌شود");}
            else if(flowRatio<-0.02) warnings.add("خروج پول حقیقی دیده می‌شود");

            // Anomaly score is a screening flag, not proof of insider trading.
            double priceAcceleration=Math.abs(cur.close>0 && rows.get(Math.max(0,n-3)).close>0 ? (cur.close/rows.get(Math.max(0,n-3)).close-1)*100 : 0);
            double volumeShock=Math.max(0,Math.min(35,(vr-1)*18));
            double moneyShock=Math.max(0,Math.min(30,Math.abs(flowRatio)*300));
            double persistenceShock=posFlowDays>=4?20:posFlowDays>=3?15:posFlowDays>=2?8:0;
            double noBreakout=(cur.close<=resistance && vr>=1.8)?15:0;
            anomalyScore=Math.round(Math.max(0,Math.min(100,volumeShock+moneyShock+persistenceShock+noBreakout+Math.min(15,priceAcceleration*2))));
            if(anomalyScore>=75) warnings.add("رفتار معاملاتی بسیار غیرعادی؛ احتمال اطلاعات‌محور بودن حرکت نیازمند بررسی است");
            else if(anomalyScore>=55) warnings.add("رفتار معاملاتی غیرعادی دیده می‌شود");
        } else {
            warnings.add("داده حقیقی/حقوقی برای آخرین روز در دسترس نیست");
        }

        // --- MFI: 5 points, complementary price-volume money-flow confirmation ---
        if(mfi>=60){score+=5; reasons.add("MFI ورود نقدینگی را تأیید می‌کند");}
        else if(mfi>=50){score+=3; reasons.add("MFI خنثی رو به مثبت است");}
        else if(mfi<40) warnings.add("MFI ضعیف است؛ فشار فروش پولی دیده می‌شود");

        // --- Market regime: 10 points ---
        score += market.score;
        if(market.score>=8) reasons.add("رژیم کلی بازار مساعد است");
        else if(market.score>=5) reasons.add("رژیم کلی بازار خنثی است");
        else warnings.add("رژیم کلی بازار ضعیف است");

        // --- Risk: 10 points ---
        double atr=atr(rows,n,14);
        double structuralStop = lowest(rows,n,20);
        double atrStop = Math.max(0,cur.close-1.5*atr);
        double stop = Math.max(structuralStop, atrStop);
        if(stop<=0 || stop>=cur.close) stop=atrStop;
        double riskPct = cur.close>0 ? (cur.close-stop)/cur.close*100.0 : 100;
        if(riskPct<=4){score+=10; reasons.add("ریسک حد ضرر پایین است");}
        else if(riskPct<=6){score+=8; reasons.add("فاصله حد ضرر قابل قبول است");}
        else if(riskPct<=8){score+=6; reasons.add("ریسک متوسط است");}
        else if(riskPct<=12){score+=3; warnings.add("فاصله حد ضرر نسبتاً زیاد است");}
        else warnings.add("فاصله حد ضرر زیاد است؛ ورود پرریسک است");

        score=Math.max(0,Math.min(100,score));
        String action=score>=70?"BUY":score>=55?"WATCH":"EXIT/NO_ENTRY";

        // Hard confirmation gates: prevent a high composite score from overriding a clearly weak setup.
        if(buyerPower>0 && buyerPower<0.80){
            score=Math.min(score,69);
            warnings.add("قدرت خریدار زیر ۰٫۸۰ است؛ امتیاز بالا به‌تنهایی مجوز ورود نیست");
            action="WATCH";
        }
        if(buyerPower>0 && buyerPower<0.65 && realMoneyFlow<=0){
            score=Math.min(score,54);
            warnings.add("قدرت خریدار بسیار ضعیف و جریان پول حقیقی منفی است");
            action="EXIT/NO_ENTRY";
        }
        if(rsi>75){
            score=Math.min(score,69);
            warnings.add("RSI بیش‌خرید شدید دارد؛ ورود جدید تأیید نمی‌شود");
            action="WATCH";
        }
        if(market.score<=2){
            score=Math.min(score,69);
            warnings.add("رژیم کلی بازار ضعیف است؛ ورود کوتاه‌مدت تأیید نمی‌شود");
            action="WATCH";
        }
        if(cur.close<ma50 && rsi<45){warnings.add("روند و مومنتوم ضعیف است"); if(score>69) action="WATCH";}
        if(buyerPower>0 && buyerPower<0.8 && cur.close<ma20) { action="WATCH"; warnings.add("قدرت فروش حقیقی با روند قیمت همسو است"); }

        double risk=cur.close-stop;
        double t1=cur.close+1.5*risk;
        double t2=cur.close+2.5*risk;
        JSONObject out=new JSONObject();
        out.put("ok",true); out.put("symbol",title); out.put("score",score); out.put("action",action);
        out.put("entry",cur.close); out.put("stop",stop); out.put("target1",t1); out.put("target2",t2);
        // --- Long-term quality score: continuous 100-point model, not a guarantee ---
        int longScore = 0;
        List<String> longReasons = new ArrayList<>();
        if(rows.size() >= 200){
            double ma200=avgClose(rows,n,200);
            double ma200Prev=avgClose(rows,n-20,200);
            double ref120=rows.get(Math.max(0,n-120)).close;
            double ref250=rows.get(Math.max(0,n-250)).close;
            double ret120=ref120>0?(cur.close/ref120-1)*100:0;
            double ret250=ref250>0?(cur.close/ref250-1)*100:0;
            double high250=highest(rows,n,250);
            double dd250=high250>0?(cur.close/high250-1)*100:0;
            double atr14=atr(rows,n,14);

            // 20: price position versus MA200 (-10% .. +15%)
            double pMa200=ma200>0?(cur.close/ma200-1)*100:0;
            double c1=clamp((pMa200+10.0)/25.0,0,1)*20;
            if(pMa200>3) longReasons.add("قیمت با فاصله مناسب بالای میانگین ۲۰۰ روزه است");
            else if(pMa200>0) longReasons.add("قیمت بالای میانگین ۲۰۰ روزه است");

            // 15: MA50/MA200 relationship (-5% .. +10%)
            double maSpread=ma200>0?(ma50/ma200-1)*100:0;
            double c2=clamp((maSpread+5.0)/15.0,0,1)*15;
            if(maSpread>0) longReasons.add("میانگین ۵۰ روزه بالاتر از ۲۰۰ روزه است");

            // 15: MA200 slope (-5% .. +8%)
            double slope=ma200Prev>0?(ma200/ma200Prev-1)*100:0;
            double c3=clamp((slope+5.0)/13.0,0,1)*15;
            if(slope>0) longReasons.add("شیب میانگین ۲۰۰ روزه مثبت است");

            // 20: 12-month return (-30% .. +40%)
            double c4=clamp((ret250+30.0)/70.0,0,1)*20;
            if(ret250>=10) longReasons.add("بازده حدود ۱۲ ماهه مثبت و قابل قبول است");

            // 15: 6-month return (-25% .. +30%)
            double c5=clamp((ret120+25.0)/55.0,0,1)*15;
            if(ret120>=5) longReasons.add("روند ۶ ماهه مثبت است");

            // 10: distance from annual high (-40% .. -5% preferred)
            double c6=clamp((dd250+40.0)/35.0,0,1)*10;
            if(dd250>=-15) longReasons.add("فاصله از سقف سالانه کنترل‌شده است");

            // 5: lower ATR/price = better stability
            double atrPct=cur.close>0?atr14/cur.close*100:10;
            double c7=clamp((8.0-atrPct)/5.0,0,1)*5;
            if(atrPct<4.5) longReasons.add("نوسان روزانه نسبتاً کنترل‌شده است");

            longScore=(int)Math.round(c1+c2+c3+c4+c5+c6+c7);
            longScore=Math.max(0,Math.min(100,longScore));
        }
        out.put("long_term_score",longScore);
        out.put("long_term_action",longScore>=80?"بلندمدت مناسب":(longScore>=65?"بلندمدت قابل بررسی":"بلندمدت ضعیف"));
        JSONArray longReasonsJson = new JSONArray();
        for(String reason : longReasons) longReasonsJson.put(reason);
        out.put("long_term_reasons",longReasonsJson);

        // --- Independent 1-month / 3-month horizon scores ---
        HorizonScore oneMonth = calcHorizonScore(rows, n, 21, buyerPower, realMoneyFlow, market.score);
        HorizonScore threeMonth = calcHorizonScore(rows, n, 63, buyerPower, realMoneyFlow, market.score);
        out.put("one_month_score",oneMonth.score); out.put("one_month_action",oneMonth.action);
        out.put("one_month_target",oneMonth.target); out.put("one_month_return",oneMonth.expectedReturn);
        out.put("three_month_score",threeMonth.score); out.put("three_month_action",threeMonth.action);
        out.put("three_month_target",threeMonth.target); out.put("three_month_return",threeMonth.expectedReturn);
        out.put("one_month_reasons",new JSONArray(oneMonth.reasons)); out.put("three_month_reasons",new JSONArray(threeMonth.reasons));
        out.put("risk_pct",riskPct); out.put("buyer_power",buyerPower); out.put("real_money_flow",realMoneyFlow); out.put("hot_money_score",hotMoneyScore); out.put("anomaly_score",anomalyScore); out.put("rent_score",anomalyScore); out.put("adx",adx); out.put("mfi",mfi); out.put("volume_ratio",vr);
        out.put("market_regime",market.label); out.put("data_rows",rows.size()); out.put("source","TSETMC");
        out.put("reasons",new JSONArray(reasons)); out.put("warnings",new JSONArray(warnings));
        return out.toString();
    }

    private String scanMarketInternal(String scanMode) throws Exception {
        List<ScanCandidate> candidates = new ArrayList<>();
        String sourceUsed = "MarketWatch";
        StringBuilder diag = new StringBuilder();

        // Primary source: official TSETMC market watch.
        try {
            String url="https://cdn.tsetmc.com/api/ClosingPrice/GetMarketWatch?market=0&industrialGroup=&paperTypes%5B0%5D=1&paperTypes%5B1%5D=2&paperTypes%5B2%5D=3&paperTypes%5B3%5D=4&paperTypes%5B4%5D=5&paperTypes%5B5%5D=6&paperTypes%5B6%5D=7&paperTypes%5B7%5D=8&paperTypes%5B8%5D=9&showTraded=false&withBestLimits=false&hEven=0&RefID=0";
            JSONObject o=new JSONObject(httpGet(url));
            JSONArray a=o.optJSONArray("marketwatch");
            if(a!=null){
                for(int i=0;i<a.length();i++){
                    JSONObject x=a.optJSONObject(i); if(x==null) continue;
                    String code=x.optString("insCode","");
                    String sym=x.optString("lVal18AFC",x.optString("symbol",x.optString("lVal30","")));
                    double close=num(x,"pClosing","pc","priceClosing");
                    double last=num(x,"pDrCotVal","pl","priceLast");
                    double yesterday=num(x,"priceYesterday","py","yClose");
                    double vol=num(x,"qTotTran5J","tvol","volume");
                    double value=num(x,"qTotCap","tval","value");
                    addCandidate(candidates,code,sym,close,last,yesterday,vol,value);
                    if(!candidates.isEmpty()){ ScanCandidate cc=candidates.get(candidates.size()-1); cc.group=x.optString("lSecVal",x.optString("sectorName","")); }
                }
            }
        } catch(Exception e) { diag.append("MarketWatch=").append(e.getMessage()==null?"ERR":e.getMessage()).append("; "); }

        // Secondary source: today's closing price for all instruments.
        // This is a separate official CDN endpoint and does not depend on MarketWatch.
        if(candidates.isEmpty()){
            sourceUsed="ClosingPriceDailyAllInst";
            try {
                JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyAllInst"));
                JSONArray a=null;
                String[] keys={"closingPriceDailyAllInst","closingPriceDaily","data","items"};
                for(String k:keys){ JSONArray z=o.optJSONArray(k); if(z!=null){a=z;break;} }
                if(a!=null){
                    for(int i=0;i<a.length();i++){
                        JSONObject x=a.optJSONObject(i); if(x==null) continue;
                        String code=x.optString("insCode",x.optString("insCode1",""));
                        String sym=x.optString("lVal18AFC",x.optString("l18",x.optString("symbol",x.optString("lVal30",""))));
                        double close=num(x,"pClosing","pc","priceClosing");
                        double last=num(x,"pDrCotVal","pl","last","priceLast");
                        double yesterday=num(x,"priceYesterday","py","yClose");
                        double vol=num(x,"qTotTran5J","tvol","volume");
                        double value=num(x,"qTotCap","tval","value");
                        addCandidate(candidates,code,sym,close,last,yesterday,vol,value);
                        if(!candidates.isEmpty()){ ScanCandidate cc=candidates.get(candidates.size()-1); cc.group=x.optString("lSecVal",x.optString("sectorName","")); }
                    }
                }
            } catch(Exception e) { diag.append("ClosingPriceDailyAllInst=").append(e.getMessage()==null?"ERR":e.getMessage()).append("; "); }
        }

        // Third source: market-wide حقیقی/حقوقی snapshot. This endpoint is typically
        // available even when MarketWatch is empty. It provides one row per active
        // instrument, so it is a much better fallback than guessing a fixed symbol list.
        if(candidates.isEmpty()){
            sourceUsed="ClientTypeAll";
            try {
                JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeAll"));
                JSONArray a=o.optJSONArray("clientTypeAllDto");
                if(a!=null){
                    for(int i=0;i<a.length();i++){
                        JSONObject x=a.optJSONObject(i); if(x==null) continue;
                        String code=x.optString("insCode",x.optString("insCode1",""));
                        if(code==null || code.trim().isEmpty()) continue;
                        double buyI=num(x,"buy_I_Volume","buyIVolume");
                        double buyN=num(x,"buy_N_Volume","buyNVolume");
                        double sellI=num(x,"sell_I_Volume","sellIVolume");
                        double sellN=num(x,"sell_N_Volume","sellNVolume");
                        double activity=buyI+buyN+sellI+sellN;
                        if(activity<=0) continue;
                        // No quote fields here; rank by traded volume/activity and let
                        // the full analyzer fetch the actual price history afterwards.
                        String sym=x.optString("lVal18AFC",x.optString("l18",x.optString("symbol","")));
                        double fast=Math.log10(Math.max(1.0,activity));
                        candidates.add(new ScanCandidate(code,sym,fast,0,activity,0));
                    }
                }
            } catch(Exception e) { diag.append("ClientTypeAll=").append(e.getMessage()==null?"ERR":e.getMessage()).append("; "); }
        }

        if(candidates.isEmpty()) throw new Exception("منبع کل بازار در دسترس نیست؛ دریافت نمادهای فعال از TSETMC انجام نشد | "+diag.toString());

        // If the all-instruments endpoint does not carry symbol names, resolve names only
        // for the most active candidates rather than making thousands of requests.
        Collections.sort(candidates,(u,v)->Double.compare(v.fast,u.fast));
        int resolveCount=Math.min(24,candidates.size());
        ExecutorService namePool=Executors.newFixedThreadPool(4);
        List<Future<?>> nameJobs=new ArrayList<>();
        for(int i=0;i<resolveCount;i++){
            final ScanCandidate c=candidates.get(i);
            if(c.symbol==null || c.symbol.trim().isEmpty() || c.symbol.equals(c.code)){
                nameJobs.add(namePool.submit(()->resolveCandidateName(c)));
            }
        }
        for(Future<?> f:nameJobs){try{f.get();}catch(Exception ignored){}}
        namePool.shutdown();
        candidates.removeIf(c -> c.symbol==null || c.symbol.trim().isEmpty() || c.symbol.equals(c.code));
        if(candidates.isEmpty()) throw new Exception("نمادهای فعال پیدا شدند اما نام نمادها از TSETMC قابل دریافت نبود");

        Collections.sort(candidates,(u,v)->Double.compare(v.fast,u.fast));

        // Resolve industry/sector only for a bounded set when the source did not provide it.
        // This keeps the scan broad without creating hundreds of TSETMC requests.
        int sectorResolveCount=Math.min(80,candidates.size());
        ExecutorService sectorPool=Executors.newFixedThreadPool(6);
        List<Future<?>> sectorJobs=new ArrayList<>();
        for(int i=0;i<sectorResolveCount;i++){
            final ScanCandidate c=candidates.get(i);
            if(c.group==null || c.group.trim().isEmpty()){
                sectorJobs.add(sectorPool.submit(()->resolveCandidateSector(c)));
            }
        }
        for(Future<?> f:sectorJobs){try{f.get();}catch(Exception ignored){}}
        sectorPool.shutdown();

        // Diversified universe: do not let a handful of mega-caps dominate the scan.
        // Pick up to 2 liquid names from each industry, then fill remaining slots by rank.
        List<ScanCandidate> selected=diversifyCandidates(candidates,30,2);
        int fullCount=selected.size();
        MarketRegime sharedMarket=getMarketRegime();
        ExecutorService pool=Executors.newFixedThreadPool(5);
        List<Future<String>> futures=new ArrayList<>();
        for(int i=0;i<fullCount;i++){
            final ScanCandidate c=selected.get(i);
            futures.add(pool.submit(()->{
                try{return analyzeInsCode(c.code,c.symbol,sharedMarket);}catch(Exception e){return errorJson(e.getMessage()==null?"خطا":e.getMessage());}
            }));
        }
        List<JSONObject> results=new ArrayList<>();
        java.util.HashMap<String,String> groupByCode=new java.util.HashMap<>();
        for(ScanCandidate c:selected) groupByCode.put(c.code,(c.group==null||c.group.trim().isEmpty())?"سایر":c.group.trim());
        for(Future<String> f:futures){try{JSONObject r=new JSONObject(f.get());if(r.optBoolean("ok",false)){String g=groupByCode.get(r.optString("insCode","")); if(g!=null) r.put("group",g); results.add(r);}}catch(Exception ignored){}}
        pool.shutdown();
        final boolean longMode = "long".equalsIgnoreCase(scanMode);
        final boolean monthMode = "month".equalsIgnoreCase(scanMode);
        final boolean quarterMode = "quarter".equalsIgnoreCase(scanMode);
        String scoreKey = longMode ? "long_term_score" : monthMode ? "one_month_score" : quarterMode ? "three_month_score" : "score";
        Collections.sort(results,(u,v)->Integer.compare(v.optInt(scoreKey,0),u.optInt(scoreKey,0)));
        JSONArray top=new JSONArray();
        int limit=Math.min(20,results.size());
        for(int i=0;i<limit;i++) top.put(results.get(i));
        JSONObject out=new JSONObject();
        out.put("ok",true); out.put("market_symbols",candidates.size()); out.put("diversified_candidates",selected.size()); out.put("full_analyzed",results.size()); out.put("results",top);
        String modeOut = longMode?"long":monthMode?"month":quarterMode?"quarter":"short";
        out.put("mode",modeOut);
        out.put("source",sourceUsed);
        String note = longMode ? "حالت بلندمدت بر اساس روند ۲۰۰ روزه، بازده چندماهه و پایداری حرکت رتبه‌بندی شده است؛ امتیاز تضمین سود نیست." :
                monthMode ? "افق یک‌ماهه بر اساس روند ۲۱ روزه، مومنتوم، قدرت روند، نقدینگی و فاصله از هدف رتبه‌بندی شده است؛ امتیاز تضمین سود نیست." :
                quarterMode ? "افق سه‌ماهه بر اساس روند ۶۳ روزه، ساختار قیمت، مومنتوم، نقدینگی و قدرت روند رتبه‌بندی شده است؛ امتیاز تضمین سود نیست." :
                "حالت کوتاه‌مدت بر اساس مومنتوم، حجم، نقدینگی، شکست مقاومت و ریسک رتبه‌بندی شده است؛ «خروج» هدف اول و سود آن نسبت به قیمت ورود نمایش داده می‌شود.";
        out.put("note",note);
        return out.toString();
    }


    private String backtestMarketInternal() throws Exception {
        List<ScanCandidate> candidates = getBacktestCandidates(30);
        if(candidates.size()<10) throw new Exception("نماد فعال کافی برای بک‌تست پیدا نشد");
        final int minHistory=100;
        ExecutorService pool=Executors.newFixedThreadPool(4);
        List<Future<BacktestSymbol>> jobs=new ArrayList<>();
        for(ScanCandidate c:candidates) jobs.add(pool.submit(() -> loadBacktestSymbol(c)));
        List<BacktestSymbol> symbols=new ArrayList<>();
        for(Future<BacktestSymbol> f:jobs){try{BacktestSymbol b=f.get(); if(b!=null && b.rows.size()>=minHistory) symbols.add(b);}catch(Exception ignored){}}
        pool.shutdown();
        if(symbols.size()<10) throw new Exception("تاریخچه کافی برای بک‌تست در دسترس نیست");

        List<IndexPoint> index=loadIndexHistory();
        JSONObject out=new JSONObject(); out.put("ok",true); out.put("symbols",symbols.size()); out.put("requested_symbols",candidates.size()); out.put("days",260);
        out.put("short",runHorizonBacktest(symbols,index,10));
        out.put("month",runHorizonBacktest(symbols,index,21));
        out.put("quarter",runHorizonBacktest(symbols,index,63));
        out.put("note","بک‌تست هر افق مستقل انجام می‌شود و سیگنال هر روز فقط با داده‌های همان روز و قبل از آن ساخته می‌شود. کوتاه‌مدت ۱۰، یک‌ماهه ۲۱ و سه‌ماهه ۶۳ روز معاملاتی بعد بررسی می‌شوند. ۳۰ نماد فعال فعلی نمونه آزمون هستند؛ بنابراین نتیجه برای کل بازار یا آینده تضمین نیست.");
        return out.toString();
    }

    private JSONObject runHorizonBacktest(List<BacktestSymbol> symbols,List<IndexPoint> index,int horizon){
        int total=0,wins=0,stops=0,timeout=0; double grossProfit=0,grossLoss=0,sumReturn=0;
        double maxDD=0,equity=100000.0,peak=equity;
        int[] bucketN=new int[5], bucketW=new int[5];
        for(BacktestSymbol b:symbols){
            int start=Math.max(80,b.rows.size()-260);
            for(int i=start;i<b.rows.size()-horizon;i++){
                Row cur=b.rows.get(i); if(cur.date==0) continue;
                int marketScore=historicalMarketScore(index,cur.date);
                HistoricalSignal sig=evaluateHistoricalHorizonSignal(b.rows,i,b.clients,marketScore,horizon);
                if(sig.action!=1) continue;
                total++;
                int bi=sig.score>=90?4:sig.score>=85?3:sig.score>=80?2:sig.score>=75?1:0; bucketN[bi]++;
                boolean win=false,stop=false; int end=Math.min(b.rows.size()-1,i+horizon);
                for(int j=i+1;j<=end;j++){
                    Row r=b.rows.get(j);
                    if(r.low<=sig.stop && r.high>=sig.target){stop=true;break;} // conservative: stop first
                    if(r.low<=sig.stop){stop=true;break;}
                    if(r.high>=sig.target){win=true;break;}
                }
                double ret;
                if(stop){ret=(sig.stop-cur.close)/cur.close*100.0;stops++;grossLoss+=-ret;}
                else if(win){ret=(sig.target-cur.close)/cur.close*100.0;wins++;grossProfit+=ret;bucketW[bi]++;}
                else {Row endRow=b.rows.get(end);ret=(endRow.close-cur.close)/cur.close*100.0;timeout++;if(ret>0)grossProfit+=ret;else grossLoss+=-ret;}
                sumReturn+=ret; equity*=1.0+ret/100.0; peak=Math.max(peak,equity); maxDD=Math.max(maxDD,(peak-equity)/peak*100.0);
            }
        }
        JSONObject o=new JSONObject();
        try{
            o.put("horizon",horizon); o.put("signals",total); o.put("wins",wins); o.put("stops",stops); o.put("timeouts",timeout);
            o.put("win_rate",total>0?wins*100.0/total:0); o.put("avg_return",total>0?sumReturn/total:0); o.put("profit_factor",grossLoss>0?grossProfit/grossLoss:(grossProfit>0?99:0)); o.put("max_drawdown",maxDD);
            JSONArray buckets=new JSONArray(); String[] labels={"70–74","75–79","80–84","85–89","90+"};
            for(int i=0;i<5;i++){JSONObject x=new JSONObject();x.put("label",labels[i]);x.put("count",bucketN[i]);x.put("wins",bucketW[i]);x.put("win_rate",bucketN[i]>0?bucketW[i]*100.0/bucketN[i]:0);buckets.put(x);} o.put("buckets",buckets);
        }catch(Exception ignored){}
        return o;
    }

    private List<ScanCandidate> getBacktestCandidates(int limit) throws Exception {
        List<ScanCandidate> list=new ArrayList<>();
        try{
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeAll"));
            JSONArray a=o.optJSONArray("clientTypeAllDto");
            if(a!=null) for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                String code=x.optString("insCode",x.optString("insCode1","")); if(code.length()==0) continue;
                double act=num(x,"buy_I_Volume","buyIVolume")+num(x,"buy_N_Volume","buyNVolume")+num(x,"sell_I_Volume","sellIVolume")+num(x,"sellNVolume","sell_N_Volume");
                if(act<=0) continue; String sym=x.optString("lVal18AFC",x.optString("l18",x.optString("symbol","")));
                list.add(new ScanCandidate(code,sym,Math.log10(Math.max(1,act)),0,act,0));
            }
        }catch(Exception ignored){}
        Collections.sort(list,(a,b)->Double.compare(b.fast,a.fast));
        int n=Math.min(limit,list.size());
        List<ScanCandidate> out=new ArrayList<>(); for(int i=0;i<n;i++){ScanCandidate c=list.get(i); if(c.symbol==null||c.symbol.trim().isEmpty()||c.symbol.equals(c.code)) resolveCandidateName(c); if(c.symbol!=null&&!c.symbol.trim().isEmpty()&&!c.symbol.equals(c.code)) out.add(c);}
        return out;
    }

    private BacktestSymbol loadBacktestSymbol(ScanCandidate c){
        try{
            JSONObject h=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/"+c.code+"/0"));
            JSONArray raw=h.optJSONArray("closingPriceDaily"); if(raw==null) return null;
            List<Row> rows=new ArrayList<>();
            for(int i=0;i<raw.length();i++){JSONObject x=raw.optJSONObject(i);if(x==null)continue;double close=num(x,"pClosing","close","Close"),open=num(x,"priceFirst","pOpen","open","Open"),high=num(x,"priceMax","pHigh","high","High"),low=num(x,"priceMin","pLow","low","Low"),vol=num(x,"qTotTran5J","volume","Volume");if(close>0)rows.add(new Row(close,open,high,low,vol,x.optInt("dEven",0)));}
            Collections.sort(rows,Comparator.comparingInt(a->a.date)); if(rows.size()<80)return null;
            java.util.Map<Integer,ClientData> cm=new java.util.HashMap<>();
            try{JSONObject co=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/"+c.code));JSONArray ca=co.optJSONArray("clientType");if(ca!=null)for(int i=0;i<ca.length();i++){JSONObject x=ca.optJSONObject(i);if(x==null)continue;ClientData d=new ClientData();d.buyIValue=x.optDouble("buy_I_Value",0);d.sellIValue=x.optDouble("sell_I_Value",0);d.buyICount=x.optDouble("buy_I_Count",0);d.sellICount=x.optDouble("sell_I_Count",0);d.date=x.optInt("recDate",0);cm.put(d.date,d);}}catch(Exception ignored){}
            return new BacktestSymbol(c,rows,cm);
        }catch(Exception e){return null;}
    }

    private List<IndexPoint> loadIndexHistory(){
        List<IndexPoint> out=new ArrayList<>();
        try{JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/Index/GetIndexB2History/32097828799138957"));JSONArray a=o.optJSONArray("indexB2");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int d=x.optInt("dEven",x.optInt("recDate",0));double v=num(x,"xValue","pClosing","xClose","close","indexValue","value");if(d>0&&v>0)out.add(new IndexPoint(d,v));}}catch(Exception ignored){}
        Collections.sort(out,Comparator.comparingInt(a->a.date)); return out;
    }

    private int historicalMarketScore(List<IndexPoint> a,int date){
        if(a.size()<25)return 5; int idx=-1; for(int i=0;i<a.size();i++){if(a.get(i).date<=date)idx=i;else break;} if(idx<24)return 5;
        double now=a.get(idx).value,sum=0;for(int i=idx-19;i<=idx;i++)sum+=a.get(i).value;double m20=sum/20.0,old=a.get(idx-20).value;
        if(now>m20&&now>old*1.02)return 10;if(now>m20&&now>old)return 8;if(now>=old*.98&&now<=old*1.02)return 5;if(now<m20&&now<old*.98)return 0;return 2;
    }

    private HistoricalSignal evaluateHistoricalSignal(List<Row>a,int n,java.util.Map<Integer,ClientData> clients,int marketScore){
        if(n<60)return new HistoricalSignal(0,0,0,0);
        Row cur=a.get(n);double ma20=avgClose(a,n,20),ma50=avgClose(a,n,50),avgVol20=avgVol(a,n,20),rsi=rsi(a,n,14),macd=ema(a,n,12)-ema(a,n,26),prevMacd=ema(a,n-1,12)-ema(a,n-1,26),adx=adx(a,n,14),mfi=mfi(a,n,14),resistance=highest(a,n-1,20);int score=0;
        if(cur.close>ma20)score+=5;if(cur.close>ma50)score+=5;if(ma20>ma50)score+=5;if(ma20>avgClose(a,n-1,20))score+=5;
        if(rsi>=50&&rsi<=65)score+=5;else if(rsi>65&&rsi<=70)score+=3;if(macd>0)score+=3;if(macd>prevMacd)score+=2;if(adx>=25)score+=5;else if(adx>=20)score+=3;
        double vr=avgVol20>0?cur.vol/avgVol20:0;boolean pos=cur.close>=cur.open&&cur.close>=a.get(n-1).close;if(pos){if(vr>=2)score+=15;else if(vr>=1.5)score+=12;else if(vr>=1.2)score+=8;else if(vr>=1)score+=4;}
        if(cur.close>resistance&&cur.close>=cur.open&&cur.vol>=avgVol20*1.2)score+=15;else if(cur.close>resistance&&cur.close>=cur.open)score+=8;
        ClientData ct=clients.get(cur.date);double bp=0,flow=0; if(ct!=null){double ab=ct.buyIValue>0&&ct.buyICount>0?ct.buyIValue/ct.buyICount:0,as=ct.sellIValue>0&&ct.sellICount>0?ct.sellIValue/ct.sellICount:0;bp=as>0?ab/as:0;flow=ct.buyIValue-ct.sellIValue;double p=bp>=2?25:bp>=1.5?20:bp>=1.2?15:bp>=1?9:bp>=.8?4:0;double vp=vr>=3?25:vr>=2?20:vr>=1.5?15:vr>=1.2?9:0;double fiveF=0,fiveT=0;int posF=0,active=0;for(int j=n;j>=0&&active<5;j--){ClientData d=clients.get(a.get(j).date);if(d!=null){double f=d.buyIValue-d.sellIValue;fiveF+=f;fiveT+=d.buyIValue+d.sellIValue;if(f>0)posF++;active++;}}double flowStrength=fiveT>0?Math.max(0,Math.min(25,(fiveF/fiveT)*250)):0;double persistence=active>0?posF/(double)active*25:0;double hot=Math.max(0,Math.min(100,p+vp+flowStrength+persistence));if(bp>0&&bp<.8)hot=Math.min(hot,35);if(flow<0)hot=Math.min(hot,45);if(hot>=80)score+=10;else if(hot>=60)score+=8;else if(hot>=40)score+=5;}
        if(mfi>=60)score+=5;else if(mfi>=50)score+=3;score+=marketScore;
        double atr=atr(a,n,14),struct=lowest(a,n,20),atrStop=Math.max(0,cur.close-1.5*atr),stop=Math.max(struct,atrStop);if(stop<=0||stop>=cur.close)stop=atrStop;double risk=cur.close-stop;risk=risk>0?risk:cur.close*.08;double riskPct=risk/cur.close*100;if(riskPct<=4)score+=10;else if(riskPct<=6)score+=8;else if(riskPct<=8)score+=6;else if(riskPct<=12)score+=3;
        score=Math.max(0,Math.min(100,score));int action=score>=70?1:0;if(bp>0&&bp<.8){score=Math.min(score,69);action=0;}if(bp>0&&bp<.65&&flow<=0){score=Math.min(score,54);action=0;}if(rsi>75){score=Math.min(score,69);action=0;}if(marketScore<=2){score=Math.min(score,69);action=0;}if(bp>0&&bp<.8&&cur.close<ma20)action=0;
        return new HistoricalSignal(score,action,stop,cur.close+1.5*risk);
    }

    private HistoricalSignal evaluateHistoricalHorizonSignal(List<Row>a,int n,java.util.Map<Integer,ClientData> clients,int marketScore,int days){
        if(n<days+20)return new HistoricalSignal(0,0,0,0);
        Row cur=a.get(n); int ref=n-days;
        double ret=a.get(ref).close>0?(cur.close/a.get(ref).close-1)*100:0;
        double maShort=avgClose(a,n,Math.max(10,days/2)), maLong=avgClose(a,n,days), maPrev=avgClose(a,Math.max(0,n-Math.max(10,days/2)),Math.max(10,days/2));
        double rsi=rsi(a,n,14),adx=adx(a,n,14),mfi=mfi(a,n,14),vr=avgVol(a,n,20)>0?cur.vol/avgVol(a,n,20):0;
        double high=highest(a,n,days),low=lowest(a,n,days),position=high>low?(cur.close-low)/(high-low):0.5;
        ClientData ct=clients.get(cur.date); double bp=0,flow=0;
        if(ct!=null){double ab=ct.buyIValue>0&&ct.buyICount>0?ct.buyIValue/ct.buyICount:0,as=ct.sellIValue>0&&ct.sellICount>0?ct.sellIValue/ct.sellICount:0;bp=as>0?ab/as:0;flow=ct.buyIValue-ct.sellIValue;}
        int score=0;
        if(cur.close>maLong)score+=12;else if(cur.close>maLong*.98)score+=7;
        if(maShort>maLong)score+=10;else if(maShort>=maLong*.99)score+=5;
        if(maShort>maPrev)score+=8;
        double retGood=days<=21?5:10;if(ret>=retGood)score+=12;else if(ret>0)score+=7;else if(ret>-5)score+=3;
        if(rsi>=50&&rsi<=68)score+=5;else if(rsi>68&&rsi<=75)score+=3;if(adx>=25)score+=3;else if(adx>=20)score+=2;
        if(bp>=1.10)score+=10;else if(bp>=.90)score+=7;else if(bp>=.80)score+=4;if(flow>0)score+=5;if(vr>=1.2)score+=3;if(mfi>=55)score+=2;
        if(position>=.65)score+=8;else if(position>=.45)score+=5;double atrPct=cur.close>0?atr(a,n,14)/cur.close*100:10;if(atrPct<=6)score+=5;else if(atrPct<=9)score+=3;
        if(marketScore>=8)score+=10;else if(marketScore>=5)score+=6;
        if(bp>0&&bp<.80)score=Math.min(score,64);if(bp>0&&bp<.65&&flow<=0)score=Math.min(score,54);if(flow<0&&bp>0&&bp<.90)score=Math.min(score,69);if(marketScore<=2)score=Math.min(score,69);if(rsi>78)score=Math.min(score,69);
        score=Math.max(0,Math.min(100,score)); int action=score>=75?1:0;
        double risk=Math.max(cur.close*.08,Math.max(0,cur.close-Math.max(low,cur.close-1.5*atr(a,n,14))));
        if(risk<=0)risk=cur.close*.08;
        double targetPct=days<=21?Math.max(0.04,Math.min(0.18,Math.max(0,ret)*.55/100.0+.035)):Math.max(0.08,Math.min(0.30,Math.max(0,ret)*.55/100.0+.10));
        double target=cur.close*(1+targetPct);
        return new HistoricalSignal(score,action,cur.close-risk,target);
    }

    private HorizonScore calcHorizonScore(List<Row> rows,int n,int days,double buyerPower,double realMoneyFlow,int marketScore){
        int score=0; List<String> reasons=new ArrayList<>();
        if(n<days+20) return new HorizonScore(0,"داده کافی نیست",rows.get(n).close,0,reasons);
        Row cur=rows.get(n);
        int ref=n-days;
        double ret=(rows.get(ref).close>0)?(cur.close/rows.get(ref).close-1)*100:0;
        double maShort=avgClose(rows,n,Math.max(10,days/2));
        double maLong=avgClose(rows,n,days);
        double maPrev=avgClose(rows,Math.max(0,n-Math.max(10,days/2)),Math.max(10,days/2));
        double rsi=rsi(rows,n,14), adx=adx(rows,n,14), mfi=mfi(rows,n,14);
        double vr=avgVol(rows,n,20)>0?cur.vol/avgVol(rows,n,20):0;
        double high=highest(rows,n,days), low=lowest(rows,n,days);
        double position=high>low?(cur.close-low)/(high-low):0.5;

        // Price/trend: 30 points
        if(cur.close>maLong) score+=12; else if(cur.close>maLong*0.98) score+=7;
        if(maShort>maLong) score+=10; else if(maShort>=maLong*0.99) score+=5;
        if(maShort>maPrev) score+=8;
        // Return/momentum: 20 points
        double retGood=days<=21?5:10;
        if(ret>=retGood) score+=12; else if(ret>0) score+=7; else if(ret>-5) score+=3;
        if(rsi>=50&&rsi<=68) score+=5; else if(rsi>68&&rsi<=75) score+=3;
        if(adx>=25) score+=3; else if(adx>=20) score+=2;
        // Liquidity/flow: 20 points, buyer power is a gate rather than a bonus-only input
        if(buyerPower>=1.10) score+=10; else if(buyerPower>=0.90) score+=7; else if(buyerPower>=0.80) score+=4;
        if(realMoneyFlow>0) score+=5;
        if(vr>=1.2) score+=3;
        if(mfi>=55) score+=2;
        // Structure / position: 20 points
        if(position>=0.65) score+=8; else if(position>=0.45) score+=5;
        double atrPct=cur.close>0?atr(rows,n,14)/cur.close*100:10;
        if(atrPct<=6) score+=5; else if(atrPct<=9) score+=3;
        if(marketScore>=8) score+=10; else if(marketScore>=5) score+=6;

        // Hard consistency gates: a medium/long horizon should not call a weak money-flow setup "strong".
        if(buyerPower>0 && buyerPower<0.80){score=Math.min(score,64); reasons.add("قدرت خریدار حقیقی ضعیف است");}
        if(buyerPower>0 && buyerPower<0.65 && realMoneyFlow<=0) score=Math.min(score,54);
        if(realMoneyFlow<0 && buyerPower>0 && buyerPower<0.90) score=Math.min(score,69);
        if(marketScore<=2) score=Math.min(score,69);
        if(rsi>78) score=Math.min(score,69);
        score=(int)Math.max(0,Math.min(100,score));

        String action=score>=75?"خرید/مناسب":score>=60?"قابل بررسی":"عدم ورود";
        if(ret>0) reasons.add("بازده افق " + days + " روزه مثبت است");
        else reasons.add("بازده افق " + days + " روزه ضعیف است");
        if(cur.close>maLong) reasons.add("قیمت بالای میانگین افق قرار دارد"); else reasons.add("قیمت زیر میانگین افق است");
        if(adx>=25) reasons.add("قدرت روند مناسب است");
        if(mfi>=55) reasons.add("MFI از ورود نقدینگی حمایت می‌کند");
        double target=cur.close*(1+(days<=21?Math.max(0.04,Math.min(0.18,Math.max(0,ret)*0.55/100.0+0.035)):Math.max(0.08,Math.min(0.30,Math.max(0,ret)*0.55/100.0+0.10))));
        double expected=cur.close>0?(target/cur.close-1)*100:0;
        return new HorizonScore(score,action,target,expected,reasons);
    }

    private void resolveCandidateSector(ScanCandidate c){
        try{
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentIdentity/"+c.code));
            JSONObject x=o.optJSONObject("instrumentIdentity");
            if(x==null) x=o.optJSONObject("identity");
            if(x!=null){
                JSONObject sec=x.optJSONObject("sector");
                if(sec!=null){
                    String g=sec.optString("lSecVal",sec.optString("cSecVal",""));
                    if(g!=null&&!g.trim().isEmpty()) c.group=g.trim();
                }
            }
        }catch(Exception ignored){}
    }

    private List<ScanCandidate> diversifyCandidates(List<ScanCandidate> all,int maxCount,int perGroup){
        List<ScanCandidate> out=new ArrayList<>();
        java.util.LinkedHashMap<String,Integer> used=new java.util.LinkedHashMap<>();
        // First pass: guarantee representation across industries.
        for(ScanCandidate c:all){
            if(out.size()>=maxCount) break;
            String g=(c.group==null||c.group.trim().isEmpty())?"سایر":c.group.trim();
            int n=used.containsKey(g)?used.get(g):0;
            if(n<perGroup){ out.add(c); used.put(g,n+1); }
        }
        // Second pass: use remaining capacity for the best-ranked names.
        if(out.size()<maxCount){
            java.util.HashSet<String> seen=new java.util.HashSet<>();
            for(ScanCandidate c:out) seen.add(c.code);
            for(ScanCandidate c:all){
                if(out.size()>=maxCount) break;
                if(seen.add(c.code)) out.add(c);
            }
        }
        return out;
    }

    private void resolveCandidateName(ScanCandidate c){
        try{
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentInfo/"+c.code));
            JSONObject x=o.optJSONObject("instrumentInfo");
            if(x==null) x=o.optJSONObject("instrument");
            if(x!=null){
                String s=x.optString("lVal18AFC",x.optString("lVal18",x.optString("l18",x.optString("lVal30",""))));
                if(s!=null && !s.trim().isEmpty()) c.symbol=s.trim();
            }
        }catch(Exception ignored){}
    }

    private void addCandidate(List<ScanCandidate> list,String code,String sym,double close,double last,double yesterday,double vol,double value){
        if(code==null || code.length()==0 || close<=0) return;
        if(sym==null || sym.trim().isEmpty()) sym=code;
        double change=yesterday>0?(last-yesterday)/yesterday*100.0:0;
        double activity=value>0?Math.log10(value):0;
        double fast=50 + Math.max(-15,Math.min(15,change*3)) + Math.max(0,Math.min(15,activity-7));
        list.add(new ScanCandidate(code,sym,fast,value,vol,change));
    }
    private double toNum(String s){ try{return Double.parseDouble(s.trim().replace(",",""));}catch(Exception e){return 0;} }

    private ClientData getLatestClientType(String insCode, int date) {
        try {
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/"+insCode));
            JSONArray a=o.optJSONArray("clientType"); if(a==null) return null;
            JSONObject best=null; int bestDate=0;
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                int d=x.optInt("recDate",0);
                if(d==date){best=x; break;}
                if(d<=date && d>bestDate){best=x; bestDate=d;}
            }
            if(best==null) return null;
            ClientData c=new ClientData();
            c.buyIValue=best.optDouble("buy_I_Value",0); c.sellIValue=best.optDouble("sell_I_Value",0);
            c.buyICount=best.optDouble("buy_I_Count",0); c.sellICount=best.optDouble("sell_I_Count",0);
            c.buyIVolume=best.optDouble("buy_I_Volume",0); c.sellIVolume=best.optDouble("sell_I_Volume",0);
            c.date=best.optInt("recDate",0); return c;
        } catch(Exception e) { return null; }
    }

    private MarketRegime getMarketRegime() {
        // TSETMC's official Total Index code. If the index endpoint is unavailable,
        // keep a neutral 5/10 instead of inventing a market condition.
        try {
            String url="https://cdn.tsetmc.com/api/Index/GetIndexB2History/32097828799138957";
            JSONObject o=new JSONObject(httpGet(url));
            JSONArray a=o.optJSONArray("indexB2");
            if(a==null || a.length()<25) return new MarketRegime(5,"خنثی (داده شاخص در دسترس نیست)");
            List<Double> closes=new ArrayList<>();
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                double v=num(x,"xValue","pClosing","xClose","close","indexValue","value");
                if(v>0) closes.add(v);
            }
            if(closes.size()<25) return new MarketRegime(5,"خنثی (داده شاخص ناقص است)");
            double now=closes.get(closes.size()-1);
            double m20=0; int s=Math.max(0,closes.size()-20); for(int i=s;i<closes.size();i++)m20+=closes.get(i); m20/=closes.size()-s;
            double old=closes.get(Math.max(0,closes.size()-21));
            if(now>m20 && now>old*1.02) return new MarketRegime(10,"صعودی قوی");
            if(now>m20 && now>old) return new MarketRegime(8,"صعودی");
            if(now>=old*0.98 && now<=old*1.02) return new MarketRegime(5,"خنثی");
            if(now<m20 && now<old*0.98) return new MarketRegime(0,"نزولی شدید");
            return new MarketRegime(2,"نزولی");
        } catch(Exception e) { return new MarketRegime(5,"خنثی (شاخص قابل دریافت نیست)"); }
    }

    private double clamp(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
    private double num(JSONObject x,String... keys){for(String k:keys) if(x.has(k)) return x.optDouble(k,0); return 0;}
    private double avgClose(List<Row> a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z+=a.get(i).close;return z/(end-s+1);}
    private double avgVol(List<Row> a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z+=a.get(i).vol;return z/(end-s+1);}
    private double highest(List<Row>a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z=Math.max(z,a.get(i).high);return z;}
    private double lowest(List<Row>a,int end,int len){int s=Math.max(0,end-len+1);double z=Double.MAX_VALUE;for(int i=s;i<=end;i++)z=Math.min(z,a.get(i).low);return z==Double.MAX_VALUE?0:z;}
    private double rsi(List<Row>a,int end,int len){if(end<len)return 50;double g=0,l=0;for(int i=end-len+1;i<=end;i++){double d=a.get(i).close-a.get(i-1).close;if(d>0)g+=d;else l-=d;}if(l==0)return 100;double rs=(g/len)/(l/len);return 100-(100/(1+rs));}
    private double adx(List<Row>a,int end,int len){
        if(end < len*2) return 0;
        double trSum=0, plusSum=0, minusSum=0;
        double adxSum=0, adxValue=0; int dxCount=0;
        double prevTr=0, prevPlus=0, prevMinus=0;
        for(int i=1;i<=end;i++){
            Row r=a.get(i), p=a.get(i-1);
            double up=r.high-p.high, down=p.low-r.low;
            double tr=Math.max(r.high-r.low,Math.max(Math.abs(r.high-p.close),Math.abs(r.low-p.close)));
            double plus=(up>down && up>0)?up:0;
            double minus=(down>up && down>0)?down:0;
            if(i<=len){trSum+=tr; plusSum+=plus; minusSum+=minus; continue;}
            if(i==len+1){
                prevTr=trSum-trSum/len+tr;
                prevPlus=plusSum-plusSum/len+plus;
                prevMinus=minusSum-minusSum/len+minus;
            } else {
                prevTr=prevTr-prevTr/len+tr;
                prevPlus=prevPlus-prevPlus/len+plus;
                prevMinus=prevMinus-prevMinus/len+minus;
            }
            double pdi=prevTr>0?100*prevPlus/prevTr:0;
            double mdi=prevTr>0?100*prevMinus/prevTr:0;
            double dx=(pdi+mdi)>0?100*Math.abs(pdi-mdi)/(pdi+mdi):0;
            if(dxCount<len){adxSum+=dx; dxCount++; if(dxCount==len) adxValue=adxSum/len;}
            else adxValue=adxValue-(adxValue/len)+dx;
        }
        return dxCount>=len?adxValue:0;
    }
    private double mfi(List<Row>a,int end,int len){
        if(end<len)return 50; double pos=0,neg=0;
        int s=Math.max(1,end-len+1);
        for(int i=s;i<=end;i++){Row r=a.get(i),p=a.get(i-1); double tp=(r.high+r.low+r.close)/3.0; double ptp=(p.high+p.low+p.close)/3.0; double flow=tp*r.vol;
            if(tp>ptp)pos+=flow; else if(tp<ptp)neg+=flow;
        }
        if(neg<=0)return 100; double ratio=pos/neg; return 100-(100/(1+ratio));
    }
    private double ema(List<Row>a,int end,int len){int s=Math.max(0,end-len*3);double e=a.get(s).close;double k=2.0/(len+1);for(int i=s+1;i<=end;i++)e=a.get(i).close*k+e*(1-k);return e;}
    private double atr(List<Row>a,int end,int len){int s=Math.max(1,end-len+1);double z=0;for(int i=s;i<=end;i++){Row r=a.get(i),p=a.get(i-1);z+=Math.max(r.high-r.low,Math.max(Math.abs(r.high-p.close),Math.abs(r.low-p.close)));}return z/(end-s+1);}
    private String errorJson(String msg){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",msg);return o.toString();}catch(Exception e){return "{\"ok\":false,\"error\":\"خطا\"}";}}
    private static class ScanCandidate{String code,symbol,group;double fast,value,vol,change;ScanCandidate(String c,String s,double f,double v,double q,double ch){code=c;symbol=s;fast=f;value=v;vol=q;change=ch;}}
    private static class Row{double close,open,high,low,vol;int date;Row(double c,double o,double h,double l,double v,int d){close=c;open=o;high=h;low=l;vol=v;date=d;}}
    private static class ClientData{double buyIValue,sellIValue,buyICount,sellICount,buyIVolume,sellIVolume;int date;}
    private static class MarketRegime{int score;String label;MarketRegime(int s,String l){score=s;label=l;}}
    private static class BacktestSymbol{ScanCandidate c;List<Row> rows;java.util.Map<Integer,ClientData> clients;BacktestSymbol(ScanCandidate c,List<Row> r,java.util.Map<Integer,ClientData> m){this.c=c;rows=r;clients=m;}}
    private static class IndexPoint{int date;double value;IndexPoint(int d,double v){date=d;value=v;}}
    private static class HistoricalSignal{int score,action;double stop,target;HistoricalSignal(int s,int a,double st,double t){score=s;action=a;stop=st;target=t;}}
    private static class HorizonScore{int score;String action;double target,expectedReturn;List<String> reasons;HorizonScore(int s,String a,double t,double r,List<String> rs){score=s;action=a;target=t;expectedReturn=r;reasons=rs;}}

    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null)webView.destroy();super.onDestroy();}
}
