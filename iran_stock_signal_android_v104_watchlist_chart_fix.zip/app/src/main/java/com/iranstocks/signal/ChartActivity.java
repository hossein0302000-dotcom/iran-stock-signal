package com.iranstocks.signal;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ChartActivity extends Activity {
    private TextView status;
    private CandleView chart;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String symbol=getIntent().getStringExtra("symbol");
        String insCode=getIntent().getStringExtra("insCode");
        if(symbol==null||symbol.trim().isEmpty()) symbol="نماد";
        if(insCode==null) insCode="";

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,12,12,12);
        TextView title=new TextView(this);
        title.setText("📈 نمودار کندلی «"+symbol+"»");
        title.setTextSize(20); title.setTextColor(Color.rgb(25,25,25));
        title.setPadding(8,8,8,14); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        status=new TextView(this); status.setText("در حال دریافت ۱۲۰ روز داده از TSETMC...");
        status.setTextSize(13); status.setPadding(8,0,8,8); root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        chart=new CandleView(); root.addView(chart,new LinearLayout.LayoutParams(-1,0,1f));
        setContentView(root);

        final String code=insCode.trim();
        if(code.isEmpty()){status.setText("کد نماد در دسترس نیست");return;}
        new Thread(() -> {
            try { JSONArray rows=loadHistory(code); runOnUiThread(() -> render(rows)); }
            catch(Exception e){runOnUiThread(() -> status.setText("خطا در دریافت نمودار: "+(e.getMessage()==null?"نامشخص":e.getMessage())));}
        },"ChartLoader").start();
    }

    private JSONArray loadHistory(String code) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/"+code+"/0").openConnection();
        try {
            c.setRequestMethod("GET"); c.setConnectTimeout(15000); c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            int rc=c.getResponseCode();
            BufferedReader br=new BufferedReader(new InputStreamReader(rc>=200&&rc<300?c.getInputStream():c.getErrorStream(),StandardCharsets.UTF_8));
            StringBuilder b=new StringBuilder(); String line; int chars=0;
            while((line=br.readLine())!=null){chars+=line.length(); if(chars>4_000_000) throw new Exception("پاسخ بیش از حد بزرگ است"); b.append(line);}
            br.close(); if(rc<200||rc>=300) throw new Exception("TSETMC HTTP "+rc);
            String body=b.toString().trim();
            JSONArray raw=null;
            if(body.startsWith("[")){ raw=new JSONArray(body); }
            else { JSONObject obj=new JSONObject(body); raw=obj.optJSONArray("closingPriceDaily"); }
            if(raw==null||raw.length()==0) throw new Exception("داده تاریخی یافت نشد"); return raw;
        } finally { c.disconnect(); }
    }

    private void render(JSONArray raw){
        try{
            List<JSONObject> rows=new ArrayList<>();
            for(int i=0;i<raw.length();i++){JSONObject x=raw.optJSONObject(i);if(x!=null)rows.add(x);}
            Collections.sort(rows,Comparator.comparingInt(a->a.optInt("dEven",0)));
            int from=Math.max(0,rows.size()-90); ArrayList<Candle> data=new ArrayList<>();
            for(int i=from;i<rows.size();i++){
                JSONObject x=rows.get(i);
                float o=(float)num(x,"priceFirst","pOpen","open","Open");
                float h=(float)num(x,"priceMax","pHigh","high","High");
                float l=(float)num(x,"priceMin","pLow","low","Low");
                float cl=(float)num(x,"pClosing","close","Close");
                if(o<=0||h<=0||l<=0||cl<=0)continue;
                data.add(new Candle(o,h,l,cl,String.valueOf(x.optInt("dEven",0))));
            }
            if(data.isEmpty())throw new Exception("داده معتبر نمودار وجود ندارد");
            chart.setData(data); status.setText("۹۰ روز اخیر • کشیدن برای جابه‌جایی، دو انگشت برای زوم");
        }catch(Exception e){status.setText("خطا در ساخت نمودار: "+(e.getMessage()==null?"نامشخص":e.getMessage()));}
    }

    private double num(JSONObject o,String...keys){
        for(String k:keys)if(o.has(k)&&!o.isNull(k)){Object v=o.opt(k);if(v instanceof Number)return ((Number)v).doubleValue();try{return Double.parseDouble(String.valueOf(v));}catch(Exception ignored){}}
        return 0;
    }

    private static class Candle { final float o,h,l,c; final String label; Candle(float o,float h,float l,float c,String label){this.o=o;this.h=h;this.l=l;this.c=c;this.label=label;} }

    private class CandleView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); private final ArrayList<Candle> data=new ArrayList<>();
        private float scale=1f,offset=0f,lastX,initialSpan; private boolean moving,zooming;
        CandleView(){super(ChartActivity.this);p.setStrokeWidth(2f);setBackgroundColor(Color.WHITE);}
        void setData(List<Candle> d){data.clear();data.addAll(d);offset=0;scale=1f;invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);if(data.isEmpty())return;float w=getWidth(),h=getHeight();float left=45,right=10,top=15,bottom=30;float plotW=w-left-right,plotH=h-top-bottom;
            float min=Float.MAX_VALUE,max=-Float.MAX_VALUE;for(Candle x:data){min=Math.min(min,x.l);max=Math.max(max,x.h);}if(max<=min)return;float visible=Math.max(8,Math.min(data.size(),data.size()/scale));int start=Math.max(0,Math.min(data.size()-(int)visible,(int)offset));int end=Math.min(data.size(),start+(int)visible);float step=plotW/Math.max(1,end-start),body=Math.max(2,step*.58f);
            p.setStyle(Paint.Style.STROKE);p.setColor(Color.LTGRAY);p.setStrokeWidth(1);for(int g=0;g<=4;g++){float y=top+plotH*g/4f;c.drawLine(left,y,w-right,y,p);}p.setTextSize(11);p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.FILL);for(int g=0;g<=4;g++){float v=max-(max-min)*g/4f;c.drawText(String.format(java.util.Locale.US,"%.0f",v),2,top+plotH*g/4f+4,p);}
            for(int i=start;i<end;i++){Candle x=data.get(i);float xx=left+(i-start+.5f)*step;float yh=top+(max-x.h)/(max-min)*plotH,yl=top+(max-x.l)/(max-min)*plotH,yo=top+(max-x.o)/(max-min)*plotH,yc=top+(max-x.c)/(max-min)*plotH;boolean up=x.c>=x.o;p.setColor(up?Color.rgb(30,140,80):Color.rgb(205,65,65));p.setStrokeWidth(1.5f);c.drawLine(xx,yh,xx,yl,p);p.setStyle(Paint.Style.FILL);float y1=Math.min(yo,yc),y2=Math.max(yo,yc);c.drawRect(new RectF(xx-body/2,y1,xx+body/2,Math.max(y1+2,y2)),p);}
            p.setColor(Color.DKGRAY);p.setTextSize(10);p.setStyle(Paint.Style.FILL);if(end>start)c.drawText(data.get(end-1).label,left+plotW-55,h-8,p);
        }
        @Override public boolean onTouchEvent(MotionEvent e){int action=e.getActionMasked();if(action==MotionEvent.ACTION_DOWN){lastX=e.getX();moving=true;zooming=false;return true;}if(action==MotionEvent.ACTION_POINTER_DOWN&&e.getPointerCount()>=2){initialSpan=span(e);zooming=initialSpan>0;moving=false;return true;}if(action==MotionEvent.ACTION_MOVE){if(zooming&&e.getPointerCount()>=2){float s=span(e);if(s>0&&initialSpan>0){float factor=s/initialSpan;scale=Math.max(.5f,Math.min(6f,scale*factor));initialSpan=s;invalidate();}return true;}if(moving){float dx=e.getX()-lastX;float visible=Math.max(8,Math.min(data.size(),data.size()/scale));float step=(getWidth()-55)/Math.max(1,visible);offset-=dx/Math.max(1,step);offset=Math.max(0,Math.min(Math.max(0,data.size()-visible),offset));lastX=e.getX();invalidate();}return true;}if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){moving=false;zooming=false;return true;}return true;}
        private float span(MotionEvent e){if(e.getPointerCount()<2)return 0;float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1);return (float)Math.sqrt(dx*dx+dy*dy);}
    }
}
