package com.iranstocks.signal;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.CandleStickChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.CandleData;
import com.github.mikephil.charting.data.CandleDataSet;
import com.github.mikephil.charting.data.CandleEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.ICandleDataSet;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ChartActivity extends Activity {
    private TextView status;
    private CandleStickChart chart;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String symbol=getIntent().getStringExtra("symbol");
        String insCode=getIntent().getStringExtra("insCode");
        if(symbol==null||symbol.trim().isEmpty()) symbol="نماد";
        if(insCode==null) insCode="";

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10,10,10,10);
        TextView title=new TextView(this);
        title.setText("📈 نمودار کندلی «"+symbol+"»");
        title.setTextSize(20); title.setTextColor(Color.WHITE); title.setPadding(8,8,8,10);
        root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        android.widget.Button back=new android.widget.Button(this);
        back.setText("← بازگشت");
        back.setOnClickListener(v -> finish());
        root.addView(back,new LinearLayout.LayoutParams(-1,-2));
        status=new TextView(this); status.setText("در حال دریافت داده تاریخی از TSETMC..."); status.setTextColor(Color.LTGRAY); status.setPadding(8,0,8,8);
        root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        chart=new CandleStickChart(this);
        chart.setBackgroundColor(Color.rgb(7,17,31));
        chart.setNoDataText("داده نمودار موجود نیست"); chart.setNoDataTextColor(Color.LTGRAY);
        chart.getDescription().setEnabled(false); chart.setPinchZoom(true); chart.setScaleEnabled(true); chart.setDragEnabled(true); chart.setDoubleTapToZoomEnabled(true); chart.setHighlightPerDragEnabled(true); chart.setHighlightPerTapEnabled(true);
        chart.setDrawGridBackground(false); chart.getLegend().setEnabled(false);
        XAxis x=chart.getXAxis(); x.setPosition(XAxis.XAxisPosition.BOTTOM); x.setTextColor(Color.LTGRAY); x.setDrawGridLines(false); x.setGranularity(1f); x.setLabelRotationAngle(-45f);
        YAxis left=chart.getAxisLeft(); left.setTextColor(Color.LTGRAY); left.setDrawGridLines(true); left.setGridColor(Color.rgb(35,55,75));
        YAxis right=chart.getAxisRight(); right.setEnabled(false);
        root.addView(chart,new LinearLayout.LayoutParams(-1,0,1f));
        setContentView(root);

        final String code=insCode.trim();
        if(code.isEmpty()){status.setText("کد نماد در دسترس نیست");return;}
        final String sym=symbol;
        new Thread(() -> { try { JSONArray rows=loadHistory(code); runOnUiThread(() -> render(rows)); } catch(Exception e){ runOnUiThread(() -> status.setText("خطا در دریافت نمودار: "+safeMsg(e))); } },"ChartLoader").start();
    }

    private String safeMsg(Exception e){String m=e.getMessage();return m==null||m.trim().isEmpty()?"نامشخص":m;}

    private JSONArray loadHistory(String code) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/"+code+"/300").openConnection();
        try{
            c.setRequestMethod("GET"); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("User-Agent","Mozilla/5.0");
            int rc=c.getResponseCode(); if(rc<200||rc>=300) throw new Exception("TSETMC HTTP "+rc);
            BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String line; int chars=0;
            while((line=br.readLine())!=null){chars+=line.length();if(chars>6000000)throw new Exception("پاسخ بیش از حد بزرگ است");b.append(line);} br.close();
            String body=b.toString().trim(); if(body.startsWith("[")) return new JSONArray(body);
            JSONObject obj=new JSONObject(body); JSONArray a=obj.optJSONArray("closingPriceDaily"); if(a==null)a=obj.optJSONArray("closingPriceDailyList"); if(a==null)a=obj.optJSONArray("data");
            if(a==null||a.length()==0)throw new Exception("داده تاریخی یافت نشد"); return a;
        }finally{c.disconnect();}
    }

    private void render(JSONArray raw){
        try{
            ArrayList<JSONObject> rows=new ArrayList<>(); for(int i=0;i<raw.length();i++){JSONObject x=raw.optJSONObject(i);if(x!=null)rows.add(x);}
            Collections.sort(rows,Comparator.comparingInt(a->a.optInt("dEven",0)));
            int from=Math.max(0,rows.size()-120); ArrayList<CandleEntry> entries=new ArrayList<>(); ArrayList<String> labels=new ArrayList<>();
            for(int i=from;i<rows.size();i++){
                JSONObject x=rows.get(i); float o=(float)num(x,"priceFirst","pFirst","pOpen","open","Open"), h=(float)num(x,"priceMax","pMax","pHigh","high","High"), l=(float)num(x,"priceMin","pMin","pLow","low","Low"), cl=(float)num(x,"pClosing","pClose","pLast","last","close","Close");
                if(o<=0||h<=0||l<=0||cl<=0)continue; entries.add(new CandleEntry(entries.size(),h,l,o,cl)); labels.add(formatPersianDate(x.optString("dEven", String.valueOf(x.optInt("dEven",0)))));
            }
            if(entries.isEmpty())throw new Exception("داده معتبر نمودار وجود ندارد");
            CandleDataSet ds=new CandleDataSet(entries,"قیمت");
            ds.setDrawIcons(false); ds.setShadowColor(Color.LTGRAY); ds.setShadowWidth(1.2f); ds.setDecreasingColor(Color.rgb(220,75,85)); ds.setDecreasingPaintStyle(android.graphics.Paint.Style.FILL); ds.setIncreasingColor(Color.rgb(45,195,125)); ds.setIncreasingPaintStyle(android.graphics.Paint.Style.FILL); ds.setNeutralColor(Color.GRAY); ds.setBarSpace(.18f);
            CandleData data=new CandleData(ds); chart.setData(data); chart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels)); chart.notifyDataSetChanged(); chart.invalidate(); chart.moveViewToX(Math.max(0,entries.size()-25)); status.setText(entries.size()+" روز اخیر • کشیدن، زوم و انتخاب کندل فعال است");
        }catch(Exception e){status.setText("خطا در ساخت نمودار: "+safeMsg(e));}
    }
    private String formatPersianDate(String raw){
        String s=raw==null?"":raw.trim();
        if(s.matches("\\d{8}")){
            // TSETMC dEven is normally already a Jalali date (YYYYMMDD).
            String d=s.substring(0,4)+"/"+s.substring(4,6)+"/"+s.substring(6,8); StringBuilder out=new StringBuilder(); for(int i=0;i<d.length();i++){char ch=d.charAt(i); if(ch>='0'&&ch<='9') out.append("۰۱۲۳۴۵۶۷۸۹".charAt(ch-'0')); else out.append(ch);} return out.toString();
        }
        return s;
    }

    private double num(JSONObject o,String...keys){for(String k:keys)if(o.has(k)&&!o.isNull(k)){Object v=o.opt(k);if(v instanceof Number)return ((Number)v).doubleValue();try{return Double.parseDouble(String.valueOf(v));}catch(Exception ignored){}}return 0;}
}
