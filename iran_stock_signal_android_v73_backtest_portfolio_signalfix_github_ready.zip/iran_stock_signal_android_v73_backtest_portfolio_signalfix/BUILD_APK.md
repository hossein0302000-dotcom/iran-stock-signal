# V22 build

V22 fixes the V21 Java compile error caused by redefining `ma50` inside `analyzeInsCode`. The duplicate declaration was removed; the existing `ma50` variable is reused.

Version: 1.5.2 / versionCode 16.

The GitHub workflow is intentionally named `.github/workflows/main.yml` to match the repository's active workflow. It uses Java 17, Android SDK 35, and Gradle 8.9, and prints the environment plus the exact fix before building.
