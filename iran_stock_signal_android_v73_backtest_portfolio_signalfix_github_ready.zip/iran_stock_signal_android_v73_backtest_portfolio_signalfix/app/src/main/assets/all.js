
function esc(x){return String(x==null?'':x).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function fmt(x){return x==null||x===''?'-':Number(x).toLocaleString('fa-IR',{maximumFractionDigits:2})}
function actionFa(a){return a==='BUY'?'خرید':a==='WATCH'?'صبر / بررسی':'خروج / عدم ورود'}
function cls(a){return a==='BUY'?'green':a==='WATCH'?'yellow':'red'}
function horizonMeta(mode,r){
  try{
    if(mode==='short') return '<div>ورود<b>'+fmt(r.entry)+'</b></div><div>حد ضرر<b>'+((r.action==='BUY'&&r.stop!=null)?fmt(r.stop):'-')+'</b></div><div>قدرت خریدار<b>'+((r.buyer_power!=null&&Number(r.buyer_power)>0)?Number(r.buyer_power).toFixed(2):'-')+'</b></div>';
    if(mode==='month') return '<div>هدف<b>'+fmt(r.one_month_target)+'</b></div><div>بازده هدف<b>'+((r.one_month_return!=null)?Number(r.one_month_return).toFixed(2)+'%':'-')+'</b></div><div>قدرت خریدار<b>'+((r.buyer_power!=null&&Number(r.buyer_power)>0)?Number(r.buyer_power).toFixed(2):'-')+'</b></div>';
    if(mode==='quarter') return '<div>هدف<b>'+fmt(r.three_month_target)+'</b></div><div>بازده هدف<b>'+((r.three_month_return!=null)?Number(r.three_month_return).toFixed(2)+'%':'-')+'</b></div><div>قدرت خریدار<b>'+((r.buyer_power!=null&&Number(r.buyer_power)>0)?Number(r.buyer_power).toFixed(2):'-')+'</b></div>';
    return '<div>امتیاز بلندمدت<b>'+fmt(r.long_term_score)+'</b></div><div>وضعیت<b>'+esc(r.long_term_action||'قابل بررسی')+'</b></div><div>قدرت خریدار<b>'+((r.buyer_power!=null&&Number(r.buyer_power)>0)?Number(r.buyer_power).toFixed(2):'-')+'</b></div>';
  }catch(e){return '<div>اطلاعات<b>-</b></div><div>وضعیت<b>-</b></div><div>قدرت خریدار<b>-</b></div>';}
}
function setStatus(t,loading=false){document.getElementById('status').innerHTML=(loading?'<span class="spinner"></span>':'')+esc(t)}
let lastScanHtml='';
let lastScanMode='';
function go(symbol){let s=(symbol!=null?String(symbol):document.getElementById('sym').value).trim();document.getElementById('sym').value=s;if(!s)return;if(symbol!=null){lastScanHtml=document.getElementById('out').innerHTML; lastScanMode='scan';}
setStatus('در حال تحلیل '+s+' ...',true);document.getElementById('out').innerHTML='<div class="card empty">در حال دریافت تاریخچه، قدرت خریدار و محاسبه امتیاز...</div>';if(window.Android&&Android.analyze)Android.analyze(s);else document.getElementById('out').innerHTML='<div class="card empty">موتور تحلیل در دسترس نیست.</div>'}
function scan(mode){setStatus('در حال اسکن بازار ...',true);document.getElementById('out').innerHTML='<div class="card empty"><span class="spinner"></span> نمادهای بازار در حال بررسی هستند؛ ممکن است چند دقیقه طول بکشد.</div>';if(window.Android&&Android.scanMarketMode)Android.scanMarketMode(mode||'short');else document.getElementById('out').innerHTML='<div class="card empty">موتور اسکن بازار در دسترس نیست.</div>'}
function backtest(){setStatus('در حال اعتبارسنجی سیگنال‌های نبض بازار ...',true);document.getElementById('out').innerHTML='<div class="card empty"><span class="spinner"></span> تاریخچه نمادها در حال بررسی است؛ ممکن است چند دقیقه طول بکشد.</div>';if(window.Android&&Android.backtestMarket)Android.backtestMarket();else document.getElementById('out').innerHTML='<div class="card empty">موتور بک‌تست در دسترس نیست.</div>'}
function receiveDailyPanel(txt){
  try{
    let j=JSON.parse(txt);
    if(!j.ok){setStatus('خطا');document.getElementById('out').innerHTML='<div class="card empty">'+esc(j.error||'خطا در پنل امروز')+'</div>';return}
    setStatus('پنل معاملات امروز آماده شد');
    let h='<div class="card"><div class="section-title"><h2>📋 پنل معاملات امروز</h2><span class="pill">TSETMC</span></div><div class="metrics"><div class="metric"><small>مثبت</small><b class="green">'+fmt(j.up)+'</b></div><div class="metric"><small>منفی</small><b class="red">'+fmt(j.down)+'</b></div><div class="metric"><small>خنثی</small><b>'+fmt(j.flat)+'</b></div><div class="metric"><small>ارزش معاملات</small><b>'+fmt(j.total_value)+'</b></div></div><p class="muted">'+esc(j.note||'')+'</p></div><div class="list">';
    (j.items||[]).forEach((r,i)=>{
      let side=r.queue_side==='BUY'?'صف خرید':(Number(r.sell_queue_volume||0)>0?'صف فروش':'');
      let sym=JSON.stringify(String(r.symbol||''));
      h+='<div class="stock"><div class="stockTop"><div><span class="rank">#'+(i+1)+'</span> <span class="stockName" style="cursor:pointer;text-decoration:underline" onclick="go('+sym+')">'+esc(r.symbol||'-')+'</span><div class="stockAction '+(Number(r.change)>=0?'green':'red')+'">'+Number(r.change||0).toFixed(2)+'٪ '+esc(side)+'</div></div><div class="scoreBadge '+(Number(r.change)>=0?'green':'red')+'">'+Number(r.change||0).toFixed(2)+'٪</div></div><div class="stockMeta"><div>حجم معاملات<b>'+fmt(r.volume)+'</b></div><div>ارزش معاملات<b>'+fmt(r.value)+'</b></div><div>صف خرید<b>'+fmt(r.buy_queue_volume)+'</b></div><div>تعداد سفارش خرید<b>'+fmt(r.buy_queue_orders)+'</b></div><div>صف فروش<b>'+fmt(r.sell_queue_volume)+'</b></div><div>تعداد سفارش فروش<b>'+fmt(r.sell_queue_orders)+'</b></div></div></div>';
    });
    h+='</div>';document.getElementById('out').innerHTML=h;
  }catch(e){setStatus('خطا در نمایش');document.getElementById('out').innerHTML='<div class="card empty">خطا در نمایش پنل معاملات امروز</div>'}
}

function receiveBacktest(txt){
  try{
    let j=JSON.parse(txt);
    if(!j.ok){setStatus('خطا');document.getElementById('out').innerHTML='<div class="card empty">'+esc(j.error||'خطا در بک‌تست')+'</div>';return}
    setStatus('اعتبارسنجی کامل شد');
    const card=(title,x)=>{
      let n=Number(x.signals)||0, ev=Number(x.evaluated_days)||0;
      let pf=Number(x.profit_factor)||0, avg=Number(x.avg_return)||0;
      let pos=Number(x.positive_rate)||0, hit=Number(x.target_hit_rate)||0;
      let stop=Number(x.stop_rate)||0, to=Number(x.timeout_rate)||0;
      let rows=(x.score_distribution||[]).map(b=>
        '<div class="reason"><b>'+esc(b.label||'')+'</b> — '+Number(b.count||0)+' سیگنال/روز ارزیابی‌شده • مثبت '+Number(b.positive_rate||0).toFixed(1)+'٪ • هدف '+Number(b.target_rate||0).toFixed(1)+'٪</div>'
      ).join('');
      return '<div class="card"><div class="section-title"><h2>'+title+'</h2><span class="pill">'+n+' سیگنال</span></div>'+
        '<div class="metrics">'+
        '<div class="metric"><small>روزهای ارزیابی</small><b>'+ev+'</b></div>'+ 
        '<div class="metric"><small>بازده میانگین</small><b>'+avg.toFixed(2)+'٪</b></div>'+ 
        '<div class="metric"><small>معاملات مثبت</small><b>'+pos.toFixed(1)+'٪</b></div>'+ 
        '<div class="metric"><small>هدف زده</small><b>'+hit.toFixed(1)+'٪</b></div>'+ 
        '<div class="metric"><small>حدضرر</small><b>'+stop.toFixed(1)+'٪</b></div>'+ 
        '<div class="metric"><small>Timeout</small><b>'+to.toFixed(1)+'٪</b></div>'+ 
        '<div class="metric"><small>Profit Factor</small><b>'+pf.toFixed(2)+'</b></div>'+ 
        '<div class="metric"><small>Max DD</small><b>'+Number(x.max_drawdown||0).toFixed(2)+'٪</b></div>'+ 
        '</div><div style="margin-top:10px"><b>توزیع امتیاز و کیفیت خروجی</b>'+rows+'</div>'+ 
        '<p class="muted" style="margin-top:10px">«هدف زده» فقط رسیدن به هدف تعیین‌شده است؛ معامله‌ای که در پایان افق مثبت مانده ولی به هدف نرسیده، در «معاملات مثبت» حساب می‌شود.</p></div>';
    };
    let h='<div class="card"><div class="topline"><div><div class="muted">اعتبارسنجی چندافقی</div><h2 style="margin:4px 0 0">بک‌تست مستقل هر افق</h2></div><span class="pill">'+fmt(j.symbols)+' نماد</span></div><p class="muted">'+esc(j.note||'')+'</p></div>';
    h+=card('⚡ کوتاه‌مدت • ۱۰ روز',j.short||{});
    h+=card('📅 یک‌ماهه • ۲۱ روز',j.month||{});
    h+=card('📊 سه‌ماهه • ۶۳ روز',j.quarter||{});
    document.getElementById('out').innerHTML=h;
    lastScanHtml=document.getElementById('out').innerHTML; lastScanMode='scan';
  }catch(e){setStatus('خطا در نمایش');document.getElementById('out').innerHTML='<div class="card empty">خطا در نمایش نتیجه اعتبارسنجی</div>'}
}

function receiveScan(txt){
  try{
    let j=JSON.parse(txt);
    if(!j.ok){setStatus('خطا');document.getElementById('out').innerHTML='<div class="card empty">'+esc(j.error||'خطا در اسکن')+'</div>';return}
    setStatus('اسکن '+(j.mode==='rent'?'رفتار غیرعادی':'بازار')+' کامل شد');
    let mode=j.mode||'short';
    let labels={short:'کوتاه‌مدت',month:'یک‌ماهه',quarter:'سه‌ماهه',long:'بلندمدت',rent:'رفتار غیرعادی غیرشاخص‌ساز'};
    let title={short:'بهترین فرصت‌های کوتاه‌مدت',month:'بهترین فرصت‌های یک‌ماهه',quarter:'بهترین فرصت‌های سه‌ماهه',long:'سهم‌های مناسب نگهداری بلندمدت',rent:'نمادهای غیرشاخص‌ساز با رفتار معاملاتی غیرعادی'}[mode]||'نتایج اسکن';
    let key=mode==='month'?'one_month_score':mode==='quarter'?'three_month_score':mode==='long'?'long_term_score':mode==='rent'?'rent_score':'score';
    let h='<div class="card"><div class="topline"><div><div class="muted">اسکن بازار • '+labels[mode]+'</div><h2 style="margin:4px 0 0">'+title+'</h2></div><span class="pill">'+fmt(j.full_analyzed)+' تحلیل</span></div><p class="muted">'+esc(j.note||'')+'</p></div><div class="list">';
    (j.results||[]).forEach((r,i)=>{
      let score=Math.max(0,Math.min(100,Number(r[key])||0));
      let act=mode==='long'?(r.long_term_action||'بلندمدت قابل بررسی'):mode==='month'?(r.one_month_action||'عدم ورود'):mode==='quarter'?(r.three_month_action||'عدم ورود'):mode==='rent'?'بررسی رفتار غیرعادی':actionFa(r.action);
      let c=mode==='short'?cls(r.action):(score>=75?'green':score>=60?'yellow':'red');
      let sym=String(r.symbol||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'");
      let extra=mode==='rent'?'<div class="stockMeta"><div>امتیاز رفتار غیرعادی<b>'+Number(r.rent_score||0).toFixed(0)+'/100</b></div><div>اعتبار شواهد<b>'+Number(r.rent_confidence||0).toFixed(0)+'/100</b></div><div>قابلیت معاملاتی<b>'+Number(r.rent_tradeability||0).toFixed(0)+'/100 • '+esc(r.rent_tradeability_label||'-')+'</b></div><div>بهترین افق<b>'+esc(r.rent_best_horizon||'-')+'</b></div></div><div class="stockMeta"><div>کوتاه‌مدت<b>'+Number(r.score||0).toFixed(0)+'</b></div><div>یک‌ماهه<b>'+Number(r.one_month_score||0).toFixed(0)+'</b></div><div>سه‌ماهه<b>'+Number(r.three_month_score||0).toFixed(0)+'</b></div><div>بلندمدت<b>'+Number(r.long_term_score||0).toFixed(0)+'</b></div></div>':' ';
      h+='<div class="stock"><div class="stockTop"><div><span class="rank">#'+(i+1)+'</span> <span class="stockName" style="cursor:pointer;text-decoration:underline" onclick="go(\''+esc(sym)+'\')">'+esc(r.symbol||'-')+'</span><div class="muted" style="margin-top:2px">'+esc(r.group||'سایر')+'</div><div class="stockAction '+c+'">'+esc(act)+'</div></div><div class="scoreBadge '+c+'">'+score+'</div></div><div class="bar"><i style="width:'+score+'%"></i></div><div class="stockMeta">'+horizonMeta(mode,r)+'</div>'+extra+'</div>';
    });
    h+='</div>';
    if(!(j.results||[]).length)h+='<div class="card empty">نتیجه قابل اتکایی برای نمایش پیدا نشد.</div>';
    document.getElementById('out').innerHTML=h;
  }catch(e){setStatus('خطا در نمایش');document.getElementById('out').innerHTML='<div class="card empty">خطا در نمایش نتیجه اسکن</div>'}
}
function backToScan(){if(!lastScanHtml)return;document.getElementById('out').innerHTML=lastScanHtml;setStatus('نتایج اسکن دوباره نمایش داده شد');window.scrollTo(0,0)}
function receiveAnalysis(txt){try{let j=JSON.parse(txt);if(!j.ok){setStatus('خطا');document.getElementById('out').innerHTML='<div class="card empty">'+esc(j.error||'خطا')+'</div>';return}setStatus('تحلیل آماده است');let c=cls(j.action);let lc=(Number(j.long_term_score)>=80?'green':Number(j.long_term_score)>=65?'yellow':'red');let rent=Number(j.rent_score!=null?j.rent_score:j.anomaly_score||0);let h='<div class="card"><div class="scoreHero"><div class="muted">'+esc(j.symbol||'نماد')+'</div><div class="score '+c+'">'+j.score+'</div><div class="scoreLabel '+c+'">'+actionFa(j.action)+'</div></div><div class="levels"><div class="level"><small>ورود</small><b>'+fmt(j.entry)+'</b></div><div class="level"><small>حد ضرر</small><b>'+((j.action==='BUY'&&j.stop!=null)?fmt(j.stop):'-')+'</b></div><div class="level"><small>هدف ۱</small><b>'+((j.action==='BUY'&&j.target1!=null)?fmt(j.target1):'-')+'</b></div><div class="level"><small>هدف ۲</small><b>'+((j.action==='BUY'&&j.target2!=null)?fmt(j.target2):'-')+'</b></div></div><div class="metrics"><div class="metric"><small>قدرت خریدار حقیقی</small><b>'+((j.buyer_power&&Number(j.buyer_power)>0)?Number(j.buyer_power).toFixed(2):'-')+'</b></div><div class="metric"><small>ورود/خروج پول حقیقی</small><b>'+fmt(j.real_money_flow)+'</b></div><div class="metric"><small>رژیم بازار</small><b>'+esc(j.market_regime||'-')+'</b></div><div class="metric"><small>ریسک حد ضرر</small><b>'+((j.risk_pct!=null)?Number(j.risk_pct).toFixed(2):'-')+'%</b></div><div class="metric"><small>🔥 پول داغ</small><b>'+((j.hot_money_score!=null)?Number(j.hot_money_score).toFixed(0):'-')+'</b></div><div class="metric"><small>ADX</small><b>'+((j.adx!=null)?Number(j.adx).toFixed(1):'-')+'</b></div><div class="metric"><small>RSI</small><b>'+((j.rsi!=null)?Number(j.rsi).toFixed(1):'-')+'</b></div><div class="metric"><small>MFI</small><b>'+((j.mfi!=null)?Number(j.mfi).toFixed(1):'-')+'</b></div><div class="metric"><small>نسبت حجم</small><b>'+((j.volume_ratio!=null)?Number(j.volume_ratio).toFixed(2):'-')+'</b></div><div class="metric"><small>🕵️ امتیاز رانت</small><b>'+rent.toFixed(0)+'/100</b></div><div class="metric"><small>قابلیت معاملاتی</small><b>'+Number(j.rent_tradeability||0).toFixed(0)+'/100 • '+esc(j.rent_tradeability_label||'-')+'</b></div><div class="metric"><small>بهترین افق</small><b>'+esc(j.rent_best_horizon||'-')+'</b></div></div><p class="muted" style="margin-top:12px">امتیاز رانت یک شاخص غربالگری رفتار غیرعادی است و به‌تنهایی اثبات رانت یا اطلاعات نهانی نیست.</p><p class="muted">'+fmt(j.data_rows)+' روز داده واقعی از '+esc(j.source||'TSETMC')+'</p></div>';
h+='<div class="card"><div class="section-title"><h2>جمع‌بندی افق زمانی</h2></div><div class="stock" style="margin-bottom:8px"><div class="stockTop"><div><b>⚡ کوتاه‌مدت</b><div class="stockAction '+c+'">'+esc(actionFa(j.action))+'</div></div><div class="scoreBadge '+c+'">'+j.score+'</div></div><div class="bar"><i style="width:'+Math.max(0,Math.min(100,Number(j.score)||0))+'%"></i></div></div><div class="stock"><div class="stockTop"><div><b>📈 بلندمدت</b><div class="stockAction '+lc+'">'+esc(j.long_term_action||'بلندمدت قابل بررسی')+'</div></div><div class="scoreBadge '+lc+'">'+(j.long_term_score||0)+'</div></div><div class="bar"><i style="width:'+Math.max(0,Math.min(100,Number(j.long_term_score)||0))+'%"></i></div></div></div>';
h+='<div class="card"><div class="section-title"><h2>افق‌های یک‌ماهه و سه‌ماهه</h2></div><div class="stock" style="margin-bottom:8px"><div class="stockTop"><div><b>📅 یک‌ماهه</b><div class="stockAction '+(Number(j.one_month_score)>=75?'green':Number(j.one_month_score)>=60?'yellow':'red')+'">'+esc(j.one_month_action||'عدم ورود')+'</div></div><div class="scoreBadge '+(Number(j.one_month_score)>=75?'green':Number(j.one_month_score)>=60?'yellow':'red')+'">'+(j.one_month_score||0)+'</div></div><div class="bar"><i style="width:'+Math.max(0,Math.min(100,Number(j.one_month_score)||0))+'%"></i></div><div class="stockMeta"><div>هدف<b>'+((j.one_month_action==='خرید/مناسب')?fmt(j.one_month_target):'-')+'</b></div><div>بازده هدف<b>'+((j.one_month_action==='خرید/مناسب'&&j.one_month_return!=null)?Number(j.one_month_return).toFixed(2)+'%':'-')+'</b></div></div></div><div class="stock"><div class="stockTop"><div><b>📊 سه‌ماهه</b><div class="stockAction '+(Number(j.three_month_score)>=75?'green':Number(j.three_month_score)>=60?'yellow':'red')+'">'+esc(j.three_month_action||'عدم ورود')+'</div></div><div class="scoreBadge '+(Number(j.three_month_score)>=75?'green':Number(j.three_month_score)>=60?'yellow':'red')+'">'+(j.three_month_score||0)+'</div></div><div class="bar"><i style="width:'+Math.max(0,Math.min(100,Number(j.three_month_score)||0))+'%"></i></div><div class="stockMeta"><div>هدف<b>'+((j.three_month_action==='خرید/مناسب')?fmt(j.three_month_target):'-')+'</b></div><div>بازده هدف<b>'+((j.three_month_action==='خرید/مناسب'&&j.three_month_return!=null)?Number(j.three_month_return).toFixed(2)+'%':'-')+'</b></div></div></div></div>';let b=j.score_breakdown||{};let caps=b.caps||[];h+='<div class="card"><div class="section-title"><h2>🔬 کالبدشکافی امتیاز</h2><span class="pill">خام '+(b.raw!=null?b.raw:'-')+' → نهایی '+(b.final!=null?b.final:'-')+'</span></div><div class="metrics"><div class="metric"><small>روند / ۲۰</small><b>'+(b.trend!=null?b.trend:'-')+'</b></div><div class="metric"><small>مومنتوم / ۱۵</small><b>'+(b.momentum!=null?b.momentum:'-')+'</b></div><div class="metric"><small>حجم / ۱۵</small><b>'+(b.volume!=null?b.volume:'-')+'</b></div><div class="metric"><small>شکست / ۱۵</small><b>'+(b.breakout!=null?b.breakout:'-')+'</b></div><div class="metric"><small>نقدینگی / ۱۰</small><b>'+(b.liquidity!=null?b.liquidity:'-')+'</b></div><div class="metric"><small>MFI / ۵</small><b>'+(b.mfi!=null?b.mfi:'-')+'</b></div><div class="metric"><small>بازار / ۱۰</small><b>'+(b.market!=null?b.market:'-')+'</b></div><div class="metric"><small>ریسک / ۱۰</small><b>'+(b.risk!=null?b.risk:'-')+'</b></div></div>'+(caps.length?'<div style="margin-top:10px"><b>محدودکننده‌ها:</b>'+caps.map(x=>'<div class="reason warn">⚠ '+esc(x)+'</div>').join('')+'</div>':'')+'</div>';
h+='<div class="card"><div class="section-title"><h2>دلایل امتیاز کوتاه‌مدت</h2><span class="pill">'+j.score+'/100</span></div>'+(j.reasons||[]).map(x=>'<div class="reason">✓ '+esc(x)+'</div>').join('')+'</div>';
if((j.long_term_reasons||[]).length)h+='<div class="card"><div class="section-title"><h2>دلایل امتیاز بلندمدت</h2><span class="pill">'+(j.long_term_score||0)+'/100</span></div>'+(j.long_term_reasons||[]).map(x=>'<div class="reason">✓ '+esc(x)+'</div>').join('')+'</div>';
if((j.patterns||[]).length)h+='<div class="card"><div class="section-title"><h2>🧩 الگوها و الگوریتم‌ها</h2><span class="pill">سیگنال '+Number(j.pattern_signal||50)+'/100</span></div>'+(j.patterns||[]).map(x=>'<div class="reason">• '+esc(x)+'</div>').join('')+'<div class="muted" style="margin-top:8px">شاخص الگو صرفاً تأیید تکنیکال است و به‌تنهایی سیگنال خرید نیست.</div></div>';if((j.algorithm_flags||[]).length)h+='<div class="card"><div class="section-title"><h2>⚙️ وضعیت الگوریتمی امروز</h2></div>'+(j.algorithm_flags||[]).map(x=>'<div class="reason">• '+esc(x)+'</div>').join('')+'</div>';if((j.warnings||[]).length)h+='<div class="card"><div class="section-title"><h2>هشدارها</h2></div>'+(j.warnings||[]).map(x=>'<div class="reason warn">⚠ '+esc(x)+'</div>').join('')+'</div>';
if(lastScanHtml){h='<button class="btn secondary" style="margin:12px 0 4px" onclick="backToScan()">← بازگشت به نتایج اسکن</button>'+h;}document.getElementById('out').innerHTML=h}catch(e){setStatus('خطا در نمایش');document.getElementById('out').innerHTML='<div class="card empty">خطا در نمایش نتیجه تحلیل</div>'}}
