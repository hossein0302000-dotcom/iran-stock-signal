package com.iranstocks.signal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Context;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    public static final String PREFS_NAME="nabd_bazar_prefs";
    public static final String PORTFOLIO_KEY="portfolio_items";
    private WebView webView;
    private final AtomicBoolean operationBusy = new AtomicBoolean(false);
    private final AtomicBoolean activityDestroyed = new AtomicBoolean(false);

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        activityDestroyed.set(false);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1001);
    }

    private void configureWebView(WebView v) {
        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        v.setWebViewClient(new WebViewClient() {
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                if (activityDestroyed.get() || isFinishing() || (Build.VERSION.SDK_INT >= 17 && isDestroyed())) return true;
                try { view.destroy(); } catch (Throwable ignored) {}
                try {
                    WebView replacement = new WebView(MainActivity.this);
                    configureWebView(replacement);
                    webView = replacement;
                    setContentView(replacement);
                    replacement.loadUrl("file:///android_asset/index.html");
                } catch (Throwable ignored) {}
                return true;
            }
        });
        v.setWebChromeClient(new WebChromeClient());
        v.addJavascriptInterface(new MarketBridge(), "Android");
    }

    private void safeEvaluateJavascript(final String js) {
        if (activityDestroyed.get()) return;
        runOnUiThread(() -> {
            if (activityDestroyed.get() || webView == null) return;
            try {
                if (Build.VERSION.SDK_INT >= 17 && webView.isAttachedToWindow()) webView.evaluateJavascript(js, null);
            } catch (Throwable ignored) {}
        });
    }

    private class MarketBridge {
        @JavascriptInterface public void analyze(final String symbol) {
            if(!operationBusy.compareAndSet(false,true)){
                final String js="window.receiveAnalysis("+JSONObject.quote(errorJson("یک عملیات دیگر در حال اجراست؛ پس از پایان آن دوباره امتحان کنید"))+");";
                safeEvaluateJavascript(js);
                return;
            }
            new Thread(() -> {
                String result;
                try { result = analyzeSymbol(symbol); }
                catch (Exception e) { result = errorJson(e.getMessage() == null ? "خطا در دریافت داده" : e.getMessage()); }
                finally { operationBusy.set(false); }
                final String js = "window.receiveAnalysis(" + JSONObject.quote(result) + ");";
                safeEvaluateJavascript(js);
            }).start();
        }

        @JavascriptInterface public void analyzePortfolioCode(final String insCode, final String symbol) {
            if(!operationBusy.compareAndSet(false,true)){
                final String js="window.receiveAnalysis("+JSONObject.quote(errorJson("یک عملیات دیگر در حال اجراست؛ پس از پایان آن دوباره امتحان کنید"))+");";
                safeEvaluateJavascript(js);
                return;
            }
            new Thread(() -> {
                String result;
                try {
                    if(insCode==null || insCode.trim().isEmpty()) throw new Exception("کد نماد در پرتفوی ثبت نشده است");
                    String sym=(symbol==null||symbol.trim().isEmpty())?insCode:symbol.trim();
                    result=analyzeInsCode(insCode.trim(),sym,getMarketRegime());
                } catch(Exception e) { result=errorJson(e.getMessage()==null?"خطا در تحلیل سهم":e.getMessage()); }
                finally { operationBusy.set(false); }
                final String js="window.receiveAnalysis("+JSONObject.quote(result)+");";
                safeEvaluateJavascript(js);
            },"PortfolioAnalyze").start();
        }

        @JavascriptInterface public void scanMarket() { scanMarketMode("short"); }

        @JavascriptInterface public void backtestMarket() {
            if(!operationBusy.compareAndSet(false,true)){
                final String js="window.receiveBacktest("+JSONObject.quote(errorJson("یک عملیات دیگر در حال اجراست؛ پس از پایان آن دوباره امتحان کنید"))+");";
                safeEvaluateJavascript(js);
                return;
            }
            new Thread(() -> {
                String result;
                try { result = backtestMarketInternal(); }
                catch (Exception e) { result = errorJson(e.getMessage() == null ? "خطا در اعتبارسنجی" : e.getMessage()); }
                finally { operationBusy.set(false); }
                final String js = "window.receiveBacktest(" + JSONObject.quote(result) + ");";
                safeEvaluateJavascript(js);
            }).start();
        }

        @JavascriptInterface public void scanMarketMode(String mode) {
            final String scanMode = (mode == null || mode.trim().isEmpty()) ? "short" : mode;
            if("daily".equalsIgnoreCase(scanMode)){
                dailyPanel();
                return;
            }
            if(!operationBusy.compareAndSet(false,true)){
                final String js="window.receiveScan("+JSONObject.quote(errorJson("یک عملیات دیگر در حال اجراست؛ پس از پایان آن دوباره امتحان کنید"))+");";
                safeEvaluateJavascript(js);
                return;
            }
            new Thread(() -> {
                String result;
                try { result = scanMarketInternal(scanMode); }
                catch (Exception e) {
                    try { JSONObject er=new JSONObject(errorJson(e.getMessage() == null ? "خطا در اسکن بازار" : e.getMessage())); er.put("mode",scanMode); result=er.toString(); }
                    catch(Exception ignored){ result=errorJson(e.getMessage() == null ? "خطا در اسکن بازار" : e.getMessage()); }
                }
                finally { operationBusy.set(false); }
                final String js = "window.receiveScan(" + JSONObject.quote(result) + ");";
                safeEvaluateJavascript(js);
            }).start();
        }

        @JavascriptInterface public String getPortfolio(){ return portfolioJson(); }

        @JavascriptInterface public String addPortfolio(String symbol,double quantity,double buyPrice,double stopPrice,double targetPrice){
            try{
                String q=URLEncoder.encode(symbol==null?"":symbol.trim(),"UTF-8").replace("+","%20");
                JSONObject search=new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentSearch/"+q));
                JSONArray arr=search.optJSONArray("instrumentSearch"); if(arr==null)arr=search.optJSONArray("instrument"); if(arr==null)arr=search.optJSONArray("instruments");
                if(arr==null)throw new Exception("نماد پیدا نشد");
                String code="",title=symbol;
                for(int i=0;i<arr.length();i++){JSONObject x=arr.optJSONObject(i);if(x==null)continue;code=x.optString("insCode","");if(!code.isEmpty()){title=x.optString("lVal30",x.optString("lVal18AFC",symbol));break;}}
                if(code.isEmpty())throw new Exception("نماد پیدا نشد");
                JSONArray a=new JSONArray(getPortfolioRaw());
                for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&code.equals(x.optString("insCode","")))throw new Exception("این نماد قبلاً در پرتفوی هست");}
                JSONObject item=new JSONObject(); item.put("symbol",title);item.put("insCode",code);item.put("quantity",Math.max(0,quantity));item.put("buyPrice",Math.max(0,buyPrice));item.put("stopPrice",Math.max(0,stopPrice));item.put("targetPrice",Math.max(0,targetPrice));item.put("enabled",true);item.put("buyAlert",true);item.put("sellAlert",true);item.put("lastAlertKey","");item.put("lastAlertTime",0);
                a.put(item); savePortfolio(a); return okJson("سهم به پرتفوی اضافه شد");
            }catch(Exception e){return errorJson(e.getMessage()==null?"خطا در افزودن سهم":e.getMessage());}
        }

        @JavascriptInterface public String removePortfolio(String insCode){try{JSONArray a=new JSONArray(getPortfolioRaw());JSONArray b=new JSONArray();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&!insCode.equals(x.optString("insCode","")))b.put(x);}savePortfolio(b);return okJson("حذف شد");}catch(Exception e){return errorJson("خطا در حذف");}}
        @JavascriptInterface public String togglePortfolio(String insCode,boolean enabled){try{JSONArray a=new JSONArray(getPortfolioRaw());boolean found=false;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&insCode.equals(x.optString("insCode",""))){x.put("enabled",enabled);found=true;break;}}savePortfolio(a);return found?okJson(enabled?"رصد سهم فعال شد":"رصد سهم متوقف شد"):errorJson("سهم در پرتفوی پیدا نشد");}catch(Exception e){return errorJson("خطا در تغییر وضعیت رصد");}}
        @JavascriptInterface public String updatePortfolio(String insCode,double quantity,double buyPrice,double stopPrice,double targetPrice){try{JSONArray a=new JSONArray(getPortfolioRaw());boolean found=false;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&insCode.equals(x.optString("insCode",""))){x.put("quantity",Math.max(0,quantity));x.put("buyPrice",Math.max(0,buyPrice));x.put("stopPrice",Math.max(0,stopPrice));x.put("targetPrice",Math.max(0,targetPrice));found=true;break;}}if(!found)return errorJson("سهم در پرتفوی پیدا نشد");savePortfolio(a);return okJson("اطلاعات سهم ویرایش شد");}catch(Exception e){return errorJson("خطا در ویرایش سهم");}}
        @JavascriptInterface public void portfolioActionAsync(String action,String insCode,boolean enabled,double quantity,double buyPrice,double stopPrice,double targetPrice){
            new Thread(() -> {
                String result;
                try {
                    if("remove".equals(action)) result=removePortfolio(insCode);
                    else if("toggle".equals(action)) result=togglePortfolio(insCode,enabled);
                    else if("update".equals(action)) result=updatePortfolio(insCode,quantity,buyPrice,stopPrice,targetPrice);
                    else result=errorJson("عملیات نامعتبر");
                } catch(Exception e){ result=errorJson("خطا در عملیات پرتفوی"); }
                final String js="window.receivePortfolioAction("+JSONObject.quote(result)+");";
                safeEvaluateJavascript(js);
            },"PortfolioAction").start();
        }
        @JavascriptInterface public String portfolioSnapshot(){return portfolioSnapshotJson();}
        @JavascriptInterface public void portfolioSnapshotAsync(){
            new Thread(() -> {
                String result;
                try { result = portfolioSnapshotJson(); }
                catch(Exception e){ result = errorJson("خطا در بروزرسانی پرتفوی"); }
                final String js = "window.receivePortfolioSnapshot(" + JSONObject.quote(result) + ");";
                safeEvaluateJavascript(js);
            }).start();
        }
        @JavascriptInterface public void startPortfolioMonitor(){
            try {
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED){
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},7102);
                }
                Intent i=new Intent(MainActivity.this,PortfolioMonitorService.class);
                if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
            } catch (Throwable t) {
                // Do not crash the WebView/app if Android blocks the background service.
            }
        }
        @JavascriptInterface public void stopPortfolioMonitor(){try{stopService(new Intent(MainActivity.this,PortfolioMonitorService.class));}catch(Exception ignored){}}

        private String getPortfolioRaw(){return getSharedPreferences(PREFS_NAME,MODE_PRIVATE).getString(PORTFOLIO_KEY,"[]");}
        private void savePortfolio(JSONArray a){getSharedPreferences(PREFS_NAME,MODE_PRIVATE).edit().putString(PORTFOLIO_KEY,a.toString()).apply();}
        private String portfolioJson(){return getPortfolioRaw();}
        private String okJson(String msg){try{JSONObject o=new JSONObject();o.put("ok",true);o.put("message",msg);return o.toString();}catch(Exception e){return "{\"ok\":true}";}}

        private String portfolioSnapshotJson(){
            try{
                JSONArray a=new JSONArray(getPortfolioRaw());
                JSONArray out=new JSONArray();
                for(int i=0;i<a.length();i++){
                    JSONObject item=a.optJSONObject(i); if(item==null) continue;
                    JSONObject z=new JSONObject(item.toString());
                    String code=item.optString("insCode","");
                    String itemError="";
                    try{
                        if(code.isEmpty()) throw new Exception("کد نماد در پرتفوی ثبت نشده است");
                        JSONObject ci=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceInfo/"+code));
                        JSONObject x=ci.optJSONObject("closingPriceInfo"); if(x==null)x=ci;
                        double last=num(x,"pDrCotVal","lastPrice","last","pLast");
                        double close=num(x,"pClosing","close","closePrice");
                        double y=num(x,"pYester","pYesterday","yesterdayPrice","priceYesterday");
                        if(last<=0 && close>0) last=close;
                        if(last<=0) throw new Exception("قیمت جاری از TSETMC دریافت نشد");
                        double q=item.optDouble("quantity",0),bp=item.optDouble("buyPrice",0);
                        z.put("last",last); z.put("close",close); z.put("changePct",y>0?(last/y-1)*100:0);
                        z.put("marketValue",last*q); z.put("pnl",bp>0?(last-bp)*q:0); z.put("pnlPct",bp>0?(last/bp-1)*100:0);
                        QueueStatus qs=getQueueSnapshot(code,close>0?close:last);
                        z.put("buyQueue",qs.isBuyQueue); z.put("sellQueue",qs.isSellQueue);
                        z.put("buyQueueVolume",qs.buyVolume); z.put("sellQueueVolume",qs.sellVolume);
                        z.put("dataOk",true);
                    }catch(Exception ex){
                        itemError=ex.getMessage()==null?"خطای دریافت داده":ex.getMessage();
                        z.put("dataOk",false); z.put("dataError",itemError);
                    }
                    out.put(z);
                }
                JSONObject r=new JSONObject(); r.put("ok",true); r.put("items",out);
                r.put("monitorNote","رصد بازار فقط در ساعات رسمی بازار فعال می‌شود؛ اعلان‌ها اطلاع‌رسانی تحلیلی هستند و سفارش خودکار ثبت نمی‌کنند.");
                return r.toString();
            }catch(Exception e){return errorJson("خطا در خواندن پرتفوی: "+(e.getMessage()==null?"نامشخص":e.getMessage()));}
        }

        private void dailyPanel(){
            if(!operationBusy.compareAndSet(false,true)){
                final String js="window.receiveDailyPanel("+JSONObject.quote(errorJson("یک عملیات دیگر در حال اجراست؛ پس از پایان آن دوباره امتحان کنید"))+");";
                safeEvaluateJavascript(js);
                return;
            }
            new Thread(() -> {
                String result;
                try { result = buildDailyPanel(); }
                catch(Exception e){ result=errorJson(e.getMessage()==null?"خطا در پنل معاملات امروز":e.getMessage()); }
                finally { operationBusy.set(false); }
                final String js="window.receiveDailyPanel("+JSONObject.quote(result)+");";
                safeEvaluateJavascript(js);
            }).start();
        }
    }

    private String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        c.setRequestProperty("Accept", "application/json,text/plain,*/*");
        int code = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close(); c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("TSETMC HTTP " + code);
        return b.toString();
    }

    private String analyzeSymbol(String symbol) throws Exception {
        String q = URLEncoder.encode(symbol.trim(), "UTF-8").replace("+", "%20");
        JSONObject search = new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentSearch/" + q));
        JSONArray arr = search.optJSONArray("instrumentSearch");
        if (arr == null) arr = search.optJSONArray("instrument");
        if (arr == null) arr = search.optJSONArray("instruments");
        if (arr == null) arr = search.optJSONArray("data");
        if (arr == null) throw new Exception("نماد پیدا نشد");
        String insCode = null, title = symbol;
        for (int i=0;i<arr.length();i++) {
            JSONObject x = arr.optJSONObject(i); if (x == null) continue;
            String code = x.optString("insCode", "");
            if (code.length() > 0) { insCode = code; title = x.optString("lVal30", x.optString("lVal18AFC", symbol)); break; }
        }
        if (insCode == null) throw new Exception("نماد پیدا نشد");
        MarketRegime market;
        try { market = getMarketRegime(); } catch(Exception ignored) { market = new MarketRegime(5,"خنثی (داده شاخص در دسترس نیست)"); }
        return analyzeInsCode(insCode, title, market);
    }

    private String analyzeInsCode(String insCode, String title, MarketRegime market) throws Exception {
        JSONObject histObj = new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/" + insCode + "/300"));
        JSONArray raw = histObj.optJSONArray("closingPriceDaily");
        if (raw == null || raw.length() < 60) throw new Exception("داده تاریخی کافی نیست");
        List<Row> rows = new ArrayList<>();
        for (int i=0;i<raw.length();i++) {
            JSONObject x=raw.optJSONObject(i); if(x==null) continue;
            double close=num(x,"pClosing","close","Close");
            double open=num(x,"priceFirst","pOpen","open","Open");
            double high=num(x,"priceMax","pHigh","high","High");
            double low=num(x,"priceMin","pLow","low","Low");
            double vol=num(x,"qTotTran5J","volume","Volume");
            if(close>0) rows.add(new Row(close,open,high,low,vol,x.optInt("dEven",0)));
        }
        Collections.sort(rows, Comparator.comparingInt(a -> a.date));
        if(rows.size()<60) throw new Exception("داده تاریخی کافی نیست");
        int n=rows.size()-1; Row cur=rows.get(n);

        // --- Trend: 20 points ---
        double ma20=avgClose(rows,n,20), ma50=avgClose(rows,n,50), avgVol20=avgVol(rows,n,20);
        double rsi=rsi(rows,n,14);
        double macd=ema(rows,n,12)-ema(rows,n,26), prevMacd=ema(rows,n-1,12)-ema(rows,n-1,26);
        double adx=adx(rows,n,14);
        double mfi=mfi(rows,n,14);
        double resistance=highest(rows,n-1,20);

        int score=0;
        int trendScore=0, momentumScore=0, volumeScore=0, breakoutScore=0, liquidityScore=0, mfiScore=0, marketScore=0, riskScore=0;
        List<String> reasons=new ArrayList<>();
        List<String> warnings=new ArrayList<>();

        // --- Trend: 20 points, strength-weighted instead of four binary 5/5 gates ---
        double prevMa20=avgClose(rows,n-1,20);
        double closeVsMa20=ma20>0?(cur.close/ma20-1)*100:0;
        double closeVsMa50=ma50>0?(cur.close/ma50-1)*100:0;
        double maSpread=ma50>0?(ma20/ma50-1)*100:0;
        double maSlope=prevMa20>0?(ma20/prevMa20-1)*100:0;
        int t1=closeVsMa20>=3?5:closeVsMa20>=1?4:closeVsMa20>0?3:closeVsMa20>=-1?1:0;
        int t2=closeVsMa50>=4?5:closeVsMa50>=1.5?4:closeVsMa50>0?3:closeVsMa50>=-1?1:0;
        int t3=maSpread>=3?5:maSpread>=1?4:maSpread>0?3:maSpread>=-1?1:0;
        int t4=maSlope>=1?5:maSlope>=0.3?4:maSlope>0?3:maSlope>=-0.3?1:0;
        score+=t1+t2+t3+t4; trendScore+=t1+t2+t3+t4;
        if(t1>=3) reasons.add("قیمت بالای میانگین ۲۰ روزه است");
        if(t2>=3) reasons.add("قیمت بالای میانگین ۵۰ روزه است");
        if(t3>=3) reasons.add("فاصله میانگین‌های ۲۰ و ۵۰ روزه مثبت است");
        if(t4>=3) reasons.add("شیب میانگین ۲۰ روزه مثبت است");
        if(t1<=1 || t2<=1) warnings.add("فاصله قیمت از میانگین‌های کوتاه/میان‌مدت ضعیف است");

        // --- Momentum: 15 points ---
        if(rsi>=50 && rsi<=65){score+=5; momentumScore+=5; reasons.add("RSI در محدوده مناسب است");}
        else if(rsi>65 && rsi<=70){score+=3; momentumScore+=3; reasons.add("مومنتوم مثبت است");}
        else if(rsi>70){warnings.add("RSI بالاست؛ ورود می‌تواند پرریسک‌تر باشد");}
        else if(rsi<40){warnings.add("RSI ضعیف است");}
        if(macd>0){score+=3; momentumScore+=3; reasons.add("MACD مثبت است");}
        if(macd>prevMacd){score+=2; momentumScore+=2; reasons.add("مومنتوم MACD رو به بهبود است");}
        if(adx>=25){score+=5; momentumScore+=5; reasons.add("ADX قدرت روند را تأیید می‌کند");}
        else if(adx>=20){score+=3; momentumScore+=3; reasons.add("قدرت روند متوسط است");}
        else warnings.add("ADX پایین است؛ روند قدرت کافی ندارد");

        // --- Volume: 15 points (direction-aware) ---
        double vr=avgVol20>0?cur.vol/avgVol20:0;
        boolean positiveCandle=cur.close>=cur.open && cur.close>=rows.get(Math.max(0,n-1)).close;
        if(positiveCandle){
            if(vr>=2){score+=15; volumeScore+=15; reasons.add("حجم بالا همراه حرکت مثبت قیمت است");}
            else if(vr>=1.5){score+=12; volumeScore+=12; reasons.add("حجم معاملات قوی و هم‌جهت با قیمت است");}
            else if(vr>=1.2){score+=8; volumeScore+=8; reasons.add("حجم معاملات بالاتر از میانگین است");}
            else if(vr>=1.0){score+=4; volumeScore+=4; reasons.add("حجم معاملات تأیید نسبی دارد");}
            else warnings.add("حجم معاملات پایین‌تر از میانگین است");
        } else if(vr>=1.2){
            warnings.add("حجم بالا همراه فشار فروش است؛ حجم به‌تنهایی سیگنال خرید نیست");
        } else if(vr<1.0){
            warnings.add("حجم معاملات پایین‌تر از میانگین است");
        }

        // --- Breakout / structure: 15 points ---
        if(cur.close>resistance && cur.close>=cur.open && cur.vol>=avgVol20*1.2){score+=15; breakoutScore+=15; reasons.add("شکست مقاومت با تأیید قیمت و حجم");}
        else if(cur.close>resistance && cur.close>=cur.open){score+=8; breakoutScore+=8; warnings.add("شکست مقاومت هنوز تأیید حجمی کامل ندارد");}
        else warnings.add("هنوز شکست مقاومت ۲۰ روزه تأیید نشده است");

        // --- Smart liquidity: Hot Money 10 + Anomaly/Rent-risk 5 = 15 points ---
        ClientData ct = getLatestClientType(insCode, cur.date);
        double buyerPower=0, realMoneyFlow=0, hotMoneyScore=0, anomalyScore=0; double volumeShock=0, moneyShock=0, persistenceShock=0, noBreakout=0, accelerationShock=0;
        int rentConfidence=0;
        String rentConfidenceLabel="نامشخص";
        if(ct != null) {
            double avgBuy = ct.buyIValue>0 && ct.buyICount>0 ? ct.buyIValue/ct.buyICount : 0;
            double avgSell = ct.sellIValue>0 && ct.sellICount>0 ? ct.sellIValue/ct.sellICount : 0;
            buyerPower = avgSell>0 ? avgBuy/avgSell : 0;
            realMoneyFlow = ct.buyIValue - ct.sellIValue;
            double flowRatio = (ct.buyIValue + ct.sellIValue)>0 ? realMoneyFlow/(ct.buyIValue + ct.sellIValue) : 0;
            double fiveDayFlow=0, fiveDayTurnover=0; int posFlowDays=0, activeDays=0;
            try {
                JSONObject co=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/"+insCode));
                JSONArray ca=co.optJSONArray("clientType");
                if(ca!=null){
                    List<JSONObject> hist=new ArrayList<>();
                    for(int i=0;i<ca.length();i++){ JSONObject x=ca.optJSONObject(i); if(x!=null && x.optInt("recDate",0)<=cur.date) hist.add(x); }
                    Collections.sort(hist,(a,b)->Integer.compare(b.optInt("recDate",0),a.optInt("recDate",0)));
                    for(JSONObject x:hist){
                        double bv=x.optDouble("buy_I_Value",0), sv=x.optDouble("sell_I_Value",0);
                        double f=bv-sv;
                        if(activeDays<5){ fiveDayFlow+=f; fiveDayTurnover+=(bv+sv); if(f>0)posFlowDays++; activeDays++; }
                    }
                }
            } catch(Exception ignored) {}
            double flowPct=Math.max(0,Math.min(100,flowRatio*500));
            double powerPts=buyerPower>=2?25:buyerPower>=1.5?20:buyerPower>=1.2?15:buyerPower>=1.0?9:buyerPower>=0.8?4:0;
            double volPts=vr>=3?25:vr>=2?20:vr>=1.5?15:vr>=1.2?9:0;
            double persistence=activeDays>0?(posFlowDays/(double)activeDays)*25:0;
            double flowStrength=fiveDayTurnover>0?Math.max(0,Math.min(25,(fiveDayFlow/fiveDayTurnover)*250)):0;
            hotMoneyScore=Math.round(Math.max(0,Math.min(100,powerPts+volPts+flowStrength+persistence)));
            if(buyerPower>0 && buyerPower<0.80) hotMoneyScore=Math.min(hotMoneyScore,35);
            if(realMoneyFlow<0) hotMoneyScore=Math.min(hotMoneyScore,45);
            if(hotMoneyScore>=80){score+=10; liquidityScore+=10; reasons.add("پول داغ و ورود نقدینگی قوی است");}
            else if(hotMoneyScore>=60){score+=8; liquidityScore+=8; reasons.add("ورود نقدینگی قابل توجه است");}
            else if(hotMoneyScore>=40){score+=5; liquidityScore+=5; reasons.add("نشانه‌هایی از ورود نقدینگی دیده می‌شود");}
            else if(flowRatio<-0.02) warnings.add("خروج پول حقیقی دیده می‌شود");

            // Anomaly score is a screening flag, not proof of insider trading.
            double signedAcceleration=(cur.close>0 && rows.get(Math.max(0,n-3)).close>0 ? (cur.close/rows.get(Math.max(0,n-3)).close-1)*100 : 0);
            volumeShock=Math.max(0,Math.min(35,(vr-1)*18));
            // Rent/anomaly score must reward corroborating positive evidence, not price fall or money outflow.
            moneyShock=Math.max(0,Math.min(30,flowRatio*300));
            persistenceShock=posFlowDays>=4?20:posFlowDays>=3?15:posFlowDays>=2?8:0;
            noBreakout=(cur.close<=resistance && vr>=1.8 && realMoneyFlow>0)?15:0;
            accelerationShock=Math.min(15,Math.max(0,signedAcceleration)*2);
            anomalyScore=Math.round(Math.max(0,Math.min(100,volumeShock+moneyShock+persistenceShock+noBreakout+accelerationShock)));
            // Evidence confidence is independent of the anomaly score: it rises only when multiple distinct signals agree.
            int evidence=0;
            if(vr>=1.5) evidence+=20; else if(vr>=1.2) evidence+=10;
            if(flowRatio>=0.05) evidence+=20; else if(flowRatio>=0.02) evidence+=12; else if(flowRatio>0) evidence+=6;
            if(posFlowDays>=4) evidence+=20; else if(posFlowDays>=3) evidence+=15; else if(posFlowDays>=2) evidence+=8;
            if(buyerPower>=1.5) evidence+=20; else if(buyerPower>=1.2) evidence+=14; else if(buyerPower>=1.0) evidence+=7;
            if(signedAcceleration>=3) evidence+=20; else if(signedAcceleration>=1.5) evidence+=12; else if(signedAcceleration>0) evidence+=6;
            rentConfidence=Math.min(100,evidence);
            rentConfidenceLabel=rentConfidence>=80?"بالا":rentConfidence>=60?"متوسط":rentConfidence>=40?"ضعیف":"نامشخص";
            if(anomalyScore>=75 && rentConfidence>=70) warnings.add("رفتار غیرعادی با چند شاهد هم‌جهت دیده می‌شود؛ نیازمند بررسی مستقل است");
            else if(anomalyScore>=55) warnings.add("رفتار معاملاتی غیرعادی دیده می‌شود");
        } else {
            warnings.add("داده حقیقی/حقوقی برای آخرین روز در دسترس نیست");
        }

        // --- MFI: 5 points, complementary price-volume money-flow confirmation ---
        if(mfi>=60){score+=5; mfiScore+=5; reasons.add("MFI ورود نقدینگی را تأیید می‌کند");}
        else if(mfi>=50){score+=3; mfiScore+=3; reasons.add("MFI خنثی رو به مثبت است");}
        else if(mfi<40) warnings.add("MFI ضعیف است؛ فشار فروش پولی دیده می‌شود");

        // --- Market regime: 10 points ---
        score += market.score; marketScore=market.score;
        if(market.score>=8) reasons.add("رژیم کلی بازار مساعد است");
        else if(market.score>=5) reasons.add("رژیم کلی بازار خنثی است");
        else warnings.add("رژیم کلی بازار ضعیف است");

        // --- Risk: 10 points ---
        double atr=atr(rows,n,14);
        double stop = technicalStop(rows,n,14,30,0.25);
        double riskPct = cur.close>0 ? (cur.close-stop)/cur.close*100.0 : 100;
        // Never fake a stop with an arbitrary percentage. If the nearest valid
        // technical support is too far away, the setup is simply too risky for
        // a short-term BUY and must not be converted into an artificial 8% stop.
        if(cur.close>0 && riskPct>12.0){
            warnings.add("حد ضرر تکنیکال بیش از ۱۲٪ فاصله دارد؛ این سیگنال برای ورود کوتاه‌مدت مناسب نیست");
        }
        if(riskPct<=4){score+=10; riskScore+=10; reasons.add("ریسک حد ضرر پایین است");}
        else if(riskPct<=6){score+=8; riskScore+=8; reasons.add("فاصله حد ضرر قابل قبول است");}
        else if(riskPct<=8){score+=6; riskScore+=6; reasons.add("ریسک متوسط است");}
        else if(riskPct<=12){score+=3; riskScore+=3; warnings.add("فاصله حد ضرر نسبتاً زیاد است");}
        else warnings.add("فاصله حد ضرر زیاد است؛ ورود پرریسک است");

        score=Math.max(0,Math.min(100,score));
        int rawScore=score;
        String action=score>=70?"BUY":score>=55?"WATCH":"EXIT/NO_ENTRY";
        if(riskPct>12.0){ score=Math.min(score,69); action="WATCH"; }

        // Live buy-queue detection. A BUY signal while locked at the upper price
        // limit is NOT an instruction to chase the queue. It becomes BUY_QUEUE:
        // wait for the queue to open, then re-check the signal and actual entry price.
        QueueStatus queueStatus = detectBuyQueue(insCode, cur.close);

        // Hard confirmation gates: prevent a high composite score from overriding a clearly weak setup.
        if(buyerPower>0 && buyerPower<0.80){
            score=Math.min(score,69);
            warnings.add("قدرت خریدار زیر ۰٫۸۰ است؛ امتیاز بالا به‌تنهایی مجوز ورود نیست");
            action="WATCH";
        }
        if(buyerPower>0 && buyerPower<0.65 && realMoneyFlow<=0){
            score=Math.min(score,54);
            warnings.add("قدرت خریدار بسیار ضعیف و جریان پول حقیقی منفی است");
            action="EXIT/NO_ENTRY";
        }
        if(rsi>75){
            score=Math.min(score,69);
            warnings.add("RSI بیش‌خرید شدید دارد؛ ورود جدید تأیید نمی‌شود");
            action="WATCH";
        }
        if(market.score<=2){
            score=Math.min(score,69);
            warnings.add("رژیم کلی بازار ضعیف است؛ ورود کوتاه‌مدت تأیید نمی‌شود");
            action="WATCH";
        }
        if(cur.close<ma50 && rsi<45){warnings.add("روند و مومنتوم ضعیف است"); if(score>69) action="WATCH";}
        if(buyerPower>0 && buyerPower<0.8 && cur.close<ma20) { action="WATCH"; warnings.add("قدرت فروش حقیقی با روند قیمت همسو است"); }

        if("BUY".equals(action) && queueStatus.isBuyQueue){
            action="BUY_QUEUE";
            warnings.add("سهم قفل صف خرید است؛ روی صف ورود نکن. پس از بازشدن صف، سیگنال و قیمت ورود دوباره بررسی شود");
        }

        double risk=cur.close-stop;
        double target1Price=cur.close+1.5*risk;
        double target2Price=cur.close+2.5*risk;
        JSONObject out=new JSONObject();
        out.put("ok",true); out.put("symbol",title); out.put("score",score); out.put("action",action);
        out.put("entry",cur.close); out.put("stop",stop); out.put("target1",target1Price); out.put("target2",target2Price);
        out.put("buy_queue",queueStatus.isBuyQueue);
        out.put("buy_queue_volume",queueStatus.buyVolume);
        out.put("buy_queue_orders",queueStatus.buyOrders);
        out.put("buy_queue_limit",queueStatus.buyLimit); out.put("sell_queue_volume",queueStatus.sellVolume); out.put("sell_queue_orders",queueStatus.sellOrders); out.put("sell_queue_limit",queueStatus.sellLimit);
        out.put("entry_mode",queueStatus.isBuyQueue?"AFTER_QUEUE_OPEN":"NORMAL");
        JSONObject breakdown=new JSONObject();
        breakdown.put("trend",trendScore); breakdown.put("momentum",momentumScore);
        breakdown.put("volume",volumeScore); breakdown.put("breakout",breakoutScore);
        breakdown.put("liquidity",liquidityScore); breakdown.put("mfi",mfiScore);
        breakdown.put("market",marketScore); breakdown.put("risk",riskScore);
        breakdown.put("raw",rawScore);
        JSONArray caps=new JSONArray();
        if(buyerPower>0 && buyerPower<0.80 && rawScore>69) caps.put("قدرت خریدار < ۰٫۸۰ → سقف ۶۹");
        if(buyerPower>0 && buyerPower<0.65 && realMoneyFlow<=0 && rawScore>54) caps.put("قدرت خریدار < ۰٫۶۵ و جریان پول غیرمثبت → سقف ۵۴");
        if(rsi>75 && rawScore>69) caps.put("RSI > ۷۵ → سقف ۶۹");
        if(market.score<=2 && rawScore>69) caps.put("رژیم بازار ≤ ۲ → سقف ۶۹");
        if(riskPct>12.0 && rawScore>69) caps.put("ریسک حد ضرر > ۱۲٪ → سقف ۶۹");
        breakdown.put("final",score); breakdown.put("caps",caps);
        out.put("score_breakdown",breakdown);
        // Current trading-day snapshot for the single-stock trading panel.
        try {
            JSONObject today=getTodayTradingPanel(insCode,cur.close,queueStatus);
            for(java.util.Iterator<String> it=today.keys();it.hasNext();){String k=it.next(); out.put(k,today.opt(k));}
        } catch(Exception ignored) {}
        out.put("rsi",rsi);
        // --- Long-term quality score: continuous 100-point model, not a guarantee ---
        int longScore = 0;
        List<String> longReasons = new ArrayList<>();
        if(rows.size() >= 200){
            double ma200=avgClose(rows,n,200);
            double ma200Prev=avgClose(rows,n-20,200);
            double ref120=rows.get(Math.max(0,n-120)).close;
            double ref250=rows.get(Math.max(0,n-250)).close;
            double ret120=ref120>0?(cur.close/ref120-1)*100:0;
            double ret250=ref250>0?(cur.close/ref250-1)*100:0;
            double high250=highest(rows,n,250);
            double dd250=high250>0?(cur.close/high250-1)*100:0;
            double atr14=atr(rows,n,14);

            // 20: price position versus MA200 (-10% .. +15%)
            double pMa200=ma200>0?(cur.close/ma200-1)*100:0;
            double c1=clamp((pMa200+10.0)/25.0,0,1)*20;
            if(pMa200>3) longReasons.add("قیمت با فاصله مناسب بالای میانگین ۲۰۰ روزه است");
            else if(pMa200>0) longReasons.add("قیمت بالای میانگین ۲۰۰ روزه است");

            // 15: MA50/MA200 relationship (-5% .. +10%)
            double longMaSpread=ma200>0?(ma50/ma200-1)*100:0;
            double c2=clamp((longMaSpread+5.0)/15.0,0,1)*15;
            if(longMaSpread>0) longReasons.add("میانگین ۵۰ روزه بالاتر از ۲۰۰ روزه است");

            // 15: MA200 slope (-5% .. +8%)
            double slope=ma200Prev>0?(ma200/ma200Prev-1)*100:0;
            double c3=clamp((slope+5.0)/13.0,0,1)*15;
            if(slope>0) longReasons.add("شیب میانگین ۲۰۰ روزه مثبت است");

            // 20: 12-month return (-30% .. +40%)
            double c4=clamp((ret250+30.0)/70.0,0,1)*20;
            if(ret250>=10) longReasons.add("بازده حدود ۱۲ ماهه مثبت و قابل قبول است");

            // 15: 6-month return (-25% .. +30%)
            double c5=clamp((ret120+25.0)/55.0,0,1)*15;
            if(ret120>=5) longReasons.add("روند ۶ ماهه مثبت است");

            // 10: distance from annual high (-40% .. -5% preferred)
            double c6=clamp((dd250+40.0)/35.0,0,1)*10;
            if(dd250>=-15) longReasons.add("فاصله از سقف سالانه کنترل‌شده است");

            // 5: lower ATR/price = better stability
            double atrPct=cur.close>0?atr14/cur.close*100:10;
            double c7=clamp((8.0-atrPct)/5.0,0,1)*5;
            if(atrPct<4.5) longReasons.add("نوسان روزانه نسبتاً کنترل‌شده است");

            longScore=(int)Math.round(c1+c2+c3+c4+c5+c6+c7);
            longScore=Math.max(0,Math.min(100,longScore));
        }
        out.put("long_term_score",longScore);
        out.put("long_term_action",longScore>=80?"بلندمدت مناسب":(longScore>=65?"بلندمدت قابل بررسی":"بلندمدت ضعیف"));
        JSONArray longReasonsJson = new JSONArray();
        for(String reason : longReasons) longReasonsJson.put(reason);
        out.put("long_term_reasons",longReasonsJson);

        // --- Independent 1-month / 3-month horizon scores ---
        HorizonScore oneMonth = calcHorizonScore(rows, n, 21, buyerPower, realMoneyFlow, market.score);
        HorizonScore threeMonth = calcHorizonScore(rows, n, 63, buyerPower, realMoneyFlow, market.score);
        out.put("one_month_score",oneMonth.score); out.put("one_month_action",oneMonth.action);
        out.put("one_month_target",oneMonth.target); out.put("one_month_return",oneMonth.expectedReturn);
        out.put("three_month_score",threeMonth.score); out.put("three_month_action",threeMonth.action);
        out.put("three_month_target",threeMonth.target); out.put("three_month_return",threeMonth.expectedReturn);
        out.put("one_month_reasons",new JSONArray(oneMonth.reasons)); out.put("three_month_reasons",new JSONArray(threeMonth.reasons));
        // Tradeability is separate from anomaly/rent intensity: it asks whether the observed behavior is currently supported by at least one investment horizon.
        int rentTradeability=Math.max(Math.max(score,oneMonth.score),Math.max(threeMonth.score,longScore));
        String rentBestHorizon=rentTradeability==score?"کوتاه‌مدت":rentTradeability==oneMonth.score?"یک‌ماهه":rentTradeability==threeMonth.score?"سه‌ماهه":"بلندمدت";
        String rentTradeabilityLabel=rentTradeability>=75?"بالا":rentTradeability>=60?"متوسط":rentTradeability>=45?"ضعیف":"پایین";
        out.put("rent_tradeability",rentTradeability); out.put("rent_tradeability_label",rentTradeabilityLabel); out.put("rent_best_horizon",rentBestHorizon);
        out.put("risk_pct",riskPct); out.put("buyer_power",buyerPower); out.put("buyer_power_date",ct!=null?ct.date:0); out.put("buyer_power_current_day",ct!=null && ct.date==cur.date); out.put("real_money_flow",realMoneyFlow); out.put("hot_money_score",hotMoneyScore); out.put("anomaly_score",anomalyScore); out.put("rent_score",anomalyScore); out.put("rent_confidence",rentConfidence); out.put("rent_confidence_label",rentConfidenceLabel); JSONObject rentBreakdown=new JSONObject(); rentBreakdown.put("volume_shock",Math.round(volumeShock)); rentBreakdown.put("money_shock",Math.round(moneyShock)); rentBreakdown.put("persistence_shock",Math.round(persistenceShock)); rentBreakdown.put("no_breakout",Math.round(noBreakout)); rentBreakdown.put("acceleration_shock",Math.round(accelerationShock)); out.put("rent_breakdown",rentBreakdown); out.put("adx",adx); out.put("mfi",mfi); out.put("volume_ratio",vr);
        out.put("market_regime",market.label); out.put("data_rows",rows.size()); out.put("source","TSETMC");
        JSONArray patterns=detectPatterns(rows,n,vr,resistance);
        out.put("patterns",patterns);
        int patternSig=patternSignal(patterns);
        out.put("pattern_signal",patternSig);
        out.put("algorithm_flags",algorithmFlags(rows,n,rsi,adx,vr,buyerPower,realMoneyFlow));
        double dayChangePct = n>0 && rows.get(n-1).close>0 ? (cur.close/rows.get(n-1).close-1)*100 : 0;
        double prevRsi = n>1 ? rsi(rows,n-1,14) : rsi;
        double ma20Now = avgClose(rows,n,20), ma50Now = avgClose(rows,n,50);
        out.put("day_change_pct",dayChangePct); out.put("ma20",ma20Now); out.put("ma50",ma50Now); out.put("macd",macd); out.put("prev_macd",prevMacd); out.put("prev_rsi",prevRsi);

        // Golden signal: a deliberately rare quality gate. It is a confidence/quality score, not a probability.
        int goldenScore=0;
        if(trendScore>=16) goldenScore+=10; else if(trendScore>=13) goldenScore+=6;
        if(momentumScore>=11) goldenScore+=10; else if(momentumScore>=8) goldenScore+=6;
        if(volumeScore>=10) goldenScore+=10; else if(volumeScore>=8) goldenScore+=6;
        if(breakoutScore>=8) goldenScore+=10; else if(breakoutScore>=5) goldenScore+=5;
        if(liquidityScore>=7) goldenScore+=10; else if(liquidityScore>=5) goldenScore+=6;
        if(mfiScore>=3) goldenScore+=5;
        if(marketScore>=8) goldenScore+=10; else if(marketScore>=5) goldenScore+=6;
        if(riskScore>=6) goldenScore+=10; else if(riskScore>=3) goldenScore+=5;
        if(oneMonth.score>=75) goldenScore+=10; else if(oneMonth.score>=70) goldenScore+=5;
        if(threeMonth.score>=70) goldenScore+=5;
        if(longScore>=65) goldenScore+=5;
        if(buyerPower>=1.10) goldenScore+=5;
        if(realMoneyFlow>0) goldenScore+=5;
        if(adx>=25) goldenScore+=3;
        if(vr>=1.20) goldenScore+=2;
        goldenScore=Math.min(100,goldenScore);
        boolean goldenPass=goldenScore>=85 && score>=80 && oneMonth.score>=75 && threeMonth.score>=70 && longScore>=65 && buyerPower>=1.10 && realMoneyFlow>0 && adx>=25 && mfi>=55 && vr>=1.20 && riskPct<=8.0 && marketScore>=5 && patternSig>=50 && dayChangePct>=0 && !queueStatus.isBuyQueue;
        out.put("golden_score",goldenScore); out.put("golden_pass",goldenPass);
        out.put("golden_reason",goldenPass?"عبور هم‌زمان فیلترهای سخت روند، مومنتوم، حجم، نقدینگی، چند افق زمانی و ریسک":"فیلتر طلایی کامل نشده است");

        // Reversal / start-of-rise screen: this is an EARLY-MOVE filter, not a
        // generic "good stock" ranking. The price must still be negative/neutral,
        // must not be locked in a buy queue, and must not have already run hard.
        double change3d = n>=4 && rows.get(n-4).close>0 ? (cur.close/rows.get(n-4).close-1)*100.0 : 0;
        double change5d = n>=6 && rows.get(n-6).close>0 ? (cur.close/rows.get(n-6).close-1)*100.0 : 0;
        boolean earlyPriceState = dayChangePct<=0.50 && dayChangePct>=-5.0;
        boolean notAlreadyRun = change3d<=4.0 && change5d<=7.0;
        boolean notBuyLocked = !queueStatus.isBuyQueue;
        int reversalScore=0;
        if(dayChangePct<0 && dayChangePct>=-3) reversalScore+=12;
        else if(dayChangePct>=-0.50 && dayChangePct<=0.50) reversalScore+=10;
        else if(dayChangePct<0 && dayChangePct>=-5) reversalScore+=7;
        if(cur.close<=ma20Now*1.01) reversalScore+=10;
        if(rsi>=35 && rsi<=55) reversalScore+=10; else if(rsi>55 && rsi<=60) reversalScore+=5;
        if(rsi>prevRsi) reversalScore+=10;
        if(macd>prevMacd) reversalScore+=10;
        if(buyerPower>=1.10) reversalScore+=10; else if(buyerPower>=0.90) reversalScore+=5;
        if(realMoneyFlow>0) reversalScore+=10;
        if(vr>=1.10) reversalScore+=8;
        if(mfi>=45) reversalScore+=8;
        if(cur.close>lowest(rows,n,5)) reversalScore+=7;
        if(marketScore>=8) reversalScore+=7; else if(marketScore>=5) reversalScore+=4;
        if(patternSig>=40) reversalScore+=5;
        if(notAlreadyRun) reversalScore+=5;
        reversalScore=Math.min(100,reversalScore);
        boolean reversalPass=earlyPriceState && notAlreadyRun && notBuyLocked &&
                reversalScore>=70 && rsi>prevRsi && macd>prevMacd &&
                buyerPower>=0.90 && realMoneyFlow>0 && marketScore>=5;
        out.put("reversal_score",reversalScore); out.put("reversal_pass",reversalPass);
        out.put("reversal_early_price_state",earlyPriceState);
        out.put("reversal_not_already_run",notAlreadyRun);
        out.put("reversal_change_3d",change3d); out.put("reversal_change_5d",change5d);
        out.put("reversal_reason",reversalPass?"قیمت هنوز منفی/خنثی است، صف خرید ندارد و هم‌زمان مومنتوم و جریان پول در حال بهبود است":"شرایط ورود زودهنگام کامل نیست؛ سهم نباید از قبل حرکت کرده یا در صف خرید قفل شده باشد");

        out.put("reasons",new JSONArray(reasons)); out.put("warnings",new JSONArray(warnings));
        return out.toString();
    }

    private String scanMarketInternal(String scanMode) throws Exception {
        List<ScanCandidate> candidates = new ArrayList<>();
        final boolean rentModeRequested = "rent".equalsIgnoreCase(scanMode);
        final boolean goldenModeRequested = "golden".equalsIgnoreCase(scanMode);
        final boolean reversalModeRequested = "reversal".equalsIgnoreCase(scanMode);
        final boolean pharmaModeRequested = "pharma".equalsIgnoreCase(scanMode);
        final boolean cementModeRequested = "cement".equalsIgnoreCase(scanMode);
        String sourceUsed = "MarketWatch";
        StringBuilder diag = new StringBuilder();

        // Primary source: official TSETMC market watch.
        try {
            String url="https://cdn.tsetmc.com/api/ClosingPrice/GetMarketWatch?market=0&industrialGroup=&paperTypes%5B0%5D=1&paperTypes%5B1%5D=2&paperTypes%5B2%5D=3&paperTypes%5B3%5D=4&paperTypes%5B4%5D=5&paperTypes%5B5%5D=6&paperTypes%5B6%5D=7&paperTypes%5B7%5D=8&paperTypes%5B8%5D=9&showTraded=false&withBestLimits=false&hEven=0&RefID=0";
            JSONObject o=new JSONObject(httpGet(url));
            JSONArray a=o.optJSONArray("marketwatch");
            if(a!=null){
                for(int i=0;i<a.length();i++){
                    JSONObject x=a.optJSONObject(i); if(x==null) continue;
                    String code=x.optString("insCode","");
                    String sym=x.optString("lVal18AFC",x.optString("symbol",x.optString("lVal30","")));
                    double close=num(x,"pClosing","pc","priceClosing");
                    double last=num(x,"pDrCotVal","pl","priceLast");
                    double yesterday=num(x,"priceYesterday","py","yClose");
                    double vol=num(x,"qTotTran5J","tvol","volume");
                    double value=num(x,"qTotCap","tval","value");
                    int beforeSize=candidates.size();
                    addCandidate(candidates,code,sym,close,last,yesterday,vol,value);
                    if(candidates.size()>beforeSize){ ScanCandidate cc=candidates.get(candidates.size()-1); cc.group=x.optString("lSecVal",x.optString("sectorName",x.optString("industry",""))); }
                }
            }
        } catch(Exception e) { diag.append("MarketWatch=").append(e.getMessage()==null?"ERR":e.getMessage()).append("; "); }

        // Secondary source: today's closing price for all instruments.
        // This is a separate official CDN endpoint and does not depend on MarketWatch.
        if(candidates.isEmpty()){
            sourceUsed="ClosingPriceDailyAllInst";
            try {
                JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyAllInst"));
                JSONArray a=null;
                String[] keys={"closingPriceDailyAllInst","closingPriceDaily","data","items"};
                for(String k:keys){ JSONArray z=o.optJSONArray(k); if(z!=null){a=z;break;} }
                if(a!=null){
                    for(int i=0;i<a.length();i++){
                        JSONObject x=a.optJSONObject(i); if(x==null) continue;
                        String code=x.optString("insCode",x.optString("insCode1",""));
                        String sym=x.optString("lVal18AFC",x.optString("l18",x.optString("symbol",x.optString("lVal30",""))));
                        double close=num(x,"pClosing","pc","priceClosing");
                        double last=num(x,"pDrCotVal","pl","last","priceLast");
                        double yesterday=num(x,"priceYesterday","py","yClose");
                        double vol=num(x,"qTotTran5J","tvol","volume");
                        double value=num(x,"qTotCap","tval","value");
                        addCandidate(candidates,code,sym,close,last,yesterday,vol,value);
                        if(!candidates.isEmpty()){ ScanCandidate cc=candidates.get(candidates.size()-1); cc.group=x.optString("lSecVal",x.optString("sectorName","")); }
                    }
                }
            } catch(Exception e) { diag.append("ClosingPriceDailyAllInst=").append(e.getMessage()==null?"ERR":e.getMessage()).append("; "); }
        }

        // Third source: market-wide حقیقی/حقوقی snapshot. This endpoint is typically
        // available even when MarketWatch is empty. It provides one row per active
        // instrument, so it is a much better fallback than guessing a fixed symbol list.
        if(candidates.isEmpty()){
            sourceUsed="ClientTypeAll";
            try {
                JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeAll"));
                JSONArray a=o.optJSONArray("clientTypeAllDto");
                if(a!=null){
                    for(int i=0;i<a.length();i++){
                        JSONObject x=a.optJSONObject(i); if(x==null) continue;
                        String code=x.optString("insCode",x.optString("insCode1",""));
                        if(code==null || code.trim().isEmpty()) continue;
                        double buyI=num(x,"buy_I_Volume","buyIVolume");
                        double buyN=num(x,"buy_N_Volume","buyNVolume");
                        double sellI=num(x,"sell_I_Volume","sellIVolume");
                        double sellN=num(x,"sell_N_Volume","sellNVolume");
                        double activity=buyI+buyN+sellI+sellN;
                        if(activity<=0) continue;
                        // No quote fields here; rank by traded volume/activity and let
                        // the full analyzer fetch the actual price history afterwards.
                        String sym=x.optString("lVal18AFC",x.optString("l18",x.optString("symbol","")));
                        double fast=Math.log10(Math.max(1.0,activity));
                        candidates.add(new ScanCandidate(code,sym,fast,0,activity,0));
                    }
                }
            } catch(Exception e) { diag.append("ClientTypeAll=").append(e.getMessage()==null?"ERR":e.getMessage()).append("; "); }
        }

        if(candidates.isEmpty()) throw new Exception("منبع کل بازار در دسترس نیست؛ دریافت نمادهای فعال از TSETMC انجام نشد | "+diag.toString());

        // If the all-instruments endpoint does not carry symbol names, resolve names only
        // for the most active candidates rather than making thousands of requests.
        Collections.sort(candidates,(u,v)->Double.compare(v.fast,u.fast));
        // Rent/anomaly scan needs a wider universe because the most-traded names are
        // often index-heavy mega-caps. Resolve more names in rent mode, then remove
        // the main index-makers before diversification. Other scan modes stay unchanged.
        int resolveCount=Math.min((rentModeRequested||goldenModeRequested||reversalModeRequested||pharmaModeRequested||cementModeRequested)?80:24,candidates.size());
        ExecutorService namePool=Executors.newFixedThreadPool(4);
        List<Future<?>> nameJobs=new ArrayList<>();
        for(int i=0;i<resolveCount;i++){
            final ScanCandidate c=candidates.get(i);
            if(c.symbol==null || c.symbol.trim().isEmpty() || c.symbol.equals(c.code)){
                nameJobs.add(namePool.submit(()->resolveCandidateName(c)));
            }
        }
        for(Future<?> f:nameJobs){try{f.get();}catch(Exception ignored){}}
        namePool.shutdown();
        candidates.removeIf(c -> c.symbol==null || c.symbol.trim().isEmpty() || c.symbol.equals(c.code));
        if(candidates.isEmpty()) throw new Exception("نمادهای فعال پیدا شدند اما نام نمادها از TSETMC قابل دریافت نبود");

        Collections.sort(candidates,(u,v)->Double.compare(v.fast,u.fast));

        if(rentModeRequested){
            int before=candidates.size();
            candidates.removeIf(c -> isIndexHeavySymbol(c.symbol));
            diag.append("rent_non_index_filter=").append(before-candidates.size()).append(";");
        }

        // Resolve sector before diversification. The earlier parallel burst could be
        // throttled by TSETMC, leaving every candidate as "سایر". Keep this bounded
        // and deliberately gentle: only the most active candidates are enriched, with
        // a small retry per symbol.
        int sectorResolveCount=Math.min((pharmaModeRequested||cementModeRequested)?240:(rentModeRequested||goldenModeRequested||reversalModeRequested?100:40),candidates.size());
        if(pharmaModeRequested||cementModeRequested){
            ExecutorService sectorPool=Executors.newFixedThreadPool(4);
            List<Future<?>> sectorJobs=new ArrayList<>();
            for(int i=0;i<sectorResolveCount;i++){
                final ScanCandidate c=candidates.get(i);
                if(c.group==null || c.group.trim().isEmpty()) sectorJobs.add(sectorPool.submit(()->resolveCandidateSector(c)));
            }
            for(Future<?> f:sectorJobs){try{f.get();}catch(Exception ignored){}}
            sectorPool.shutdown();
        }else{
            for(int i=0;i<sectorResolveCount;i++){
                ScanCandidate c=candidates.get(i);
                if(c.group==null || c.group.trim().isEmpty()) resolveCandidateSector(c);
            }
        }

        // Industry-specific short-term screens: if TSETMC sector metadata is unavailable,
        // add a small verified-symbol fallback universe so the tab does not fail merely because
        // the sector field was omitted by an endpoint. These are screening fallbacks, not claims
        // about a company's fundamentals.
        if(pharmaModeRequested) addSectorFallbackCandidates(candidates, new String[]{
            "دسبحا","دعبید","دالبر","دکوثر","دزهراوی","دجابر","دتماد","داسوه","دلقما","دابور",
            "دسانکو","دفارا","دپارس","دکیمی","دشیمی","دتولید","درازک","دیران","والبر","تیپیکو","برکت"
        }, "دارویی");
        if(cementModeRequested) addSectorFallbackCandidates(candidates, new String[]{
            "ساروج","سخوز","ساربیل","سپاها","سبهان","سغرب","سکرما","سقاین","سشمال","سدشت",
            "سخاش","سبزوا","سیلام","سکرد","سفانو","سفارس","ساراب","سنیر","سبجنو","سمازن",
            "سهرمز","سخزر","سشرق","ساروم","سصوفی","ساوه","سجام"
        }, "سیمانی");
        if(pharmaModeRequested) candidates.removeIf(c -> !isPharmaGroup(c.group));
        if(cementModeRequested) candidates.removeIf(c -> !isCementGroup(c.group));
        if((pharmaModeRequested||cementModeRequested) && candidates.isEmpty())
            throw new Exception(pharmaModeRequested?"هیچ نماد دارویی در داده گروهی TSETMC شناسایی نشد؛ منبع گروهی در دسترس نیست":"هیچ نماد سیمانی در داده گروهی TSETMC شناسایی نشد؛ منبع گروهی در دسترس نیست");

        // For quality screens use a wider deep set; strict filters are applied only after analysis.
        int deepLimit=(goldenModeRequested||reversalModeRequested)?32:(pharmaModeRequested||cementModeRequested)?24:12;
        List<ScanCandidate> selected=diversifyCandidates(candidates,deepLimit,2);
        int fullCount=selected.size();
        MarketRegime sharedMarket=getMarketRegime();
        List<JSONObject> results=new ArrayList<>();
        JSONArray scanErrors=new JSONArray();
        java.util.HashMap<String,String> groupByCode=new java.util.HashMap<>();
        for(ScanCandidate c:selected) groupByCode.put(c.code,(c.group==null||c.group.trim().isEmpty())?"سایر":c.group.trim());
        // Analyze strictly one symbol at a time to avoid Android memory pressure from multiple large TSETMC JSON payloads.
        for(ScanCandidate c:selected){
            try{
                String raw=analyzeInsCode(c.code,c.symbol,sharedMarket);
                JSONObject r=new JSONObject(raw);
                if(r.optBoolean("ok",false)){
                    String g=groupByCode.get(r.optString("insCode",""));
                    if(g!=null) r.put("group",g);
                    results.add(r);
                } else {
                    JSONObject er=new JSONObject();
                    er.put("symbol",c.symbol);
                    er.put("insCode",c.code);
                    er.put("error",r.optString("error","analysis returned ok=false"));
                    scanErrors.put(er);
                }
            }catch(Exception e){
                JSONObject er=new JSONObject();
                try{
                    er.put("symbol",c.symbol);
                    er.put("insCode",c.code);
                    er.put("error",e.getClass().getSimpleName()+": "+(e.getMessage()==null?"unknown":e.getMessage()));
                    scanErrors.put(er);
                }catch(Exception ignored){}
            }
            System.gc();
        }
        final boolean longMode = "long".equalsIgnoreCase(scanMode);
        final boolean monthMode = "month".equalsIgnoreCase(scanMode);
        final boolean quarterMode = "quarter".equalsIgnoreCase(scanMode);
        final boolean rentMode = "rent".equalsIgnoreCase(scanMode);
        final boolean goldenMode = "golden".equalsIgnoreCase(scanMode);
        final boolean reversalMode = "reversal".equalsIgnoreCase(scanMode);
        final boolean pharmaMode = "pharma".equalsIgnoreCase(scanMode);
        final boolean cementMode = "cement".equalsIgnoreCase(scanMode);
        String scoreKey = longMode ? "long_term_score" : monthMode ? "one_month_score" : quarterMode ? "three_month_score" : rentMode ? "rent_score" : goldenMode ? "golden_score" : reversalMode ? "reversal_score" : "score";
        int analyzedBeforeFilter=results.size();
        if(goldenMode){
            List<JSONObject> passed=new ArrayList<>(); for(JSONObject u:results) if(u.optBoolean("golden_pass",false)) passed.add(u);
            if(!passed.isEmpty()) results=passed; else { results.sort((a,b)->Integer.compare(b.optInt("golden_score",0),a.optInt("golden_score",0))); for(JSONObject u:results) u.put("signal_status","نزدیک به طلایی — فیلتر کامل نشده"); }
        }
        if(reversalMode){
            List<JSONObject> passed=new ArrayList<>(); for(JSONObject u:results) if(u.optBoolean("reversal_pass",false)) passed.add(u);
            // Do NOT fill this screen with weak/fake candidates when no real setup exists.
            // Empty is preferable to showing a stock that has already started running.
            results=passed;
        }
        if(pharmaMode){
            List<JSONObject> passed=new ArrayList<>(); for(JSONObject u:results) if(u.optInt("score",0)>=65 && u.optDouble("buyer_power",0)>=0.90 && u.optDouble("real_money_flow",0)>0 && u.optDouble("volume_ratio",0)>=1.00 && u.optDouble("rsi",50)>=40 && u.optDouble("rsi",50)<=75) passed.add(u);
            if(!passed.isEmpty()) results=passed; else { results.removeIf(u->u.optInt("score",0)<55); for(JSONObject u:results) u.put("signal_status","کاندیدای دارویی — فیلتر کامل نشده"); }
        }
        if(cementMode){
            List<JSONObject> passed=new ArrayList<>(); for(JSONObject u:results) if(u.optInt("score",0)>=65 && u.optDouble("buyer_power",0)>=0.90 && u.optDouble("real_money_flow",0)>0 && u.optDouble("volume_ratio",0)>=1.00 && u.optDouble("adx",0)>=20) passed.add(u);
            if(!passed.isEmpty()) results=passed; else { results.removeIf(u->u.optInt("score",0)<55); for(JSONObject u:results) u.put("signal_status","کاندیدای سیمانی — فیلتر کامل نشده"); }
        }
        if(rentMode) Collections.sort(results,(u,v)->{int c=Integer.compare(v.optInt("rent_confidence",0),u.optInt("rent_confidence",0)); return c!=0?c:Integer.compare(v.optInt("rent_score",0),u.optInt("rent_score",0));});
        else Collections.sort(results,(u,v)->Integer.compare(v.optInt(scoreKey,0),u.optInt(scoreKey,0)));
        JSONArray top=new JSONArray();
        int limit=Math.min(20,results.size());
        for(int i=0;i<limit;i++) top.put(results.get(i));
        JSONObject out=new JSONObject();
        out.put("ok",true); out.put("market_symbols",candidates.size()); out.put("diversified_candidates",selected.size()); out.put("full_analyzed",results.size()); out.put("scan_errors",scanErrors); out.put("results",top);
        String modeOut = longMode?"long":monthMode?"month":quarterMode?"quarter":rentMode?"rent":goldenMode?"golden":reversalMode?"reversal":pharmaMode?"pharma":cementMode?"cement":"short";
        out.put("mode",modeOut);
        out.put("source",sourceUsed);
        String note = longMode ? "حالت بلندمدت بر اساس روند ۲۰۰ روزه، بازده چندماهه و پایداری حرکت رتبه‌بندی شده است؛ امتیاز تضمین سود نیست." :
                monthMode ? "افق یک‌ماهه بر اساس روند ۲۱ روزه، مومنتوم، قدرت روند، نقدینگی و فاصله از هدف رتبه‌بندی شده است؛ امتیاز تضمین سود نیست." :
                quarterMode ? "افق سه‌ماهه بر اساس روند ۶۳ روزه، ساختار قیمت، مومنتوم، نقدینگی و قدرت روند رتبه‌بندی شده است؛ امتیاز تضمین سود نیست." :
                rentMode ? "این خروجی ابتدا سهام شاخص‌ساز اصلی را کنار می‌گذارد و سپس بین نمادهای غیرشاخص‌ساز، رفتار غیرعادی را با چند شاهد مستقل غربال می‌کند. «اعتبار شواهد» کیفیت هم‌جهتی داده‌هاست و اثبات رانت یا اطلاعات نهانی نیست." :
                goldenMode ? "سیگنال طلایی عمداً کم‌تعداد است و فقط در صورت عبور هم‌زمان از فیلترهای سخت روند، مومنتوم، حجم، نقدینگی، چند افق زمانی، ریسک و بازار نمایش داده می‌شود. امتیاز طلایی ۸۰٪ احتمال موفقیت یا تضمین سود نیست." :
                reversalMode ? "این خروجی فقط ستاپ‌های واقعاً زودهنگام را نشان می‌دهد: قیمت منفی/خنثی، بدون صف خرید، بدون رشد شدید چندروزه و با بهبود هم‌زمان مومنتوم و جریان پول. اگر ستاپ معتبر نباشد، خروجی خالی می‌ماند." :
                pharmaMode ? "اسکن کوتاه‌مدت تخصصی گروه دارویی است؛ ابتدا گروه جدا می‌شود و سپس امتیاز، قدرت خریدار، ورود پول، حجم و RSI بررسی می‌شوند. در نبود سیگنال کامل، کاندیدای نزدیک جداگانه نمایش داده می‌شود." :
                cementMode ? "اسکن کوتاه‌مدت تخصصی گروه سیمانی است؛ ابتدا گروه جدا می‌شود و سپس امتیاز، قدرت خریدار، ورود پول، حجم و ADX بررسی می‌شوند. در نبود سیگنال کامل، کاندیدای نزدیک جداگانه نمایش داده می‌شود." :
                "حالت کوتاه‌مدت بر اساس مومنتوم، حجم، نقدینگی، شکست مقاومت و ریسک رتبه‌بندی شده است؛ «خروج» هدف اول و سود آن نسبت به قیمت ورود نمایش داده می‌شود.";
        out.put("note",note);
        return out.toString();
    }


    private String backtestMarketInternal() throws Exception {
        List<ScanCandidate> candidates = getBacktestCandidates(60);
        if(candidates.size()<10) throw new Exception("نماد فعال کافی برای بک‌تست پیدا نشد");
        final int minHistory=100;
        ExecutorService pool=Executors.newFixedThreadPool(4);
        List<Future<BacktestSymbol>> jobs=new ArrayList<>();
        for(ScanCandidate c:candidates) jobs.add(pool.submit(() -> loadBacktestSymbol(c)));
        List<BacktestSymbol> symbols=new ArrayList<>();
        for(Future<BacktestSymbol> f:jobs){try{BacktestSymbol b=f.get(); if(b!=null && b.rows.size()>=minHistory) symbols.add(b);}catch(Exception ignored){}}
        pool.shutdown();
        if(symbols.size()<10) throw new Exception("تاریخچه کافی برای بک‌تست در دسترس نیست");

        List<IndexPoint> index=loadIndexHistory();
        JSONObject out=new JSONObject(); out.put("ok",true); out.put("symbols",symbols.size()); out.put("requested_symbols",candidates.size()); out.put("days",260);
        out.put("short",runHorizonBacktest(symbols,index,10));
        out.put("month",runHorizonBacktest(symbols,index,21));
        out.put("quarter",runHorizonBacktest(symbols,index,63));
        out.put("note","بک‌تست هر افق مستقل انجام می‌شود و سیگنال هر روز فقط با داده‌های همان روز و قبل از آن ساخته می‌شود. کوتاه‌مدت ۱۰، یک‌ماهه ۲۱ و سه‌ماهه ۶۳ روز معاملاتی بعد بررسی می‌شوند. "+symbols.size()+" نماد فعال دارای داده کافی نمونه آزمون هستند. Max DD در این نسخه به‌صورت توالی معاملات با وزن مساوی محاسبه می‌شود و شبیه‌سازی یک پرتفوی کاملاً سرمایه‌گذاری‌شده نیست؛ نتیجه برای کل بازار یا آینده تضمین نیست.");
        return out.toString();
    }

    private JSONObject runHorizonBacktest(List<BacktestSymbol> symbols,List<IndexPoint> index,int horizon){
        int evaluated=0,total=0,wins=0,stops=0,timeout=0,positive=0,negative=0;
        double grossProfit=0,grossLoss=0,sumReturn=0,sumPositive=0,sumNegative=0;
        double maxDD=0;
        double equity=100.0,peak=equity;
        int[] bucketN=new int[6], bucketPositive=new int[6], bucketWins=new int[6];
        List<TradeResult> tradeResults=new ArrayList<>();
        for(BacktestSymbol b:symbols){
            int start=Math.max(80,b.rows.size()-260);
            for(int i=start;i<b.rows.size()-horizon;i++){
                Row cur=b.rows.get(i); if(cur.date==0) continue;
                evaluated++;
                int marketScore=historicalMarketScore(index,cur.date);
                HistoricalSignal sig = horizon==10
                    ? evaluateHistoricalSignal(b.rows,i,b.clients,marketScore)
                    : evaluateHistoricalHorizonSignal(b.rows,i,b.clients,marketScore,horizon);
                int bi=sig.score>=90?5:sig.score>=85?4:sig.score>=80?3:sig.score>=75?2:sig.score>=70?1:0;
                bucketN[bi]++;
                if(sig.action!=1) continue;
                total++;
                boolean win=false,stop=false; int end=Math.min(b.rows.size()-1,i+horizon);
                for(int j=i+1;j<=end;j++){
                    Row r=b.rows.get(j);
                    if(r.low<=sig.stop && r.high>=sig.target){stop=true;break;}
                    if(r.low<=sig.stop){stop=true;break;}
                    if(r.high>=sig.target){win=true;break;}
                }
                double ret;
                if(stop){
                    ret=(sig.stop-cur.close)/cur.close*100.0; stops++; grossLoss+=Math.max(0,-ret);
                } else if(win){
                    ret=(sig.target-cur.close)/cur.close*100.0; wins++; grossProfit+=Math.max(0,ret); bucketWins[bi]++;
                } else {
                    Row endRow=b.rows.get(end); ret=(endRow.close-cur.close)/cur.close*100.0; timeout++;
                    if(ret>0) grossProfit+=ret; else if(ret<0) grossLoss+=-ret;
                }
                if(ret>0){positive++;sumPositive+=ret;bucketPositive[bi]++;} else if(ret<0){negative++;sumNegative+=ret;}
                sumReturn+=ret; tradeResults.add(new TradeResult(cur.date,ret));
            }
        }
        Collections.sort(tradeResults,Comparator.comparingInt(t->t.date));
        // Max DD is an equal-weight trade-sequence metric, not a claim about a fully invested portfolio.
        // Each completed signal contributes its percentage return additively in chronological order,
        // avoiding the old and misleading 100% capital compounding for every overlapping signal.
        for(TradeResult t:tradeResults){ equity+=t.ret; peak=Math.max(peak,equity); if(peak>0) maxDD=Math.max(maxDD,(peak-equity)/peak*100.0); }
        JSONObject o=new JSONObject();
        try{
            o.put("horizon",horizon); o.put("evaluated_days",evaluated); o.put("signals",total); o.put("wins",wins); o.put("stops",stops); o.put("timeouts",timeout);
            o.put("positive_trades",positive); o.put("negative_trades",negative);
            o.put("positive_rate",total>0?positive*100.0/total:0);
            o.put("target_hit_rate",total>0?wins*100.0/total:0);
            o.put("stop_rate",total>0?stops*100.0/total:0);
            o.put("timeout_rate",total>0?timeout*100.0/total:0);
            o.put("timeout_positive",Math.max(0,positive-wins));
            o.put("avg_return",total>0?sumReturn/total:0);
            o.put("avg_positive_return",positive>0?sumPositive/positive:0);
            o.put("avg_negative_return",negative>0?sumNegative/negative:0);
            o.put("profit_factor",grossLoss>0?grossProfit/grossLoss:(grossProfit>0?99:0));
            o.put("max_drawdown",maxDD);
            JSONArray buckets=new JSONArray(); String[] labels={"<70","70–74","75–79","80–84","85–89","90+"};
            for(int i=0;i<6;i++){
                JSONObject x=new JSONObject();x.put("label",labels[i]);x.put("count",bucketN[i]);x.put("positive",bucketPositive[i]);x.put("wins",bucketWins[i]);
                x.put("positive_rate",bucketN[i]>0?bucketPositive[i]*100.0/bucketN[i]:0);x.put("target_rate",bucketN[i]>0?bucketWins[i]*100.0/bucketN[i]:0);buckets.put(x);
            }
            o.put("score_distribution",buckets);
        }catch(Exception ignored){}
        return o;
    }

    private List<ScanCandidate> getBacktestCandidates(int limit) throws Exception {
        List<ScanCandidate> list=new ArrayList<>();
        try{
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeAll"));
            JSONArray a=o.optJSONArray("clientTypeAllDto");
            if(a!=null) for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                String code=x.optString("insCode",x.optString("insCode1","")); if(code.length()==0) continue;
                double act=num(x,"buy_I_Volume","buyIVolume")+num(x,"buy_N_Volume","buyNVolume")+num(x,"sell_I_Volume","sellIVolume")+num(x,"sellNVolume","sell_N_Volume");
                if(act<=0) continue; String sym=x.optString("lVal18AFC",x.optString("l18",x.optString("symbol","")));
                list.add(new ScanCandidate(code,sym,Math.log10(Math.max(1,act)),0,act,0));
            }
        }catch(Exception ignored){}
        Collections.sort(list,(a,b)->Double.compare(b.fast,a.fast));
        int n=Math.min(limit,list.size());
        List<ScanCandidate> out=new ArrayList<>(); for(int i=0;i<n;i++){ScanCandidate c=list.get(i); if(c.symbol==null||c.symbol.trim().isEmpty()||c.symbol.equals(c.code)) resolveCandidateName(c); if(c.symbol!=null&&!c.symbol.trim().isEmpty()&&!c.symbol.equals(c.code)) out.add(c);}
        return out;
    }

    private BacktestSymbol loadBacktestSymbol(ScanCandidate c){
        try{
            JSONObject h=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/"+c.code+"/0"));
            JSONArray raw=h.optJSONArray("closingPriceDaily"); if(raw==null) return null;
            List<Row> rows=new ArrayList<>();
            for(int i=0;i<raw.length();i++){JSONObject x=raw.optJSONObject(i);if(x==null)continue;double close=num(x,"pClosing","close","Close"),open=num(x,"priceFirst","pOpen","open","Open"),high=num(x,"priceMax","pHigh","high","High"),low=num(x,"priceMin","pLow","low","Low"),vol=num(x,"qTotTran5J","volume","Volume");if(close>0)rows.add(new Row(close,open,high,low,vol,x.optInt("dEven",0)));}
            Collections.sort(rows,Comparator.comparingInt(a->a.date)); if(rows.size()<80)return null;
            java.util.Map<Integer,ClientData> cm=new java.util.HashMap<>();
            try{JSONObject co=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/"+c.code));JSONArray ca=co.optJSONArray("clientType");if(ca!=null)for(int i=0;i<ca.length();i++){JSONObject x=ca.optJSONObject(i);if(x==null)continue;ClientData d=new ClientData();d.buyIValue=x.optDouble("buy_I_Value",0);d.sellIValue=x.optDouble("sell_I_Value",0);d.buyICount=x.optDouble("buy_I_Count",0);d.sellICount=x.optDouble("sell_I_Count",0);d.date=x.optInt("recDate",0);cm.put(d.date,d);}}catch(Exception ignored){}
            return new BacktestSymbol(c,rows,cm);
        }catch(Exception e){return null;}
    }

    private List<IndexPoint> fetchIndexHistory(String indexCode){
        List<IndexPoint> out=new ArrayList<>();
        try{
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/Index/GetIndexB2History/"+indexCode));
            JSONArray a=o.optJSONArray("indexB2");
            if(a==null) return out;
            java.util.HashSet<Integer> seen=new java.util.HashSet<>();
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                int d=x.optInt("dEven",x.optInt("recDate",0));
                double v=num(x,"xValue","pClosing","xClose","close","indexValue","value");
                if(d>0&&v>0&&seen.add(d)) out.add(new IndexPoint(d,v));
            }
        }catch(Exception ignored){}
        Collections.sort(out,Comparator.comparingInt(a->a.date));
        return out;
    }

    private List<IndexPoint> loadIndexHistory(){
        // Keep the known TSETMC Total Index code as primary, but fall back to
        // the currently referenced TEDPIX code if the primary endpoint is empty
        // or incomplete. This avoids treating a temporary endpoint/code issue
        // as a real neutral market regime.
        List<IndexPoint> out=fetchIndexHistory("32097828799138957");
        if(out.size()<25) out=fetchIndexHistory("32097828820363860");
        return out;
    }

    private int historicalMarketScore(List<IndexPoint> a,int date){
        if(a.size()<25)return 5; int idx=-1; for(int i=0;i<a.size();i++){if(a.get(i).date<=date)idx=i;else break;} if(idx<24)return 5;
        double now=a.get(idx).value,sum=0;for(int i=idx-19;i<=idx;i++)sum+=a.get(i).value;double m20=sum/20.0,old=a.get(idx-20).value;
        if(now>m20&&now>old*1.02)return 10;if(now>m20&&now>old)return 8;if(now>=old*.98&&now<=old*1.02)return 5;if(now<m20&&now<old*.98)return 0;return 2;
    }

    private HistoricalSignal evaluateHistoricalSignal(List<Row>a,int n,java.util.Map<Integer,ClientData> clients,int marketScore){
        if(n<60)return new HistoricalSignal(0,0,0,0);
        Row cur=a.get(n);double ma20=avgClose(a,n,20),ma50=avgClose(a,n,50),avgVol20=avgVol(a,n,20),rsi=rsi(a,n,14),macd=ema(a,n,12)-ema(a,n,26),prevMacd=ema(a,n-1,12)-ema(a,n-1,26),adx=adx(a,n,14),mfi=mfi(a,n,14),resistance=highest(a,n-1,20);int score=0;
        if(cur.close>ma20)score+=5;if(cur.close>ma50)score+=5;if(ma20>ma50)score+=5;if(ma20>avgClose(a,n-1,20))score+=5;
        if(rsi>=50&&rsi<=65)score+=5;else if(rsi>65&&rsi<=70)score+=3;if(macd>0)score+=3;if(macd>prevMacd)score+=2;if(adx>=25)score+=5;else if(adx>=20)score+=3;
        double vr=avgVol20>0?cur.vol/avgVol20:0;boolean pos=cur.close>=cur.open&&cur.close>=a.get(n-1).close;if(pos){if(vr>=2)score+=15;else if(vr>=1.5)score+=12;else if(vr>=1.2)score+=8;else if(vr>=1)score+=4;}
        if(cur.close>resistance&&cur.close>=cur.open&&cur.vol>=avgVol20*1.2)score+=15;else if(cur.close>resistance&&cur.close>=cur.open)score+=8;
        ClientData ct=clients.get(cur.date);double bp=0,flow=0; if(ct!=null){double ab=ct.buyIValue>0&&ct.buyICount>0?ct.buyIValue/ct.buyICount:0,as=ct.sellIValue>0&&ct.sellICount>0?ct.sellIValue/ct.sellICount:0;bp=as>0?ab/as:0;flow=ct.buyIValue-ct.sellIValue;double p=bp>=2?25:bp>=1.5?20:bp>=1.2?15:bp>=1?9:bp>=.8?4:0;double vp=vr>=3?25:vr>=2?20:vr>=1.5?15:vr>=1.2?9:0;double fiveF=0,fiveT=0;int posF=0,active=0;for(int j=n;j>=0&&active<5;j--){ClientData d=clients.get(a.get(j).date);if(d!=null){double f=d.buyIValue-d.sellIValue;fiveF+=f;fiveT+=d.buyIValue+d.sellIValue;if(f>0)posF++;active++;}}double flowStrength=fiveT>0?Math.max(0,Math.min(25,(fiveF/fiveT)*250)):0;double persistence=active>0?posF/(double)active*25:0;double hot=Math.max(0,Math.min(100,p+vp+flowStrength+persistence));if(bp>0&&bp<.8)hot=Math.min(hot,35);if(flow<0)hot=Math.min(hot,45);if(hot>=80)score+=10;else if(hot>=60)score+=8;else if(hot>=40)score+=5;}
        if(mfi>=60)score+=5;else if(mfi>=50)score+=3;score+=marketScore;
        double atr=atr(a,n,14),stop=technicalStop(a,n,14,30,0.25);double risk=cur.close-stop;risk=risk>0?risk:cur.close*.08;double riskPct=risk/cur.close*100;if(riskPct<=4)score+=10;else if(riskPct<=6)score+=8;else if(riskPct<=8)score+=6;else if(riskPct<=12)score+=3;
        score=Math.max(0,Math.min(100,score));int action=score>=70?1:0;if(bp>0&&bp<.8){score=Math.min(score,69);action=0;}if(bp>0&&bp<.65&&flow<=0){score=Math.min(score,54);action=0;}if(rsi>75){score=Math.min(score,69);action=0;}if(marketScore<=2){score=Math.min(score,69);action=0;}if(bp>0&&bp<.8&&cur.close<ma20)action=0;if(riskPct>12.0){score=Math.min(score,69);action=0;}
        return new HistoricalSignal(score,action,stop,cur.close+1.5*risk);
    }

    private HistoricalSignal evaluateHistoricalHorizonSignal(List<Row>a,int n,java.util.Map<Integer,ClientData> clients,int marketScore,int days){
        if(n<days+20)return new HistoricalSignal(0,0,0,0);
        Row cur=a.get(n); int ref=n-days;
        double ret=a.get(ref).close>0?(cur.close/a.get(ref).close-1)*100:0;
        double maShort=avgClose(a,n,Math.max(10,days/2)), maLong=avgClose(a,n,days), maPrev=avgClose(a,Math.max(0,n-Math.max(10,days/2)),Math.max(10,days/2));
        double rsi=rsi(a,n,14),adx=adx(a,n,14),mfi=mfi(a,n,14),vr=avgVol(a,n,20)>0?cur.vol/avgVol(a,n,20):0;
        double high=highest(a,n,days),low=lowest(a,n,days),position=high>low?(cur.close-low)/(high-low):0.5;
        ClientData ct=clients.get(cur.date); double bp=0,flow=0;
        if(ct!=null){double ab=ct.buyIValue>0&&ct.buyICount>0?ct.buyIValue/ct.buyICount:0,as=ct.sellIValue>0&&ct.sellICount>0?ct.sellIValue/ct.sellICount:0;bp=as>0?ab/as:0;flow=ct.buyIValue-ct.sellIValue;}
        int score=0;
        if(cur.close>maLong)score+=12;else if(cur.close>maLong*.98)score+=7;
        if(maShort>maLong)score+=10;else if(maShort>=maLong*.99)score+=5;
        if(maShort>maPrev)score+=8;
        double retGood=days<=21?5:10;if(ret>=retGood)score+=12;else if(ret>0)score+=7;else if(ret>-5)score+=3;
        if(rsi>=50&&rsi<=68)score+=5;else if(rsi>68&&rsi<=75)score+=3;if(adx>=25)score+=3;else if(adx>=20)score+=2;
        if(bp>=1.10)score+=10;else if(bp>=.90)score+=7;else if(bp>=.80)score+=4;if(flow>0)score+=5;if(vr>=1.2)score+=3;if(mfi>=55)score+=2;
        if(position>=.65)score+=8;else if(position>=.45)score+=5;double atrPct=cur.close>0?atr(a,n,14)/cur.close*100:10;if(atrPct<=6)score+=5;else if(atrPct<=9)score+=3;
        if(marketScore>=8)score+=10;else if(marketScore>=5)score+=6;
        if(bp>0&&bp<.80)score=Math.min(score,64);if(bp>0&&bp<.65&&flow<=0)score=Math.min(score,54);if(flow<0&&bp>0&&bp<.90)score=Math.min(score,69);if(marketScore<=2)score=Math.min(score,69);if(rsi>78)score=Math.min(score,69);
        score=Math.max(0,Math.min(100,score)); int action=score>=70?1:0;
        double horizonStop=technicalStop(a,n,14,days<=21?45:90,0.25);
        double risk=Math.max(0,cur.close-horizonStop);
        if(risk<=0)risk=cur.close*.08;
        double riskPct=risk/cur.close*100.0;
        if(riskPct>15.0){ score=Math.min(score,74); action=0; }
        double targetPct=days<=21?Math.max(0.04,Math.min(0.18,Math.max(0,ret)*.55/100.0+.035)):Math.max(0.08,Math.min(0.30,Math.max(0,ret)*.55/100.0+.10));
        double target=cur.close*(1+targetPct);
        return new HistoricalSignal(score,action,cur.close-risk,target);
    }

    private HorizonScore calcHorizonScore(List<Row> rows,int n,int days,double buyerPower,double realMoneyFlow,int marketScore){
        int score=0; List<String> reasons=new ArrayList<>();
        if(n<days+20) return new HorizonScore(0,"داده کافی نیست",rows.get(n).close,0,reasons);
        Row cur=rows.get(n);
        int ref=n-days;
        double ret=(rows.get(ref).close>0)?(cur.close/rows.get(ref).close-1)*100:0;
        double maShort=avgClose(rows,n,Math.max(10,days/2));
        double maLong=avgClose(rows,n,days);
        double maPrev=avgClose(rows,Math.max(0,n-Math.max(10,days/2)),Math.max(10,days/2));
        double rsi=rsi(rows,n,14), adx=adx(rows,n,14), mfi=mfi(rows,n,14);
        double vr=avgVol(rows,n,20)>0?cur.vol/avgVol(rows,n,20):0;
        double high=highest(rows,n,days), low=lowest(rows,n,days);
        double position=high>low?(cur.close-low)/(high-low):0.5;

        // Price/trend: 30 points
        if(cur.close>maLong) score+=12; else if(cur.close>maLong*0.98) score+=7;
        if(maShort>maLong) score+=10; else if(maShort>=maLong*0.99) score+=5;
        if(maShort>maPrev) score+=8;
        // Return/momentum: 20 points
        double retGood=days<=21?5:10;
        if(ret>=retGood) score+=12; else if(ret>0) score+=7; else if(ret>-5) score+=3;
        if(rsi>=50&&rsi<=68) score+=5; else if(rsi>68&&rsi<=75) score+=3;
        if(adx>=25) score+=3; else if(adx>=20) score+=2;
        // Liquidity/flow: 20 points, buyer power is a gate rather than a bonus-only input
        if(buyerPower>=1.10) score+=10; else if(buyerPower>=0.90) score+=7; else if(buyerPower>=0.80) score+=4;
        if(realMoneyFlow>0) score+=5;
        if(vr>=1.2) score+=3;
        if(mfi>=55) score+=2;
        // Structure / position: 20 points
        if(position>=0.65) score+=8; else if(position>=0.45) score+=5;
        double atrPct=cur.close>0?atr(rows,n,14)/cur.close*100:10;
        if(atrPct<=6) score+=5; else if(atrPct<=9) score+=3;
        if(marketScore>=8) score+=10; else if(marketScore>=5) score+=6;

        // Hard consistency gates: a medium/long horizon should not call a weak money-flow setup "strong".
        if(buyerPower>0 && buyerPower<0.80){score=Math.min(score,64); reasons.add("قدرت خریدار حقیقی ضعیف است");}
        if(buyerPower>0 && buyerPower<0.65 && realMoneyFlow<=0) score=Math.min(score,54);
        if(realMoneyFlow<0 && buyerPower>0 && buyerPower<0.90) score=Math.min(score,69);
        if(marketScore<=2) score=Math.min(score,69);
        if(rsi>78) score=Math.min(score,69);
        score=(int)Math.max(0,Math.min(100,score));

        String action=score>=75?"خرید/مناسب":score>=70?"نزدیک به ورود":score>=60?"قابل بررسی":"صبر";
        if(ret>0) reasons.add("بازده افق " + days + " روزه مثبت است");
        else reasons.add("بازده افق " + days + " روزه ضعیف است");
        if(cur.close>maLong) reasons.add("قیمت بالای میانگین افق قرار دارد"); else reasons.add("قیمت زیر میانگین افق است");
        if(adx>=25) reasons.add("قدرت روند مناسب است");
        if(mfi>=55) reasons.add("MFI از ورود نقدینگی حمایت می‌کند");
        double target=cur.close*(1+(days<=21?Math.max(0.04,Math.min(0.18,Math.max(0,ret)*0.55/100.0+0.035)):Math.max(0.08,Math.min(0.30,Math.max(0,ret)*0.55/100.0+0.10))));
        double expected=cur.close>0?(target/cur.close-1)*100:0;
        return new HorizonScore(score,action,target,expected,reasons);
    }

    private void resolveCandidateSector(ScanCandidate c){
        if(c==null || c.code==null || c.code.trim().isEmpty()) return;
        String[] urls={
            "https://cdn.tsetmc.com/api/Instrument/GetInstrumentIdentity/"+c.code,
            "https://cdn.tsetmc.com/api/Instrument/GetInstrumentInfo/"+c.code
        };
        for(String url:urls){
            for(int attempt=0;attempt<2;attempt++){
                try{
                    JSONObject o=new JSONObject(httpGet(url));
                    String g=findSectorName(o);
                    if(g!=null && !g.trim().isEmpty()){ c.group=g.trim(); return; }
                }catch(Exception ignored){}
                try{Thread.sleep(120L);}catch(InterruptedException ie){Thread.currentThread().interrupt();return;}
            }
        }
        try{
            String raw=httpGet("http://old.tsetmc.com/tsev2/data/instinfodata.aspx?i="+c.code+"&c=&e=1");
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("LSecVal='([^']*)'").matcher(raw==null?"":raw);
            if(m.find() && !m.group(1).trim().isEmpty()) c.group=m.group(1).trim();
        }catch(Exception ignored){}
    }

    private String findSectorName(JSONObject root){
        if(root==null) return "";
        String[] wrappers={"instrumentIdentity","instrumentInfo","identity","instrument","data"};
        for(String w:wrappers){
            JSONObject x=root.optJSONObject(w);
            String g=findSectorNameDirect(x);
            if(g!=null&&!g.trim().isEmpty()) return g;
        }
        String g=findSectorNameDirect(root);
        if(g!=null&&!g.trim().isEmpty()) return g;
        return findSectorNameDeep(root);
    }

    private String findSectorNameDeep(Object node){
        if(node instanceof JSONObject){
            JSONObject o=(JSONObject)node;
            String[] keys={"lSecVal","lSecVal18","sectorName","industryName","industryGroupName"};
            for(String k:keys){
                String v=o.optString(k,"");
                if(v!=null&&!v.trim().isEmpty()&&!"null".equalsIgnoreCase(v)) return v.trim();
            }
            java.util.Iterator<String> it=o.keys();
            while(it.hasNext()){
                Object child=o.opt(it.next());
                String v=findSectorNameDeep(child);
                if(v!=null&&!v.trim().isEmpty()) return v;
            }
        } else if(node instanceof JSONArray){
            JSONArray a=(JSONArray)node;
            for(int i=0;i<a.length();i++){
                String v=findSectorNameDeep(a.opt(i));
                if(v!=null&&!v.trim().isEmpty()) return v;
            }
        }
        return "";
    }

    private String findSectorNameDirect(JSONObject x){
        if(x==null) return "";
        String[] keys={"sector","industry","sectorInfo","industryGroup"};
        for(String k:keys){
            JSONObject z=x.optJSONObject(k);
            if(z!=null){
                String g=z.optString("lSecVal",z.optString("lSecVal18",z.optString("sectorName",z.optString("name",z.optString("title","")))));
                if(g!=null&&!g.trim().isEmpty()) return g;
            }
            String gs=x.optString(k,"");
            if(gs!=null&&!gs.trim().isEmpty()&&!"null".equalsIgnoreCase(gs)) return gs;
        }
        String[] direct={"lSecVal","sectorName","industryName","industryGroupName"};
        for(String k:direct){
            String g=x.optString(k,"");
            if(g!=null&&!g.trim().isEmpty()) return g;
        }
        return "";
    }

    private void addSectorFallbackCandidates(List<ScanCandidate> candidates,String[] symbols,String group){
        if(symbols==null) return;
        java.util.HashSet<String> existing=new java.util.HashSet<>();
        for(ScanCandidate c:candidates) if(c!=null && c.symbol!=null) existing.add(c.symbol.trim());
        for(String symbol:symbols){
            if(symbol==null || symbol.trim().isEmpty() || existing.contains(symbol.trim())) continue;
            try{
                String q=URLEncoder.encode(symbol.trim(),"UTF-8").replace("+","%20");
                JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentSearch/"+q));
                JSONArray a=o.optJSONArray("instrumentSearch"); if(a==null)a=o.optJSONArray("instrument"); if(a==null)a=o.optJSONArray("instruments");
                if(a==null) continue;
                for(int i=0;i<a.length();i++){
                    JSONObject x=a.optJSONObject(i); if(x==null) continue;
                    String code=x.optString("insCode","");
                    String title=x.optString("lVal18AFC",x.optString("lVal30",symbol.trim()));
                    if(code.isEmpty()) continue;
                    ScanCandidate c=new ScanCandidate(code,title,1.0,0,0,0); c.group=group; candidates.add(c); existing.add(title.trim()); break;
                }
            }catch(Exception ignored){}
        }
    }

    private boolean isPharmaGroup(String group){
        if(group==null) return false;
        String g=group.trim().replace("ي","ی").replace("ك","ک");
        return g.contains("دارویی") || g.contains("دارو") || g.contains("مواد و محصولات دارویی");
    }

    private boolean isCementGroup(String group){
        if(group==null) return false;
        String g=group.trim().replace("ي","ی").replace("ك","ک");
        return g.contains("سیمان") || g.contains("سیمانی");
    }

    private boolean isIndexHeavySymbol(String symbol){
        if(symbol==null) return false;
        String s=symbol.trim().replace("ي","ی").replace("ك","ک").replace(" ","").toLowerCase(java.util.Locale.ROOT);
        String[] heavy={
            "فارس","فولاد","فملی","ذوب","کگل","کچاد","شپنا","شبندر","شتران","شبریز",
            "تاپیکو","پارسان","وغدیر","شستا","خودرو","خساپا","وبملت","وتجارت","وبصادر",
            "وپارس","وامید","رمپنا","حکشتی","اخابر","همراه","وبانک","وتوسم","وساپا",
            "وسینا","وبهمن","وغدیر","نوری","زاگرس","مارون","بوعلی","جم","پارس",
            "شپدیس","فخوز","کگهر","آریا","صبا","شگویا","بفجر","فجر","کطبس"
        };
        for(String x:heavy) if(s.equals(x)) return true;
        return false;
    }

    private List<ScanCandidate> diversifyCandidates(List<ScanCandidate> all,int maxCount,int perGroup){
        List<ScanCandidate> out=new ArrayList<>();
        java.util.LinkedHashMap<String,Integer> used=new java.util.LinkedHashMap<>();
        // First pass: guarantee representation across industries.
        for(ScanCandidate c:all){
            if(out.size()>=maxCount) break;
            String g=(c.group==null||c.group.trim().isEmpty())?"سایر":c.group.trim();
            int n=used.containsKey(g)?used.get(g):0;
            if(n<perGroup){ out.add(c); used.put(g,n+1); }
        }
        // Second pass: use remaining capacity for the best-ranked names.
        if(out.size()<maxCount){
            java.util.HashSet<String> seen=new java.util.HashSet<>();
            for(ScanCandidate c:out) seen.add(c.code);
            for(ScanCandidate c:all){
                if(out.size()>=maxCount) break;
                if(seen.add(c.code)) out.add(c);
            }
        }
        return out;
    }

    private void resolveCandidateName(ScanCandidate c){
        try{
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/Instrument/GetInstrumentInfo/"+c.code));
            JSONObject x=o.optJSONObject("instrumentInfo");
            if(x==null) x=o.optJSONObject("instrument");
            if(x!=null){
                String s=x.optString("lVal18AFC",x.optString("lVal18",x.optString("l18",x.optString("lVal30",""))));
                if(s!=null && !s.trim().isEmpty()) c.symbol=s.trim();
                String g=findSectorName(o);
                if(g!=null && !g.trim().isEmpty()) c.group=g.trim();
            }
        }catch(Exception ignored){}
    }

    private void addCandidate(List<ScanCandidate> list,String code,String sym,double close,double last,double yesterday,double vol,double value){
        if(code==null || code.length()==0 || close<=0) return;
        if(sym==null || sym.trim().isEmpty()) sym=code;
        double change=yesterday>0?(last-yesterday)/yesterday*100.0:0;
        double activity=value>0?Math.log10(value):0;
        double fast=50 + Math.max(-15,Math.min(15,change*3)) + Math.max(0,Math.min(15,activity-7));
        list.add(new ScanCandidate(code,sym,fast,value,vol,change));
    }
    private double toNum(String s){ try{return Double.parseDouble(s.trim().replace(",",""));}catch(Exception e){return 0;} }

    private QueueStatus getQueueSnapshot(String insCode, double currentClose) {
        try {
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/BestLimits/"+insCode));
            JSONArray a=o.optJSONArray("bestLimits");
            if(a==null || a.length()==0) return new QueueStatus(false,0,0,0,0,0,0);
            double bestBuy=0,bestSell=0;
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                double bp=x.optDouble("pMeDem",0), sp=x.optDouble("pMeOf",0);
                if(bp>bestBuy) bestBuy=bp;
                if(sp>0 && (bestSell<=0 || sp<bestSell)) bestSell=sp;
            }
            double buyVol=0,buyOrd=0,sellVol=0,sellOrd=0;
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                double bp=x.optDouble("pMeDem",0), sp=x.optDouble("pMeOf",0);
                if(bp>0 && Math.abs(bp-bestBuy)<0.000001){buyVol=Math.max(buyVol,x.optDouble("qTitMeDem",0));buyOrd=Math.max(buyOrd,x.optDouble("zOrdMeDem",0));}
                if(sp>0 && Math.abs(sp-bestSell)<0.000001){sellVol=Math.max(sellVol,x.optDouble("qTitMeOf",0));sellOrd=Math.max(sellOrd,x.optDouble("zOrdMeOf",0));}
            }
            double upper=0,lower=0;
            try{ JSONObject cp=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceInfo/"+insCode)); JSONObject ci=cp.optJSONObject("closingPriceInfo"); if(ci!=null){upper=num(ci,"priceMax","pMax","maxPrice","pMaxPrice");lower=num(ci,"priceMin","pMin","minPrice","pMinPrice");} }catch(Exception ignored){}
            boolean atUpper=currentClose>0&&upper>0&&Math.abs(currentClose-upper)/upper<0.0025;
            boolean atLower=currentClose>0&&lower>0&&Math.abs(currentClose-lower)/lower<0.0025;
            boolean buyQueue=atUpper&&bestBuy>0&&Math.abs(bestBuy-upper)/upper<0.0025&&buyVol>0&&sellVol<=0&&sellOrd<=0;
            boolean sellQueue=atLower&&bestSell>0&&Math.abs(bestSell-lower)/lower<0.0025&&sellVol>0&&buyVol<=0&&buyOrd<=0;
            QueueStatus qs=new QueueStatus(buyQueue,buyVol,buyOrd,sellVol,sellOrd,bestBuy,bestSell); qs.isSellQueue=sellQueue; return qs;
        }catch(Exception e){return new QueueStatus(false,0,0,0,0,0,0);}
    }

    private QueueStatus detectBuyQueue(String insCode,double currentClose){ return getQueueSnapshot(insCode,currentClose); }

    private String buildDailyPanel() throws Exception {
        String url="https://cdn.tsetmc.com/api/ClosingPrice/GetMarketWatch?market=0&industrialGroup=&paperTypes%5B0%5D=1&paperTypes%5B1%5D=2&paperTypes%5B2%5D=3&paperTypes%5B3%5D=4&paperTypes%5B4%5D=5&paperTypes%5B5%5D=6&paperTypes%5B6%5D=7&paperTypes%5B7%5D=8&paperTypes%5B8%5D=9&showTraded=false&withBestLimits=false&hEven=0&RefID=0";
        JSONObject o=new JSONObject(httpGet(url)); JSONArray a=o.optJSONArray("marketwatch");
        if(a==null||a.length()==0) throw new Exception("داده معاملات امروز از TSETMC در دسترس نیست");
        List<DailyItem> list=new ArrayList<>(); int up=0,down=0,flat=0; double totalValue=0,totalVolume=0;
        for(int i=0;i<a.length();i++){ JSONObject x=a.optJSONObject(i); if(x==null)continue; String code=x.optString("insCode",""); if(code.isEmpty())continue; String sym=x.optString("lVal18AFC",x.optString("symbol",x.optString("lVal30",code))); double close=num(x,"pClosing","pc","priceClosing"),last=num(x,"pDrCotVal","pl","priceLast"),y=num(x,"priceYesterday","py","yClose"),vol=num(x,"qTotTran5J","tvol","volume"),val=num(x,"qTotCap","tval","value"); if(close<=0)continue; double ch=y>0?(last-y)/y*100:0; if(ch>0.05)up++; else if(ch<-0.05)down++; else flat++; totalValue+=Math.max(0,val); totalVolume+=Math.max(0,vol); list.add(new DailyItem(code,sym,close,last,y,vol,val,ch)); }
        Collections.sort(list,(u,v)->Double.compare(v.value,u.value));
        int limit=Math.min(20,list.size()); JSONArray rows=new JSONArray();
        for(int i=0;i<limit;i++){ DailyItem d=list.get(i); QueueStatus q=getQueueSnapshot(d.code,d.close); JSONObject z=new JSONObject(); z.put("symbol",d.symbol);z.put("insCode",d.code);z.put("last",d.last);z.put("change",d.change);z.put("volume",d.volume);z.put("value",d.value);z.put("buy_queue_volume",q.buyVolume);z.put("buy_queue_orders",q.buyOrders);z.put("sell_queue_volume",q.sellVolume);z.put("sell_queue_orders",q.sellOrders);z.put("buy_limit",q.buyLimit);z.put("sell_limit",q.sellLimit);z.put("queue_side",q.isBuyQueue?"BUY":""); rows.put(z); }
        JSONObject out=new JSONObject(); out.put("ok",true);out.put("up",up);out.put("down",down);out.put("flat",flat);out.put("total_value",totalValue);out.put("total_volume",totalVolume);out.put("items",rows);out.put("source","TSETMC");out.put("note","پنل امروز بر اساس داده بازار و بهترین مظنه‌هاست؛ حجم صف با داده لحظه‌ای دفتر سفارش محاسبه می‌شود و ممکن است با تغییر صف‌ها تغییر کند."); return out.toString();
    }

    private JSONArray detectPatterns(List<Row>a,int n,double vr,double resistance){ JSONArray p=new JSONArray(); if(n<2)return p; Row c=a.get(n),pr=a.get(n-1); double range=Math.max(0,c.high-c.low),body=Math.abs(c.close-c.open),upper=Math.max(0,c.high-Math.max(c.close,c.open)),lower=Math.max(0,Math.min(c.close,c.open)-c.low); if(range>0&&body/range<=0.10)p.put("دوجی / عدم تصمیم"); if(body>0&&lower>=body*2&&upper<=body*1.2&&c.close>=c.open)p.put("چکش صعودی"); if(body>0&&lower>=body*2&&upper<=body*1.2&&c.close<c.open)p.put("فشار فروش با سایه پایینی بلند"); if(pr.close<pr.open&&c.close>c.open&&c.open<=pr.close&&c.close>=pr.open)p.put("پوشای صعودی"); if(pr.close>pr.open&&c.close<c.open&&c.open>=pr.close&&c.close<=pr.open)p.put("پوشای نزولی"); if(c.close>resistance&&c.close>=c.open)p.put(vr>=1.2?"شکست مقاومت با تأیید حجم":"شکست مقاومت بدون تأیید کامل حجم"); if(vr>=2)p.put("جهش حجم معاملات"); double ma20=avgClose(a,n,20),ma50=avgClose(a,n,50),pma20=avgClose(a,n-1,20),pma50=avgClose(a,n-1,50); if(ma20>ma50&&pma20<=pma50)p.put("تقاطع صعودی MA20/MA50"); if(ma20<ma50&&pma20>=pma50)p.put("تقاطع نزولی MA20/MA50"); return p; }
    private int patternSignal(JSONArray p){ int n=p.length(),s=0; for(int i=0;i<n;i++){String x=p.optString(i,""); if(x.contains("صعودی")||x.contains("شکست مقاومت")||x.contains("تقاطع صعودی")||x.contains("جهش حجم"))s+=20; else if(x.contains("نزولی")||x.contains("فشار فروش")||x.contains("تقاطع نزولی"))s-=20; else s+=5;} return (int)clamp(50+s,0,100); }
    private JSONArray algorithmFlags(List<Row>a,int n,double rsi,double adx,double vr,double bp,double flow){ JSONArray x=new JSONArray(); if(rsi>=70)x.put("بیش‌خرید"); else if(rsi<=30)x.put("بیش‌فروش"); if(adx>=25)x.put("روند قدرتمند"); else if(adx<20)x.put("روند ضعیف"); if(vr>=1.5)x.put("تأیید حجم"); if(bp>=1.5)x.put("قدرت خریدار بالا"); else if(bp>0&&bp<0.8)x.put("قدرت خریدار ضعیف"); if(flow>0)x.put("ورود پول حقیقی"); else if(flow<0)x.put("خروج پول حقیقی"); return x; }

    private JSONObject getTodayTradingPanel(String insCode,double currentClose,QueueStatus q) throws Exception {
        JSONObject out=new JSONObject();
        JSONObject cp=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceInfo/"+insCode));
        JSONObject ci=cp.optJSONObject("closingPriceInfo");
        if(ci==null) ci=cp.optJSONObject("closingPrice");
        if(ci!=null){
            double last=num(ci,"pDrCotVal","lastPrice","last","pLast");
            double close=num(ci,"pClosing","close","closePrice");
            double y=num(ci,"pYester","pYesterday","yesterdayPrice","priceYesterday");
            double high=num(ci,"pMax","priceMax","maxPrice","pMaxPrice");
            double low=num(ci,"pMin","priceMin","minPrice","pMinPrice");
            double vol=num(ci,"qTotTran5J","volume","qVolume","totalVolume");
            double val=num(ci,"qTotCap","value","tradeValue","qTotCapValue");
            double trades=num(ci,"zTotTran","trades","tradeCount","zTotTran5J");
            double base=y>0?y:close, lp=last>0?last:currentClose;
            out.put("today_last",last); out.put("today_close",close); out.put("today_yesterday",y);
            out.put("today_high",high); out.put("today_low",low); out.put("today_volume",vol); out.put("today_value",val); out.put("today_trades",trades);
            out.put("today_change_pct",base>0?(lp/base-1)*100.0:0);
        }
        out.put("buy_queue",q.isBuyQueue); out.put("buy_queue_volume",q.buyVolume); out.put("buy_queue_orders",q.buyOrders); out.put("buy_queue_limit",q.buyLimit);
        out.put("sell_queue",q.isSellQueue); out.put("sell_queue_volume",q.sellVolume); out.put("sell_queue_orders",q.sellOrders); out.put("sell_queue_limit",q.sellLimit);
        out.put("today_queue_side",q.isBuyQueue?"صف خرید":(q.isSellQueue?"صف فروش":"بدون صف قفل‌شده"));
        return out;
    }

    private ClientData getLatestClientType(String insCode, int date) {
        try {
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/"+insCode));
            JSONArray a=o.optJSONArray("clientType"); if(a==null) return null;
            JSONObject best=null; int bestDate=0;
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null) continue;
                int d=x.optInt("recDate",0);
                if(d==date){best=x; break;}
            }
            if(best==null) return null;
            ClientData c=new ClientData();
            c.buyIValue=best.optDouble("buy_I_Value",0); c.sellIValue=best.optDouble("sell_I_Value",0);
            c.buyICount=best.optDouble("buy_I_Count",0); c.sellICount=best.optDouble("sell_I_Count",0);
            c.buyIVolume=best.optDouble("buy_I_Volume",0); c.sellIVolume=best.optDouble("sell_I_Volume",0);
            c.date=best.optInt("recDate",0); return c;
        } catch(Exception e) { return null; }
    }

    private MarketRegime getMarketRegime() {
        List<IndexPoint> a=fetchIndexHistory("32097828799138957");
        if(a.size()<25){
            a=fetchIndexHistory("32097828820363860");
        }
        if(a.size()<25) return new MarketRegime(5,"خنثی (داده شاخص ناقص است)");

        double now=a.get(a.size()-1).value;
        int s=Math.max(0,a.size()-20);
        double m20=0;
        for(int i=s;i<a.size();i++) m20+=a.get(i).value;
        m20/=a.size()-s;
        double old=a.get(a.size()-21).value;
        if(now>m20 && now>old*1.02) return new MarketRegime(10,"صعودی قوی");
        if(now>m20 && now>old) return new MarketRegime(8,"صعودی");
        if(now>=old*0.98 && now<=old*1.02) return new MarketRegime(5,"خنثی");
        if(now<m20 && now<old*0.98) return new MarketRegime(0,"نزولی شدید");
        return new MarketRegime(2,"نزولی");
    }

    private double clamp(double v,double lo,double hi){return Math.max(lo,Math.min(hi,v));}
    private double num(JSONObject x,String... keys){for(String k:keys) if(x.has(k)) return x.optDouble(k,0); return 0;}
    private double avgClose(List<Row> a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z+=a.get(i).close;return z/(end-s+1);}
    private double avgVol(List<Row> a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z+=a.get(i).vol;return z/(end-s+1);}
    private double highest(List<Row>a,int end,int len){int s=Math.max(0,end-len+1);double z=0;for(int i=s;i<=end;i++)z=Math.max(z,a.get(i).high);return z;}
    // Technical short-term stop: nearest meaningful swing support below price,
    // with a small ATR buffer. Falls back to 1.5 ATR only when no valid swing
    // support exists. This avoids using a distant 20-day absolute low as the stop.
    private double technicalStop(List<Row>a,int end,int atrLen,int lookback,double bufferAtr){
        Row cur=a.get(end); double atrv=atr(a,end,atrLen);
        double best=0; int s=Math.max(1,end-lookback+1);
        for(int i=s+1;i<=end-1;i++){
            Row r=a.get(i),p=a.get(i-1),q=a.get(i+1);
            if(r.low<=p.low && r.low<=q.low && r.low<cur.close){
                if(r.low>best) best=r.low;
            }
        }
        double stop=best>0 ? best- Math.max(0,atrv*bufferAtr) : cur.close-1.5*atrv;
        if(stop<=0 || stop>=cur.close) stop=cur.close-1.5*atrv;
        return Math.max(0,stop);
    }
    private double lowest(List<Row>a,int end,int len){int s=Math.max(0,end-len+1);double z=Double.MAX_VALUE;for(int i=s;i<=end;i++)z=Math.min(z,a.get(i).low);return z==Double.MAX_VALUE?0:z;}
    private double rsi(List<Row>a,int end,int len){if(end<len)return 50;double g=0,l=0;for(int i=end-len+1;i<=end;i++){double d=a.get(i).close-a.get(i-1).close;if(d>0)g+=d;else l-=d;}if(l==0)return 100;double rs=(g/len)/(l/len);return 100-(100/(1+rs));}
    private double adx(List<Row>a,int end,int len){
        if(end < len*2) return 0;
        double trSum=0, plusSum=0, minusSum=0;
        double adxSum=0, adxValue=0; int dxCount=0;
        double prevTr=0, prevPlus=0, prevMinus=0;
        for(int i=1;i<=end;i++){
            Row r=a.get(i), p=a.get(i-1);
            double up=r.high-p.high, down=p.low-r.low;
            double tr=Math.max(r.high-r.low,Math.max(Math.abs(r.high-p.close),Math.abs(r.low-p.close)));
            double plus=(up>down && up>0)?up:0;
            double minus=(down>up && down>0)?down:0;
            if(i<=len){trSum+=tr; plusSum+=plus; minusSum+=minus; continue;}
            if(i==len+1){
                prevTr=trSum-trSum/len+tr;
                prevPlus=plusSum-plusSum/len+plus;
                prevMinus=minusSum-minusSum/len+minus;
            } else {
                prevTr=prevTr-prevTr/len+tr;
                prevPlus=prevPlus-prevPlus/len+plus;
                prevMinus=prevMinus-prevMinus/len+minus;
            }
            double pdi=prevTr>0?100*prevPlus/prevTr:0;
            double mdi=prevTr>0?100*prevMinus/prevTr:0;
            double dx=(pdi+mdi)>0?100*Math.abs(pdi-mdi)/(pdi+mdi):0;
            if(dxCount<len){adxSum+=dx; dxCount++; if(dxCount==len) adxValue=adxSum/len;}
            else adxValue=((adxValue*(len-1))+dx)/len;
        }
        return dxCount>=len?Math.max(0,Math.min(100,adxValue)):0;
    }
    private double mfi(List<Row>a,int end,int len){
        if(end<len)return 50; double pos=0,neg=0;
        int s=Math.max(1,end-len+1);
        for(int i=s;i<=end;i++){Row r=a.get(i),p=a.get(i-1); double tp=(r.high+r.low+r.close)/3.0; double ptp=(p.high+p.low+p.close)/3.0; double flow=tp*r.vol;
            if(tp>ptp)pos+=flow; else if(tp<ptp)neg+=flow;
        }
        if(neg<=0)return 100; double ratio=pos/neg; return 100-(100/(1+ratio));
    }
    private double ema(List<Row>a,int end,int len){int s=Math.max(0,end-len*3);double e=a.get(s).close;double k=2.0/(len+1);for(int i=s+1;i<=end;i++)e=a.get(i).close*k+e*(1-k);return e;}
    private double atr(List<Row>a,int end,int len){int s=Math.max(1,end-len+1);double z=0;for(int i=s;i<=end;i++){Row r=a.get(i),p=a.get(i-1);z+=Math.max(r.high-r.low,Math.max(Math.abs(r.high-p.close),Math.abs(r.low-p.close)));}return z/(end-s+1);}
    private String errorJson(String msg){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",msg);return o.toString();}catch(Exception e){return "{\"ok\":false,\"error\":\"خطا\"}";}}
    private static class QueueStatus{boolean isBuyQueue,isSellQueue;double buyVolume,buyOrders,sellVolume,sellOrders,buyLimit,sellLimit;QueueStatus(boolean q,double v,double o,double sv,double so,double bp,double sp){isBuyQueue=q;isSellQueue=sv>0&&so>0&&sp>0&&bp<=0;buyVolume=v;buyOrders=o;sellVolume=sv;sellOrders=so;buyLimit=bp;sellLimit=sp;}}
    private static class ScanCandidate{String code,symbol,group;double fast,value,vol,change;ScanCandidate(String c,String s,double f,double v,double q,double ch){code=c;symbol=s;fast=f;value=v;vol=q;change=ch;}}
    private static class Row{double close,open,high,low,vol;int date;Row(double c,double o,double h,double l,double v,int d){close=c;open=o;high=h;low=l;vol=v;date=d;}}
    private static class ClientData{double buyIValue,sellIValue,buyICount,sellICount,buyIVolume,sellIVolume;int date;}
    private static class MarketRegime{int score;String label;MarketRegime(int s,String l){score=s;label=l;}}
    private static class TradeResult{final int date;final double ret;TradeResult(int date,double ret){this.date=date;this.ret=ret;}}
    private static class BacktestSymbol{ScanCandidate c;List<Row> rows;java.util.Map<Integer,ClientData> clients;BacktestSymbol(ScanCandidate c,List<Row> r,java.util.Map<Integer,ClientData> m){this.c=c;rows=r;clients=m;}}
    private static class IndexPoint{int date;double value;IndexPoint(int d,double v){date=d;value=v;}}
    private static class HistoricalSignal{int score,action;double stop,target;HistoricalSignal(int s,int a,double st,double t){score=s;action=a;stop=st;target=t;}}
    private static class HorizonScore{int score;String action;double target,expectedReturn;List<String> reasons;HorizonScore(int s,String a,double t,double r,List<String> rs){score=s;action=a;target=t;expectedReturn=r;reasons=rs;}}
    private static class DailyItem{String code,symbol;double close,last,yesterday,volume,value,change;DailyItem(String c,String s,double cl,double l,double y,double v,double val,double ch){code=c;symbol=s;close=cl;last=l;yesterday=y;volume=v;value=val;change=ch;}}

    @Override public void onBackPressed(){if(webView!=null && !activityDestroyed.get() && webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){
        activityDestroyed.set(true);
        operationBusy.set(false);
        if(webView!=null){
            try { webView.stopLoading(); } catch(Throwable ignored) {}
            try { webView.removeJavascriptInterface("Android"); } catch(Throwable ignored) {}
            try { webView.destroy(); } catch(Throwable ignored) {}
            webView=null;
        }
        super.onDestroy();
    }
}
