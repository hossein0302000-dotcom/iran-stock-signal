package com.iranstocks.signal;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.CandleStickChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.CandleData;
import com.github.mikephil.charting.data.CandleDataSet;
import com.github.mikephil.charting.data.CandleEntry;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ChartActivity extends Activity {
    private CandleStickChart chart;
    private TextView status;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String symbol = getIntent().getStringExtra("symbol");
        String insCode = getIntent().getStringExtra("insCode");
        if (symbol == null) symbol = "نماد";
        if (insCode == null) insCode = "";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12, 12, 12, 12);

        TextView title = new TextView(this);
        title.setText("📈 نمودار کندلی «" + symbol + "»");
        title.setTextSize(20);
        title.setTextColor(Color.rgb(25,25,25));
        title.setPadding(8, 8, 8, 14);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        status = new TextView(this);
        status.setText("در حال دریافت ۱۲۰ روز داده از TSETMC...");
        status.setTextSize(13);
        status.setPadding(8, 0, 8, 8);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        chart = new CandleStickChart(this);
        chart.setNoDataText("داده نمودار در دسترس نیست");
        chart.setBackgroundColor(Color.WHITE);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);
        chart.setDoubleTapToZoomEnabled(true);
        chart.setHighlightPerDragEnabled(true);
        chart.getDescription().setEnabled(false);
        chart.getLegend().setEnabled(false);
        chart.setExtraOffsets(8, 4, 12, 12);
        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setGranularity(1f);
        x.setDrawGridLines(false);
        YAxis left = chart.getAxisLeft();
        left.setDrawGridLines(true);
        chart.getAxisRight().setEnabled(false);
        root.addView(chart, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        if (insCode == null || insCode.trim().isEmpty()) {
            status.setText("کد نماد در دسترس نیست");
            return;
        }
        final String code = insCode.trim();
        new Thread(() -> {
            try {
                JSONArray rows = loadHistory(code);
                runOnUiThread(() -> render(rows));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("خطا در دریافت نمودار: " + (e.getMessage() == null ? "نامشخص" : e.getMessage())));
            }
        }, "ChartLoader").start();
    }

    private JSONArray loadHistory(String code) throws Exception {
        String url = "https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/" + code + "/120";
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("GET");
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
        int rc = c.getResponseCode();
        BufferedReader br = new BufferedReader(new InputStreamReader(rc >= 200 && rc < 300 ? c.getInputStream() : c.getErrorStream(), StandardCharsets.UTF_8));
        StringBuilder b = new StringBuilder(); String line;
        while ((line = br.readLine()) != null) b.append(line);
        br.close(); c.disconnect();
        if (rc < 200 || rc >= 300) throw new Exception("TSETMC HTTP " + rc);
        JSONObject obj = new JSONObject(b.toString());
        JSONArray raw = obj.optJSONArray("closingPriceDaily");
        if (raw == null || raw.length() == 0) throw new Exception("داده تاریخی یافت نشد");
        return raw;
    }

    private void render(JSONArray raw) {
        try {
            List<JSONObject> rows = new ArrayList<>();
            for (int i=0;i<raw.length();i++) {
                JSONObject x=raw.optJSONObject(i);
                if(x!=null) rows.add(x);
            }
            Collections.sort(rows, Comparator.comparingInt(a -> a.optInt("dEven", 0)));
            int from=Math.max(0, rows.size()-90);
            ArrayList<CandleEntry> entries = new ArrayList<>();
            ArrayList<String> labels = new ArrayList<>();
            for(int i=from;i<rows.size();i++) {
                JSONObject x=rows.get(i);
                float open=(float)num(x,"priceFirst","pOpen","open","Open");
                float high=(float)num(x,"priceMax","pHigh","high","High");
                float low=(float)num(x,"priceMin","pLow","low","Low");
                float close=(float)num(x,"pClosing","close","Close");
                if(open<=0||high<=0||low<=0||close<=0) continue;
                entries.add(new CandleEntry(entries.size(),high,low,open,close));
                labels.add(String.valueOf(x.optInt("dEven",0)));
            }
            if(entries.isEmpty()) throw new Exception("داده معتبر نمودار وجود ندارد");
            CandleDataSet set = new CandleDataSet(entries, "قیمت");
            set.setDrawValues(false);
            set.setShadowWidth(1.2f);
            set.setBarSpace(0.18f);
            set.setIncreasingColor(Color.rgb(30,140,80));
            set.setIncreasingPaintStyle(android.graphics.Paint.Style.FILL);
            set.setDecreasingColor(Color.rgb(205,65,65));
            set.setDecreasingPaintStyle(android.graphics.Paint.Style.FILL);
            set.setNeutralColor(Color.GRAY);
            set.setShadowColor(Color.DKGRAY);
            set.setHighlightEnabled(true);
            CandleData data = new CandleData(set);
            chart.setData(data);
            chart.invalidate();
            chart.moveViewToX(Math.max(0, entries.size()-35));
            chart.setVisibleXRangeMaximum(45);
            status.setText("۹۰ روز اخیر • زوم و جابه‌جایی روی نمودار فعال است");
        } catch(Exception e) {
            status.setText("خطا در ساخت نمودار: " + (e.getMessage() == null ? "نامشخص" : e.getMessage()));
        }
    }

    private double num(JSONObject o, String... keys) {
        for(String k:keys) {
            if(o.has(k) && !o.isNull(k)) {
                Object v=o.opt(k);
                if(v instanceof Number) return ((Number)v).doubleValue();
                try { return Double.parseDouble(String.valueOf(v)); } catch(Exception ignored) {}
            }
        }
        return 0;
    }
}
