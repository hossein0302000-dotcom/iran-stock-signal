package com.iranstocks.signal;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.github.mikephil.charting.charts.CandleStickChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.CandleData;
import com.github.mikephil.charting.data.CandleDataSet;
import com.github.mikephil.charting.data.CandleEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class ChartActivity extends Activity {
    private TextView status;
    private TextView selectedInfo;
    private CandleStickChart chart;
    private final ArrayList<String> dateLabels=new ArrayList<>();
    private final ArrayList<String> dayDetails=new ArrayList<>();
    private android.app.AlertDialog detailsDialog;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String symbol=getIntent().getStringExtra("symbol");
        String insCode=getIntent().getStringExtra("insCode");
        if(symbol==null||symbol.trim().isEmpty()) symbol="نماد";
        if(insCode==null) insCode="";

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10,10,10,10);
        TextView title=new TextView(this);
        title.setText("📈 نمودار کندلی «"+symbol+"»");
        title.setTextSize(20); title.setTextColor(Color.WHITE); title.setPadding(8,8,8,10);
        root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        android.widget.Button back=new android.widget.Button(this);
        back.setText("← بازگشت");
        back.setOnClickListener(v -> finish());
        root.addView(back,new LinearLayout.LayoutParams(-1,-2));
        status=new TextView(this); status.setText("در حال دریافت داده نمودار از منبع زنده بازار..."); status.setTextColor(Color.LTGRAY); status.setPadding(8,0,8,8);
        root.addView(status,new LinearLayout.LayoutParams(-1,-2));

        chart=new CandleStickChart(this);
        chart.setBackgroundColor(Color.rgb(7,17,31));
        chart.setNoDataText("داده نمودار موجود نیست"); chart.setNoDataTextColor(Color.LTGRAY);
        chart.getDescription().setEnabled(false); chart.setPinchZoom(true); chart.setScaleEnabled(true); chart.setDragEnabled(true); chart.setDoubleTapToZoomEnabled(true); chart.setHighlightPerDragEnabled(true); chart.setHighlightPerTapEnabled(true);
        chart.setDrawGridBackground(false); chart.getLegend().setEnabled(false);
        XAxis x=chart.getXAxis(); x.setPosition(XAxis.XAxisPosition.BOTTOM); x.setTextColor(Color.LTGRAY); x.setDrawGridLines(false); x.setGranularity(1f); x.setGranularityEnabled(true); x.setLabelRotationAngle(-45f); x.setAvoidFirstLastClipping(true);
        YAxis left=chart.getAxisLeft(); left.setTextColor(Color.LTGRAY); left.setDrawGridLines(true); left.setGridColor(Color.rgb(35,55,75));
        YAxis right=chart.getAxisRight(); right.setEnabled(false);
        root.addView(chart,new LinearLayout.LayoutParams(-1,0,1f));

        selectedInfo=new TextView(this);
        selectedInfo.setText("روی یک کندل بزنید تا اطلاعات همان روز معاملات نمایش داده شود.");
        selectedInfo.setTextColor(Color.WHITE); selectedInfo.setTextSize(12); selectedInfo.setPadding(10,8,10,8); selectedInfo.setBackgroundColor(Color.rgb(12,29,47));
        root.addView(selectedInfo,new LinearLayout.LayoutParams(-1,80));
        setContentView(root);

        chart.setOnChartValueSelectedListener(new OnChartValueSelectedListener(){
            @Override public void onValueSelected(Entry e, Highlight h){
                int i=Math.round(e.getX());
                if(i>=0&&i<dayDetails.size()) {
                    String details=dayDetails.get(i);
                    selectedInfo.setText(details);
                    if(detailsDialog!=null && detailsDialog.isShowing()){
                        detailsDialog.setMessage(details);
                    }else{
                        detailsDialog=new android.app.AlertDialog.Builder(ChartActivity.this)
                            .setTitle("📊 مشخصات معاملات روز")
                            .setMessage(details)
                            .setPositiveButton("باشه",null)
                            .create();
                        detailsDialog.setOnDismissListener(d -> detailsDialog=null);
                        detailsDialog.show();
                    }
                }
            }
            @Override public void onNothingSelected(){ }
        });

        final String code=insCode.trim();
        final String chartSymbol = symbol == null ? "" : symbol.trim();
        if(code.isEmpty()){status.setText("کد نماد در دسترس نیست");return;}
        new Thread(() -> { try { JSONArray rows=loadHistory(code,chartSymbol); runOnUiThread(() -> render(rows)); } catch(Exception e){ runOnUiThread(() -> status.setText("خطا در دریافت نمودار: "+safeMsg(e))); } },"ChartLoader").start();
    }

    private String safeMsg(Exception e){String m=e.getMessage();return m==null||m.trim().isEmpty()?"نامشخص":m;}

    private JSONArray loadHistory(String code,String symbol) throws Exception {
        // Primary source: the TradingView data-feed used by tse.ir. It exposes
        // daily OHLCV directly and is a better fit for the candle chart than the
        // CDN daily-history endpoint when that CDN snapshot is stale.
        try {
            JSONArray tv=loadTradingViewHistory(symbol,300);
            if(tv.length()>=5) return tv;
        } catch(Exception ignored) {}

        // Fallback: existing TSETMC CDN hybrid source.
        JSONArray base=fetchArray("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDailyList/"+code+"/0",
                "closingPriceDaily","closingPriceChartData","chartData","data");
        HashMap<String,JSONObject> merged=new HashMap<>();
        for(int i=0;i<base.length();i++){JSONObject x=base.optJSONObject(i);if(x!=null){String d=rawDateKey(x);if(!d.isEmpty())merged.put(d,x);}}

        Calendar cal=Calendar.getInstance();
        SimpleDateFormat df=new SimpleDateFormat("yyyyMMdd",Locale.US);
        for(int i=0;i<45;i++){
            String d=df.format(cal.getTime());
            try{
                JSONArray a=fetchArray("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceDaily/"+code+"/"+d,
                        "closingPriceDaily","data");
                if(a.length()>0){JSONObject x=a.optJSONObject(0);if(x!=null){String k=rawDateKey(x);merged.put(k.isEmpty()?d:k,x);}}
            }catch(Exception ignored){}
            cal.add(Calendar.DAY_OF_YEAR,-1);
        }

        try{
            String body=fetchBody("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceInfo/"+code);
            JSONObject obj=new JSONObject(body);
            JSONObject q=obj.optJSONObject("closingPriceInfo"); if(q==null)q=obj;
            String today=df.format(Calendar.getInstance().getTime());
            if(q!=null&&q.length()>0){JSONObject candle=new JSONObject(q.toString());candle.put("dEven",today);merged.put(today,candle);}
        }catch(Exception ignored){}

        ArrayList<String> keys=new ArrayList<>(merged.keySet());
        Collections.sort(keys);
        JSONArray out=new JSONArray();
        for(String k:keys)out.put(merged.get(k));
        if(out.length()==0)throw new Exception("داده تاریخی یافت نشد");
        return out;
    }

    private JSONArray loadTradingViewHistory(String symbol,int countback) throws Exception {
        String s=symbol==null?"":symbol.trim();
        if(s.isEmpty())throw new Exception("نام نماد در دسترس نیست");
        String enc=java.net.URLEncoder.encode(s,"UTF-8").replace("+","%20");
        long now=System.currentTimeMillis()/1000L;
        long from=now-(4L*365L*24L*60L*60L);
        String url="https://webgw.tse.ir/InstrumentProvider/api/v1/TradingView/history?symbol="+enc+"&resolution=1D&from="+from+"&to="+now+"&countback="+countback;
        String body=fetchBody(url);
        JSONObject obj=new JSONObject(body);
        if(!"ok".equalsIgnoreCase(obj.optString("s")))throw new Exception("TradingView status "+obj.optString("s"));
        JSONArray t=obj.optJSONArray("t"),o=obj.optJSONArray("o"),h=obj.optJSONArray("h"),l=obj.optJSONArray("l"),c=obj.optJSONArray("c"),v=obj.optJSONArray("v");
        if(t==null||o==null||h==null||l==null||c==null)throw new Exception("TradingView OHLC ناقص است");
        int n=Math.min(t.length(),Math.min(o.length(),Math.min(h.length(),Math.min(l.length(),c.length()))));
        JSONArray out=new JSONArray();
        SimpleDateFormat df=new SimpleDateFormat("yyyyMMdd",Locale.US);
        df.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Tehran"));
        for(int i=0;i<n;i++){
            long ts=t.optLong(i,0);
            double oo=o.optDouble(i,0),hh=h.optDouble(i,0),ll=l.optDouble(i,0),cc=c.optDouble(i,0);
            if(ts<=0||oo<=0||hh<=0||ll<=0||cc<=0)continue;
            JSONObject x=new JSONObject();
            x.put("dEven",df.format(new java.util.Date(ts*1000L)));
            x.put("pf",oo); x.put("pmax",hh); x.put("pmin",ll); x.put("pc",cc);
            if(v!=null&&i<v.length())x.put("qTotTran5J",v.optDouble(i,0));
            out.put(x);
        }
        return out;
    }

    private JSONArray fetchArray(String url,String...names) throws Exception{
        String body=fetchBody(url);
        if(body.startsWith("["))return new JSONArray(body);
        JSONObject obj=new JSONObject(body);
        for(String n:names){
            JSONArray a=obj.optJSONArray(n);
            if(a!=null)return a;
            JSONObject one=obj.optJSONObject(n);
            if(one!=null){JSONArray a1=new JSONArray();a1.put(one);return a1;}
        }
        return new JSONArray();
    }

    private String fetchBody(String url) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        try{
            c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent","Mozilla/5.0"); c.setRequestProperty("Accept","application/json,text/plain,*/*");
            int rc=c.getResponseCode(); if(rc<200||rc>=300)throw new Exception("TSETMC HTTP "+rc);
            BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8));
            StringBuilder b=new StringBuilder(); String line; int chars=0;
            while((line=br.readLine())!=null){chars+=line.length();if(chars>12000000)throw new Exception("پاسخ بیش از حد بزرگ است");b.append(line);}
            br.close(); return b.toString().trim();
        }finally{c.disconnect();}
    }

    private String rawDateKey(JSONObject x){
        if(x==null)return "";
        String s=x.optString("dEven",x.optString("date",x.optString("Date",""))).replaceAll("[^0-9]","");
        return s.matches("\\d{8}")?s:"";
    }

    private void render(JSONArray raw){
        try{
            ArrayList<JSONObject> rows=new ArrayList<>(); for(int i=0;i<raw.length();i++){JSONObject x=raw.optJSONObject(i);if(x!=null)rows.add(x);}
            Collections.sort(rows,(a,b)->String.valueOf(a.opt("dEven")).compareTo(String.valueOf(b.opt("dEven"))));
            int from=Math.max(0,rows.size()-300); ArrayList<CandleEntry> entries=new ArrayList<>();
            dateLabels.clear(); dayDetails.clear();
            for(int i=from;i<rows.size();i++){
                JSONObject x=rows.get(i); float o=(float)num(x,"open","Open","pOpen","priceFirst","pFirst","firstPrice","pf"), h=(float)num(x,"high","High","pHigh","priceMax","pMax","maxPrice","pmax"), l=(float)num(x,"low","Low","pLow","priceMin","pMin","minPrice","pmin"), cl=(float)num(x,"close","Close","pClose","pClosing","last","pLast","closingPrice","pc");
                if(o<=0||h<=0||l<=0||cl<=0)continue;
                entries.add(new CandleEntry(entries.size(),h,l,o,cl));
                String rawDate=x.optString("dEven",x.optString("date",x.optString("Date",String.valueOf(x.optInt("dEven",0)))));
                String date=formatPersianDate(rawDate);
                dateLabels.add(date);
                dayDetails.add(buildDayDetails(date,o,h,l,cl,x));
            }
            if(entries.isEmpty())throw new Exception("داده معتبر نمودار وجود ندارد");
            CandleDataSet ds=new CandleDataSet(entries,"قیمت");
            ds.setDrawIcons(false); ds.setShadowColor(Color.LTGRAY); ds.setShadowWidth(1.2f); ds.setDecreasingColor(Color.rgb(220,75,85)); ds.setDecreasingPaintStyle(android.graphics.Paint.Style.FILL); ds.setIncreasingColor(Color.rgb(45,195,125)); ds.setIncreasingPaintStyle(android.graphics.Paint.Style.FILL); ds.setNeutralColor(Color.GRAY); ds.setBarSpace(.12f);
            CandleData data=new CandleData(ds); chart.setData(data);
            chart.getXAxis().setValueFormatter(new ValueFormatter(){
                @Override public String getFormattedValue(float value){ int i=Math.round(value); return i>=0&&i<dateLabels.size()?dateLabels.get(i):""; }
            });
            chart.getXAxis().setLabelCount(Math.min(10,Math.max(2,dateLabels.size())),false);
            chart.notifyDataSetChanged(); chart.invalidate(); chart.moveViewToX(Math.max(0,entries.size()-55));
            status.setText(entries.size()+" روز اخیر • تاریخ شمسی • برای اطلاعات روز روی کندل بزنید");
        }catch(Exception e){status.setText("خطا در ساخت نمودار: "+safeMsg(e));}
    }

    private String buildDayDetails(String date,float o,float h,float l,float cl,JSONObject x){
        double ch=num(x,"priceChange","pClosingChange","pClosingChangeValue","pClosingChangeP");
        double pct=num(x,"priceChangeP","pClosingChangeP","pClosingChangePercent");
        long trades=Math.round(num(x,"zTotTran","zTotTran5J","qTotTran5J","qTotTran","tradeCount"));
        double volume=num(x,"qTotTran5J","qTotTran","qTotTran5J","volume","volumeValue");
        double value=num(x,"qTotCap","qTotCap5J","value","totalValue","tradeValue");
        String change=(ch!=0?fmtNum(ch):"-");
        String percent=(pct!=0?fmtNum(pct)+"٪":"-");
        return "تاریخ: "+date+"\nباز: "+fmtNum(o)+"  |  بالا: "+fmtNum(h)+"  |  پایین: "+fmtNum(l)+"  |  پایانی: "+fmtNum(cl)+"\nتغییر: "+change+" ("+percent+")  |  حجم: "+fmtNum(volume)+"  |  معاملات: "+fmtNum(trades)+"\nارزش معاملات: "+fmtNum(value);
    }

    private String fmtNum(double n){ String s; if(Math.abs(n-Math.rint(n))<0.001) s=String.format(java.util.Locale.US,"%,d",Math.round(n)); else s=String.format(java.util.Locale.US,"%,.2f",n); StringBuilder out=new StringBuilder();String fa="۰۱۲۳۴۵۶۷۸۹";for(int i=0;i<s.length();i++){char c=s.charAt(i);out.append(c>='0'&&c<='9'?fa.charAt(c-'0'):c);}return out.toString(); }
    private String fmtInt(long n){ return fmtNum(n); }

    private String formatPersianDate(String raw){
        String s=raw==null?"":raw.trim();
        s=s.replaceAll("[^0-9]","");
        if(s.matches("\\d{8}")){
            int y=Integer.parseInt(s.substring(0,4)), m=Integer.parseInt(s.substring(4,6)), d=Integer.parseInt(s.substring(6,8));
            if(y>=1900){int[] j=gregorianToJalali(y,m,d); return persianDate(j[0],j[1],j[2]);}
            if(y>=1200&&y<=1500)return persianDate(y,m,d);
            return persianDate(y,m,d);
        }
        return raw==null?"":raw;
    }
    private String persianDate(int y,int m,int d){String z=String.format(java.util.Locale.US,"%04d/%02d/%02d",y,m,d);StringBuilder out=new StringBuilder();String fa="۰۱۲۳۴۵۶۷۸۹";for(int i=0;i<z.length();i++){char c=z.charAt(i);out.append(c>='0'&&c<='9'?fa.charAt(c-'0'):c);}return out.toString();}
    private int[] gregorianToJalali(int gy,int gm,int gd){int[] gdm={0,31,28,31,30,31,30,31,31,30,31,30,31};int gy2=gy-1600,gm2=gm-1,gd2=gd-1;int gDayNo=365*gy2+(gy2+3)/4-(gy2+99)/100+(gy2+399)/400;for(int i=0;i<gm2;i++)gDayNo+=gdm[i];if(gm2>1&&((gy%4==0&&gy%100!=0)||(gy%400==0)))gDayNo++;gDayNo+=gd2;int jDayNo=gDayNo-79;int jNp=jDayNo/12053;jDayNo%=12053;int jy=979+33*jNp+4*(jDayNo/1461);jDayNo%=1461;if(jDayNo>=366){jy+=(jDayNo-1)/365;jDayNo=(jDayNo-1)%365;}int jm,jd;if(jDayNo<186){jm=1+jDayNo/31;jd=1+jDayNo%31;}else{jm=7+(jDayNo-186)/30;jd=1+(jDayNo-186)%30;}return new int[]{jy,jm,jd};}

    private double num(JSONObject o,String...keys){for(String k:keys)if(o.has(k)&&!o.isNull(k)){Object v=o.opt(k);if(v instanceof Number)return ((Number)v).doubleValue();try{return Double.parseDouble(String.valueOf(v));}catch(Exception ignored){}}return 0;}
}
