# V76 build

V76 carries forward the latest portfolio fixes from V75 and makes the executable web layer consistent: the packaged `all.js` is synchronized with `app/src/main/assets/index.html`. Portfolio row actions (analysis, monitoring toggle, and delete) use the asynchronous Android bridge already implemented in `MainActivity.java`, while add/edit remain unchanged. Buyer-power display is preserved.

Version: 1.13.0 / versionCode 64.
