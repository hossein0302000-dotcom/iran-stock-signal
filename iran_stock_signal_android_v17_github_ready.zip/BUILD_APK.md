# ساخت APK بدون Android Studio

این پروژه برای GitHub Actions آماده شده است.

1. کل پروژه را در یک repository جدید GitHub آپلود کنید.
2. Branch اصلی را `main` بگذارید.
3. از تب Actions، workflow با نام `Build Android APK` را اجرا کنید.
4. بعد از پایان موفق، در بخش Artifacts فایل `iran-stock-signal-v1.1-debug` را دانلود کنید.
5. فایل داخل آن `app-debug.apk` است.

نیازی به نصب Android Studio، Android SDK یا Gradle روی گوشی نیست؛ GitHub runner ابزارهای ساخت را نصب می‌کند.

نکته: این APK فعلاً پوسته رابط نسخه 1.1 را دارد و برای تحلیل زنده هنوز باید به API پایتون/سرویس تحلیل متصل شود. این workflow فقط ساخت APK را حل می‌کند.
