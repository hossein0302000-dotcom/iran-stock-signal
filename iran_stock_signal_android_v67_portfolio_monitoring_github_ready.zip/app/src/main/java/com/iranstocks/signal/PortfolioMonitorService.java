package com.iranstocks.signal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

public class PortfolioMonitorService extends Service {
    private static final String CHANNEL_ID="portfolio_monitor";
    private static final int NOTIF_ID=7101;
    private static final long INTERVAL_MS=5*60*1000L;
    private final AtomicBoolean running=new AtomicBoolean(false);
    private Thread worker;

    @Override public void onCreate(){super.onCreate(); createChannel();}

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        startForeground(NOTIF_ID,buildStatusNotification("رصد پرتفوی فعال است"));
        if(running.compareAndSet(false,true)){
            worker=new Thread(this::loop,"PortfolioMonitor");
            worker.start();
        }
        return START_STICKY;
    }

    private void loop(){
        while(running.get()){
            try{
                if(isMarketOpen()) checkPortfolio();
            }catch(Exception ignored){}
            try{Thread.sleep(INTERVAL_MS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        }
    }

    private boolean isMarketOpen(){
        Calendar c=Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Tehran"),Locale.US);
        int dow=c.get(Calendar.DAY_OF_WEEK);
        // Iranian stock market regular session: Saturday through Wednesday, 09:00-12:30 Tehran.
        if(dow==Calendar.THURSDAY || dow==Calendar.FRIDAY) return false;
        int min=c.get(Calendar.HOUR_OF_DAY)*60+c.get(Calendar.MINUTE);
        return min>=540 && min<=750;
    }

    private void checkPortfolio(){
        android.content.SharedPreferences sp=getSharedPreferences(MainActivity.PREFS_NAME,MODE_PRIVATE);
        String raw=sp.getString(MainActivity.PORTFOLIO_KEY,"[]");
        try{
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++){
                JSONObject item=a.optJSONObject(i); if(item==null)continue;
                if(!item.optBoolean("enabled",true))continue;
                monitorItem(sp,a,item,i);
            }
            sp.edit().putString(MainActivity.PORTFOLIO_KEY,a.toString()).apply();
        }catch(Exception ignored){}
    }

    private void monitorItem(android.content.SharedPreferences sp,JSONArray all,JSONObject item,int index){
        try{
            String code=item.optString("insCode","");
            String symbol=item.optString("symbol","نماد");
            if(code.isEmpty()) return;
            JSONObject ci=getClosingInfo(code);
            double last=num(ci,"pDrCotVal","lastPrice","last","pLast");
            double close=num(ci,"pClosing","close","closePrice");
            double y=num(ci,"pYester","pYesterday","yesterdayPrice","priceYesterday");
            if(last<=0) last=close;
            if(last<=0)return;
            double bp=0,flow=0;
            JSONObject ct=getClientType(code);
            if(ct!=null){
                double bi=num(ct,"buy_I_Value"), si=num(ct,"sell_I_Value"), bc=num(ct,"buy_I_Count"), sc=num(ct,"sell_I_Count");
                double avgBuy=bi>0&&bc>0?bi/bc:0, avgSell=si>0&&sc>0?si/sc:0;
                bp=avgSell>0?avgBuy/avgSell:0; flow=bi-si;
            }
            double buyPrice=item.optDouble("buyPrice",0);
            double stop=item.optDouble("stopPrice",0);
            double target=item.optDouble("targetPrice",0);
            String day=String.valueOf(Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Tehran"),Locale.US).get(Calendar.DAY_OF_YEAR));
            String keyBase=day+":"+symbol+":";
            String alert="";
            String detail="";
            if(item.optBoolean("sellAlert",true) && stop>0 && last<=stop){alert="SELL";detail="قیمت به حد ضرر تعیین‌شده رسیده است";}
            else if(item.optBoolean("sellAlert",true) && target>0 && last>=target){alert="SELL";detail="قیمت به هدف تعیین‌شده رسیده است";}
            else if(item.optBoolean("sellAlert",true) && bp>0 && bp<0.65 && flow<=0){alert="SELL";detail="قدرت خریدار بسیار ضعیف و جریان پول حقیقی غیرمثبت است";}
            else if(item.optBoolean("buyAlert",true) && bp>=1.5 && flow>0 && (y<=0 || last>=y)){alert="BUY";detail="قدرت خریدار بالا و ورود پول حقیقی مثبت است";}
            if(alert.isEmpty()) return;
            String lastKey=item.optString("lastAlertKey","");
            String newKey=keyBase+alert;
            long lastTime=item.optLong("lastAlertTime",0);
            long now=System.currentTimeMillis();
            if(newKey.equals(lastKey) && now-lastTime<30*60*1000L) return;
            item.put("lastAlertKey",newKey); item.put("lastAlertTime",now);
            all.put(index,item);
            String title=("SELL".equals(alert)?"🔴 هشدار فروش • ":"🟢 هشدار خرید/تقویت • ")+symbol;
            String body=detail+" | آخرین قیمت: "+format(last);
            if(bp>0) body+=" | قدرت خریدار: "+String.format(Locale.US,"%.2f",bp);
            if(buyPrice>0) body+=" | نسبت به خرید: "+String.format(Locale.US,"%.2f%%",(last/buyPrice-1)*100.0);
            sendAlert(title,body);
        }catch(Exception ignored){}
    }

    private JSONObject getClosingInfo(String code)throws Exception{
        JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClosingPrice/GetClosingPriceInfo/"+code));
        JSONObject x=o.optJSONObject("closingPriceInfo"); return x!=null?x:o;
    }
    private JSONObject getClientType(String code){
        try{
            JSONObject o=new JSONObject(httpGet("https://cdn.tsetmc.com/api/ClientType/GetClientTypeHistory/"+code));
            JSONArray a=o.optJSONArray("clientType"); if(a==null||a.length()==0)return null;
            JSONObject best=null; int bestDate=0;
            for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int d=x.optInt("recDate",0);if(d>=bestDate){bestDate=d;best=x;}}
            return best;
        }catch(Exception e){return null;}
    }
    private String httpGet(String url)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(7000); c.setReadTimeout(10000); c.setRequestProperty("User-Agent","Mozilla/5.0 Android");
        int code=c.getResponseCode(); BufferedReader br=new BufferedReader(new InputStreamReader(code>=200&&code<300?c.getInputStream():c.getErrorStream(), StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String line; while((line=br.readLine())!=null)b.append(line); br.close(); c.disconnect(); if(code<200||code>=300)throw new Exception("HTTP "+code); return b.toString();
    }
    private double num(JSONObject x,String...keys){if(x==null)return 0;for(String k:keys)if(x.has(k))return x.optDouble(k,0);return 0;}
    private String format(double v){return String.format(Locale.US,"%.0f",v);}

    private Notification buildStatusNotification(String text){
        Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,0,i,Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT:PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_ID):new Notification.Builder(this);
        return b.setContentTitle("نبض بازار • رصد پرتفوی").setContentText(text).setSmallIcon(com.iranstocks.signal.R.drawable.ic_launcher).setContentIntent(pi).setOngoing(true).build();
    }
    private void sendAlert(String title,String body){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); int id=(int)(System.currentTimeMillis()%100000)+7200;
        Intent i=new Intent(this,MainActivity.class); PendingIntent pi=PendingIntent.getActivity(this,id,i,Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT:PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_ID):new Notification.Builder(this);
        nm.notify(id,b.setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setSmallIcon(com.iranstocks.signal.R.drawable.ic_launcher).setAutoCancel(true).setContentIntent(pi).build());
    }
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"رصد پرتفوی",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("هشدارهای خرید و فروش پرتفوی");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
    @Override public void onDestroy(){running.set(false);if(worker!=null)worker.interrupt();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
